#region Using declarations
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NinjaTrader.Cbi;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.Gui.NinjaScript
{
    // =====================================================================
    //  SyncModule — execution capture pipeline
    // =====================================================================
    //
    //  Ported from JournifiSync v2.0.1 (NinjaTrader/AddOns/JournifiSync_v2.0.1/
    //  JournifiSync_v2.0.cs) with these surgical changes at the seams:
    //
    //    Removed                          Replaced with
    //    ─────────────────────────────────────────────────────────────────
    //    AddOnBase base class             plain class, lifecycle driven by
    //                                     the orchestrator
    //    OnStateChange()                  Initialize() / Cleanup() public
    //                                     methods called from
    //                                     JournifiSyncNT.OnStateChange
    //    Local syncFolder hardcoded path  JournifiNTPaths.SyncDir
    //    Local LoadSettings/SaveSettings  JournifiNTSettingsStore.Sync.*
    //    LogMessage(level, msg)           JournifiNTLog.Info / .Warn /
    //                                     .Error / line below for EXEC/POS
    //    JournifiExecutionRecord class    JournifiSyncNTExecutionRecord
    //                                     (renamed; same shape, same JSON)
    //    JournifiSyncStats                JournifiSyncNTSyncStats
    //
    //  EVERYTHING ELSE — the export processor loop, ATM template caching,
    //  account subscribe/unsubscribe, JSON serializer, atomic file writes,
    //  the StringBuilder pool, the cache prune cadence — is a direct port.
    //  The wire format (executions_YYYY-MM-DD.json) is bit-identical to
    //  v2.0.1's output so the journal-side JournifiSync watcher needs zero
    //  changes.

    #region Module class

    /// <summary>
    /// SyncModule for JournifiSync NT. Captures every NinjaTrader execution
    /// (across all subscribed accounts), groups by trading day, and writes
    /// atomic JSON batches to <c>JournifiSync\executions_YYYY-MM-DD.json</c>.
    /// The Journifi AI desktop app's chokidar watcher picks them up.
    ///
    /// Threading model:
    ///   • <see cref="OnExecutionUpdate"/> fires on NT's data thread —
    ///     we do minimal work there (dedup check, build record, enqueue)
    ///     and offload disk I/O to the export-processor task.
    ///   • <see cref="ExportProcessorLoop"/> runs as a long-lived Task,
    ///     batching up to 32 records or 50ms of work per round, then
    ///     writing atomically under <see cref="fileLock"/>.
    ///   • The heartbeat timer fires on a thread-pool thread every 2s.
    ///
    /// The orchestrator owns the lifetime — call Initialize on State.Active
    /// and Cleanup on State.Terminated.
    /// </summary>
    public class JournifiSyncNTSyncModule
    {
        #region Constants

        private const int MaxBatchSize = 32;
        private const int BatchWindowMs = 50;
        private const int IdleDelayMs = 200;
        private const int ActiveDelayMs = 50;
        private const int MaxCacheSize = 1000;
        private const int MaxProcessedExecutions = 5000;  // v3.0.1 — bound the dedup set (was unbounded for the whole session)
        private static readonly TimeSpan CachePruneInterval = TimeSpan.FromHours(1);
        private const int HeartbeatIntervalMs = 2000;

        // v3.0.5 — crash/freeze recovery: number of 2s heartbeat sweeps over an
        // account's NT-side Account.Executions after it (re)subscribes. NT reloads
        // the session's executions from the provider ASYNCHRONOUSLY on reconnect,
        // so a single sweep at subscribe-time usually runs too early; 8 sweeps
        // (~16s) covers the load while staying bounded (never a forever loop).
        private const int BackfillSweepsOnConnect = 8;

        // v3.0.6 — periodic full-resync safety net. BEYOND the bounded
        // post-reconnect window above, sweep EVERY subscribed account's
        // Account.Executions once every PeriodicResyncEveryBeats heartbeats, so a
        // fill dropped during NORMAL operation (an in-flight pendingExports queue
        // lost on a recompile / NT restart, or a missed OnExecutionUpdate) is
        // recovered within ~30s instead of never. This is what fixes the dropped-
        // exit-fill class that understated account P&L / balance / drawdown
        // (accounts-tab bug, 2026-07-01). Cheap: processedExecutions dedups every
        // already-seen fill, and ExportBatchToFile skips the rewrite when nothing
        // new — so a no-op sweep costs one Account.Executions.ToList() + a HashSet
        // diff, no file write.
        private const int PeriodicResyncEveryBeats = 15;  // 15 × 2s ≈ 30s

        #endregion

        #region Fields

        // Stats are exposed publicly so the Dashboard / Sync tabs can render
        // them without poking module internals.
        public JournifiSyncNTSyncStats Stats { get; } = new JournifiSyncNTSyncStats();

        // Cached pointer to the v3 settings store's Sync section.  We re-read
        // it on each enable check to avoid stale reads if the user toggled
        // accounts via the UI mid-session.
        private JournifiNTSyncSettings SyncSettings => JournifiNTSettingsStore.Current.Sync;

        // The disabled-accounts set lives in JournifiNTSettings now, but we
        // keep a HashSet wrapper for O(1) lookup on the hot path.  Refreshed
        // from settings whenever ReloadSettings() is called.
        private HashSet<string> disabledAccounts = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly object disabledAccountsLock = new object();

        // Threading + lifecycle
        private CancellationTokenSource cts;
        private Task exportTask;
        private System.Threading.Timer heartbeatTimer;
        private readonly object fileLock = new object();
        private bool initialized;

        // Hot-path data structures
        private readonly ConcurrentQueue<JournifiSyncNTExecutionRecord> pendingExports =
            new ConcurrentQueue<JournifiSyncNTExecutionRecord>();
        private readonly ConcurrentDictionary<string, bool> processedExecutions =
            new ConcurrentDictionary<string, bool>();
        // Caches per-order origin (ATM template OR automated-strategy name) so
        // the account.Strategies scan runs once per orderId, not once per fill.
        private readonly ConcurrentDictionary<string, OrderOrigin> atmTemplateCache =
            new ConcurrentDictionary<string, OrderOrigin>();
        private DateTime lastCachePrune = DateTime.UtcNow;
        private long backfillBeatCounter;   // v3.0.6 — drives the periodic resync safety-net sweep
        private readonly StringBuilder jsonBuilder = new StringBuilder(8192);

        // Account subscriptions. Guarded by subscribedAccountsLock because it's
        // now touched from three threads: NT's account-status thread
        // (OnAccountStatusUpdate), the orchestrator (Initialize/Cleanup), and
        // the heartbeat timer's RescanAccounts sweep (v3.0.1). LOCK-ORDER
        // CONTRACT: never hold subscribedAccountsLock while taking
        // Connection.Connections (and vice-versa) — the two locks are always
        // acquired separately, never nested, so there's no deadlock path.
        private readonly Dictionary<Account, bool> subscribedAccounts = new Dictionary<Account, bool>();
        private readonly object subscribedAccountsLock = new object();

        // v3.0.3 — live broker-position mirror, maintained from OnPositionUpdate,
        // serialized to positions_snapshot.json every heartbeat. Lets the journal
        // reconcile its execution-reconstructed open trades against NT's ACTUAL
        // position: a journal "open" with no matching NT position is a stranded/
        // phantom open (auto-resolvable); a non-flat NT position is real and can be
        // surfaced. Keyed "accountName|instrumentFullName"; a flat position removes
        // its key, so "absent" deterministically means "flat". ConcurrentDictionary
        // because OnPositionUpdate (NT data thread) writes while the heartbeat timer
        // thread reads — no extra lock needed.
        private readonly ConcurrentDictionary<string, LivePositionState> livePositions =
            new ConcurrentDictionary<string, LivePositionState>();

        // v3.0.6 — per-account broker balances (net-liquidation, session realized
        // P&L, cash), mirrored from NT's AccountItemUpdate stream. Serialized into
        // positions_snapshot.json so the journal's Accounts tab can show BROKER
        // TRUTH for NT-linked accounts instead of summing journaled trades (which
        // drift when the sync drops a fill). Keyed by account name; each value is
        // read-modify-written under its own lock (OnAccountItemUpdate on NT's
        // account thread vs the heartbeat thread reading the snapshot).
        private readonly ConcurrentDictionary<string, LiveAccountBalance> liveBalances =
            new ConcurrentDictionary<string, LiveAccountBalance>();

        // v3.0.5 — per-account countdown of remaining execution-backfill sweeps.
        // Set to BackfillSweepsOnConnect when an account subscribes; the heartbeat
        // decrements it each cycle. The freeze/kill recovery path: a force-killed
        // NT never delivers (via the live OnExecutionUpdate event) the fills that
        // happened while we were dead, but NT reloads them into Account.Executions
        // on reconnect — so we sweep that collection for a bounded window after
        // every (re)subscribe and enqueue anything that was missed.
        private readonly ConcurrentDictionary<Account, int> backfillSweepsRemaining =
            new ConcurrentDictionary<Account, int>();

        #endregion

        #region Public API surface (UI + orchestrator)

        public bool IsEnabled => SyncSettings.Enabled;
        public string SyncFolder => JournifiNTPaths.SyncDir;
        public IEnumerable<string> GetMonitoredAccounts()
        {
            lock (subscribedAccountsLock)
                return subscribedAccounts.Keys.Select(a => a.Name).ToList();
        }

        /// <summary>
        /// Toggle the sync master switch. Persists immediately via the
        /// shared settings store.
        /// </summary>
        public void SetEnabled(bool enabled)
        {
            SyncSettings.Enabled = enabled;
            Stats.IsRunning = enabled;
            JournifiNTSettingsStore.Save();
            JournifiNTLog.Info("Sync", $"Sync {(enabled ? "enabled" : "disabled")}");

            // v3.0.9 — re-enabling is a CATCH-UP trigger. Any fills that landed
            // while sync was OFF were ignored by OnExecutionUpdate (the IsEnabled
            // gate) but are still in NT's Account.Executions. Re-open a backfill
            // window on every subscribed account so the next heartbeats sweep them
            // back in immediately, instead of waiting up to ~30s for the periodic
            // net. (backfillSweepsRemaining is a ConcurrentDictionary — safe to
            // set under subscribedAccountsLock; no nested lock.)
            if (enabled && initialized)
            {
                int n = 0;
                lock (subscribedAccountsLock)
                {
                    foreach (var account in subscribedAccounts.Keys)
                    {
                        backfillSweepsRemaining[account] = BackfillSweepsOnConnect;
                        n++;
                    }
                }
                if (n > 0)
                    JournifiNTLog.Info("Sync", $"Re-enabled → re-opened execution-backfill windows on {n} account(s) (catch-up sweep).");
            }
        }

        /// <summary>
        /// Toggle one account's sync without affecting others. Persists
        /// immediately via the shared settings store.
        /// </summary>
        public void SetAccountEnabled(string accountName, bool enabled)
        {
            if (string.IsNullOrWhiteSpace(accountName)) return;
            lock (disabledAccountsLock)
            {
                if (enabled) disabledAccounts.Remove(accountName);
                else disabledAccounts.Add(accountName);

                // Mirror into the persisted settings list.
                SyncSettings.DisabledAccounts = disabledAccounts.ToList();
            }
            JournifiNTLog.Info("Sync", $"Account '{accountName}' sync {(enabled ? "enabled" : "disabled")}");
            JournifiNTSettingsStore.Save();
        }

        public bool IsAccountEnabled(string accountName)
        {
            lock (disabledAccountsLock)
            {
                return !disabledAccounts.Contains(accountName);
            }
        }

        /// <summary>
        /// Returns only accounts whose Connection.Status is Connected.
        /// Mirrors v2.0.1's pattern using <c>Connection.Connections</c>.
        /// </summary>
        public IEnumerable<string> GetConnectedAccounts()
        {
            var connected = new List<string>();
            try
            {
                // Snapshot the subscribed set FIRST (under its own lock), then
                // release before taking Connection.Connections — honoring the
                // never-nest lock-order contract.
                List<Account> snapshot;
                lock (subscribedAccountsLock)
                    snapshot = subscribedAccounts.Keys.ToList();

                lock (Connection.Connections)
                {
                    var liveConns = Connection.Connections
                        .Where(c => c.Status == ConnectionStatus.Connected)
                        .ToList();
                    foreach (var account in snapshot)
                    {
                        if (liveConns.Any(c => c.Accounts.Contains(account)))
                            connected.Add(account.Name);
                    }
                }
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("Sync", $"GetConnectedAccounts: {ex.Message}");
            }
            return connected;
        }

        /// <summary>Refresh in-memory disabled-account set from the settings store.</summary>
        public void ReloadSettings()
        {
            lock (disabledAccountsLock)
            {
                disabledAccounts = new HashSet<string>(
                    SyncSettings.DisabledAccounts ?? new List<string>(),
                    StringComparer.OrdinalIgnoreCase);
            }
            JournifiNTLog.Info("Sync",
                $"Settings reloaded ({disabledAccounts.Count} disabled account(s)).");
        }

        #endregion

        #region Lifecycle (called by orchestrator)

        /// <summary>
        /// Bring the module up: subscribe to account events, start the
        /// export processor + heartbeat. Idempotent (safe to call again
        /// after a Cleanup → re-enter into Active state).
        /// </summary>
        public void Initialize()
        {
            if (initialized)
            {
                JournifiNTLog.Warn("Sync", "Initialize called twice — ignoring second call.");
                return;
            }

            try
            {
                if (!Directory.Exists(JournifiNTPaths.SyncDir))
                    Directory.CreateDirectory(JournifiNTPaths.SyncDir);

                ReloadSettings();

                JournifiNTLog.Info("Sync", $"Output folder: {JournifiNTPaths.SyncDir}");
                JournifiNTLog.Info("Sync", "Optimizations: ATM cache, batch export, adaptive polling.");

                // Subscribe to NT's account status feed + every currently-known account.
                Account.AccountStatusUpdate += OnAccountStatusUpdate;
                foreach (Account account in Account.All)
                    SubscribeToAccount(account);

                // Start export processor.
                cts = new CancellationTokenSource();
                exportTask = Task.Run(() => ExportProcessorLoop(cts.Token));

                StartHeartbeat();

                Stats.IsRunning = true;
                Stats.StartTime = DateTime.Now;
                initialized = true;
                JournifiNTLog.Info("Sync", "Module initialized successfully.");
            }
            catch (Exception ex)
            {
                JournifiNTLog.Error("Sync", "Initialization failed", ex);
            }
        }

        /// <summary>
        /// Tear down cleanly: unsubscribe events, stop processor, flush
        /// any pending records before returning. Bounded shutdown wait
        /// (3s) so NT teardown isn't blocked by a stuck task.
        /// </summary>
        public void Cleanup()
        {
            if (!initialized) return;

            try
            {
                JournifiNTLog.Info("Sync", "Module shutting down...");
                cts?.Cancel();
                try { exportTask?.Wait(TimeSpan.FromSeconds(3)); } catch { /* bounded */ }

                List<Account> toUnsubscribe;
                lock (subscribedAccountsLock)
                    toUnsubscribe = subscribedAccounts.Keys.ToList();
                foreach (var account in toUnsubscribe)
                    UnsubscribeFromAccount(account);
                lock (subscribedAccountsLock)
                    subscribedAccounts.Clear();

                Account.AccountStatusUpdate -= OnAccountStatusUpdate;
                livePositions.Clear();   // v3.0.3 — drop the position mirror on teardown
                backfillSweepsRemaining.Clear();   // v3.0.5 — drop backfill windows on teardown

                StopHeartbeat();

                int total = Stats.AtmCacheHits + Stats.AtmCacheMisses;
                double rate = total > 0 ? (Stats.AtmCacheHits * 100.0 / total) : 0;
                JournifiNTLog.Info("Sync",
                    $"ATM cache: {Stats.AtmCacheHits} hits, {Stats.AtmCacheMisses} misses ({rate:F1}%). " +
                    $"Total execs: {Stats.ExecutionCount}, exports: {Stats.ExportCount}.");

                Stats.IsRunning = false;
                cts?.Dispose();
                initialized = false;
            }
            catch (Exception ex)
            {
                JournifiNTLog.Error("Sync", "Cleanup error", ex);
            }
        }

        #endregion

        #region Account subscription

        private void OnAccountStatusUpdate(object sender, AccountStatusEventArgs e)
        {
            if (e.Status == ConnectionStatus.Connected) SubscribeToAccount(e.Account);
            else if (e.Status == ConnectionStatus.Disconnected) UnsubscribeFromAccount(e.Account);
        }

        /// <summary>
        /// v3.0.1 — periodic safety sweep over <see cref="Account.All"/>,
        /// subscribing any connected account not yet monitored. This is the
        /// fix for the "Sim trade captured with no entry" bug:
        ///
        /// NT only raises <c>Account.AccountStatusUpdate</c> on a connection
        /// STATE transition (Disconnected → Connected). A Sim account CREATED
        /// MID-SESSION is born into the internal Simulator connection, which is
        /// already Connected — so no status event fires, and the account isn't
        /// in the <see cref="Account.All"/> snapshot taken at Initialize. The
        /// old code therefore never subscribed it: its entry fills were missed
        /// and only later exits captured, producing a "phantom" trade that
        /// starts mid-position (e.g. an opening Sell at position 0 mis-read as
        /// a fresh short). The journal-side fix (v7.6.9) handles the symptom;
        /// this closes it at the source.
        ///
        /// Runs off the 2s heartbeat timer, so a new account is picked up
        /// within ~2s of creation. <see cref="SubscribeToAccount"/> is
        /// idempotent, so repeated calls are cheap no-ops for already-monitored
        /// accounts.
        /// </summary>
        private void RescanAccounts()
        {
            if (!initialized) return;
            try
            {
                foreach (Account account in Account.All)
                    SubscribeToAccount(account);
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("Sync", $"Account rescan: {ex.Message}");
            }
        }

        private void SubscribeToAccount(Account account)
        {
            if (account == null) return;

            // Benign fast-path: already monitored. Re-checked under lock below.
            lock (subscribedAccountsLock)
            {
                if (subscribedAccounts.ContainsKey(account)) return;
            }

            try
            {
                // Connection check holds ONLY Connection.Connections (never
                // nested with subscribedAccountsLock — see the lock-order
                // contract on the field declaration).
                bool isConnected;
                lock (Connection.Connections)
                {
                    isConnected = Connection.Connections
                        .Where(c => c.Status == ConnectionStatus.Connected)
                        .Any(c => c.Accounts.Contains(account));
                }
                if (!isConnected) return;

                string connectionName = account.Connection?.Options?.Name ?? "Unknown";

                lock (subscribedAccountsLock)
                {
                    // Re-check: another thread (status event vs rescan sweep)
                    // may have subscribed between the fast-path and here.
                    if (subscribedAccounts.ContainsKey(account)) return;
                    account.ExecutionUpdate += OnExecutionUpdate;
                    account.PositionUpdate += OnPositionUpdate;
                    account.AccountItemUpdate += OnAccountItemUpdate;   // v3.0.6 — broker balances
                    subscribedAccounts[account] = true;
                    Stats.AccountCount = subscribedAccounts.Count;
                    // v3.0.5 — open a bounded execution-backfill window for this
                    // (re)subscribe so the heartbeat sweeps Account.Executions and
                    // recovers any fills missed while we were down/disconnected.
                    backfillSweepsRemaining[account] = BackfillSweepsOnConnect;
                }

                // v3.0.7 — seed the broker-balance mirror immediately so a flat /
                // idle account (which won't fire AccountItemUpdate until it next
                // trades or the market ticks its position) still reports its balance
                // right away, instead of being absent from accountBalances[] until
                // then. The AccountItemUpdate stream keeps it fresh thereafter.
                SeedAccountBalance(account);

                JournifiNTLog.Info("Sync", $"[+] Subscribed: {account.Name} ({connectionName})");
            }
            catch (Exception ex)
            {
                JournifiNTLog.Error("Sync", $"Subscribe failed for {account.Name}", ex);
            }
        }

        private void UnsubscribeFromAccount(Account account)
        {
            if (account == null) return;
            try
            {
                bool removed = false;
                lock (subscribedAccountsLock)
                {
                    if (subscribedAccounts.ContainsKey(account))
                    {
                        account.ExecutionUpdate -= OnExecutionUpdate;
                        account.PositionUpdate -= OnPositionUpdate;
                        account.AccountItemUpdate -= OnAccountItemUpdate;   // v3.0.6
                        subscribedAccounts.Remove(account);
                        backfillSweepsRemaining.TryRemove(account, out _);
                        liveBalances.TryRemove(account.Name, out _);        // drop stale broker balance
                        Stats.AccountCount = subscribedAccounts.Count;
                        removed = true;
                    }
                }
                if (removed)
                    JournifiNTLog.Info("Sync", $"[-] Unsubscribed: {account.Name}");
            }
            catch (Exception ex)
            {
                JournifiNTLog.Error("Sync", $"Unsubscribe failed for {account.Name}", ex);
            }
        }

        #endregion

        #region Execution event handlers

        private void OnExecutionUpdate(object sender, ExecutionEventArgs e)
        {
            if (!IsEnabled) return;
            SafeExecute(() => TryCaptureExecution(sender as Account, e.Execution, fromBackfill: false));
        }

        /// <summary>
        /// Build + enqueue one execution record. SHARED by the live event path
        /// (OnExecutionUpdate) and the catch-up sweep (BackfillExecutions) so the
        /// wire format can never drift between them. Dedup is an ATOMIC claim via
        /// processedExecutions.TryAdd: the data thread (live event) and the
        /// heartbeat thread (backfill sweep) can race on the same ExecutionId and
        /// exactly one wins — the loser is a no-op. Returns true if newly enqueued.
        /// </summary>
        private bool TryCaptureExecution(Account account, Execution execution, bool fromBackfill)
        {
            // v3.0.8 — drop ONLY when we truly can't build a usable record: no
            // instrument, or no exchange execId. We NO LONGER drop on a null
            // Order. Per NT docs, "not all executions have an associated Order
            // object (e.g. ExitOnSessionClose or AtmStrategyCreate())", and a
            // provider-loaded backfill execution can also arrive Order-less. The
            // pre-v3.0.8 guard silently discarded those fills (no [Sync.Exec] /
            // [Sync.Backfill] line at all), which lost a real Buy 1 @30048 on
            // 052067 (~$1.2k). Everything the journal's signed position-walk
            // needs is available directly on the Execution; the Order-only
            // fields fall back below.
            if (execution?.Instrument == null) return false;
            if (account != null && !IsAccountEnabled(account.Name)) return false;

            string execId = execution.ExecutionId;
            if (string.IsNullOrEmpty(execId)) return false;

            // May be null — NT: "not all executions have an associated Order"
            // (ExitOnSessionClose / AtmStrategyCreate); provider-loaded backfill
            // fills can be Order-less too.
            Order order = execution.Order;

            // Resolve the fill SIDE up front, BEFORE claiming the execId. Order
            // present → its exact OrderAction (Buy/Sell/BuyToCover/SellShort).
            // Order null → derive from the execution's own MarketPosition (NT:
            // "the position of THIS fill", always Long|Short for a real fill),
            // so Long => Buy-side, Short => Sell-side. The consumer's isBuyAction/
            // isSellAction treat Buy≡BuyToCover and Sell≡SellShort, so the SIGN
            // the position-walk needs is exact; only the (unused) cover/short
            // nuance is lost. If neither resolves the side (impossible per NT
            // docs), FAIL LOUD and DON'T claim the execId — a later Order-bearing
            // re-fire of the same ExecutionId can still capture it. We never
            // GUESS a sign that drives P&L.
            string action;
            if (order != null)
                action = order.OrderAction.ToString();
            else if (execution.MarketPosition == MarketPosition.Long)
                action = "Buy";
            else if (execution.MarketPosition == MarketPosition.Short)
                action = "Sell";
            else
            {
                JournifiNTLog.Warn(fromBackfill ? "Sync.Backfill" : "Sync.Exec",
                    $"Skipped Order-less fill with unresolved side (MarketPosition={execution.MarketPosition}) | " +
                    $"{account?.Name} | {execution.Instrument.FullName} | qty {execution.Quantity} @ {execution.Price} | execId {execId}");
                return false;
            }

            // v3.0.8 — belt: NT Executions are real fills (qty > 0). Guards a
            // hypothetical provider-loaded zero/negative synthetic from entering
            // the signed position-walk.
            if (execution.Quantity <= 0) return false;

            // Atomic dedup-claim. TryAdd returns false if already processed —
            // replaces the old check-then-set, which could double-process under
            // the new live-event-vs-backfill-sweep race.
            if (!processedExecutions.TryAdd(execId, true)) return false;

            // GetOrderOriginCached already null-guards a null order (returns a
            // "Manual" origin); the Order-derived record fields fall back below.
            OrderOrigin origin = GetOrderOriginCached(account, order, execution.Instrument);

            var record = new JournifiSyncNTExecutionRecord
            {
                ExecutionId = execId,
                Timestamp = execution.Time,
                AccountName = account?.Name ?? "Unknown",
                // v3.0.10 — the data provider this fill came through. Empty (not
                // "Unknown") when unresolvable, so the journal can tell "no
                // connection reported" from a provider literally named Unknown.
                ConnectionName = JsonSafeConnectionName(account),
                InstrumentName = execution.Instrument.FullName,
                // Resolved above: Order.OrderAction, or the MarketPosition side
                // for Order-less fills (never guessed — unresolved side bails).
                Action = action,
                Quantity = execution.Quantity,
                Price = execution.Price,
                // Order-only metadata; "Unknown" when the Order is absent (the
                // position-walk never reads these — display / analytics only).
                OrderType = order != null ? order.OrderType.ToString() : "Unknown",
                OrderState = order != null ? order.OrderState.ToString() : "Unknown",
                // Execution.OrderId is a direct string property (present even
                // when the Order object is not), so fall back to it.
                OrderId = order != null ? order.OrderId : (execution.OrderId ?? ""),
                AtmTemplate = origin.AtmTemplate,
                // Non-empty ONLY for automated NinjaScript strategies (e.g.
                // "AlphaEMA"). Empty for manual + ATM-managed manual fills.
                Strategy = origin.StrategyName,
                Commission = execution.Commission,
                TickSize = execution.Instrument.MasterInstrument.TickSize,
                PointValue = execution.Instrument.MasterInstrument.PointValue
            };

            pendingExports.Enqueue(record);
            Interlocked.Increment(ref Stats.executionCount);
            Stats.LastExecutionTime = DateTime.Now;

            string side = record.Action.Contains("Buy") ? "BUY" : "SELL";
            string originLabel = string.IsNullOrEmpty(record.Strategy)
                ? $"ATM: {record.AtmTemplate}"
                : $"Strategy: {record.Strategy} (automated)";
            JournifiNTLog.Info(fromBackfill ? "Sync.Backfill" : "Sync.Exec",
                $"[{side}]{(fromBackfill ? " (recovered)" : "")} {record.AccountName} | {record.InstrumentName} | " +
                $"{record.Action} {record.Quantity} @ {record.Price} | {record.OrderType} | {originLabel}");

            // v3.0.4+ — execution-driven auto-roll: tell the Bars module which
            // contract is being traded so its bar subscription rolls itself each
            // quarter (MNQM6->MNQU6). Futures only; fire-and-forget so a bars
            // hiccup can never break execution capture (NoteTradedContract is
            // itself fully try-wrapped). Same-assembly static, so Instance
            // resolves without the cross-assembly Bridge the UI tabs need.
            try
            {
                var masterInstrument = execution.Instrument.MasterInstrument;
                if (masterInstrument != null && masterInstrument.InstrumentType == InstrumentType.Future)
                    JournifiSyncNT.Instance?.Bars?.NoteTradedContract(execution.Instrument);
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("Sync.Exec", $"auto-roll note failed: {ex.Message}");
            }

            return true;
        }

        /// <summary>
        /// v3.0.5 — replay an account's existing executions from NT's own
        /// Account.Executions collection, enqueuing any not already processed.
        /// This is the freeze/kill recovery path: when NT is force-killed (End
        /// Task) or the AddOn restarts mid-session, fills that happened while we
        /// weren't listening are NEVER delivered via the live OnExecutionUpdate
        /// event. But NT re-fetches the session's executions from the provider on
        /// reconnect, so Account.Executions holds them — we just sweep it. Dedup
        /// is layered + safe: processedExecutions.TryAdd skips anything already
        /// seen, and ExportBatchToFile dedups against the on-disk ExecutionIds, so
        /// even an evicted-then-re-swept exec is a no-op, never a duplicate.
        /// Snapshots Account.Executions under its own lock (same pattern the
        /// order-origin lookup uses for account.Strategies / strategy.Orders),
        /// then releases BEFORE building records (so the strategy-lookup lock is
        /// never nested inside the executions lock).
        /// </summary>
        private void BackfillExecutions(Account account)
        {
            if (account == null || !IsEnabled) return;
            if (!IsAccountEnabled(account.Name)) return;
            try
            {
                List<Execution> snapshot;
                lock (account.Executions)
                    snapshot = account.Executions.ToList();

                int recovered = 0;
                foreach (Execution execution in snapshot)
                    if (TryCaptureExecution(account, execution, fromBackfill: true))
                        recovered++;

                if (recovered > 0)
                    JournifiNTLog.Info("Sync.Backfill",
                        $"Recovered {recovered} missed execution(s) from {account.Name} (catch-up sweep).");
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("Sync.Backfill", $"Backfill {account?.Name}: {ex.Message}");
            }
        }

        /// <summary>
        /// v3.0.5 — heartbeat-driven drain of the per-account backfill windows.
        /// For each subscribed account with sweeps remaining, run one
        /// BackfillExecutions pass and decrement. Bounded by design: after
        /// BackfillSweepsOnConnect cycles the window closes and live events carry
        /// the load alone (no perpetual Account.Executions re-scan / file-rewrite
        /// churn). Snapshots the account list under subscribedAccountsLock, then
        /// calls BackfillExecutions OUTSIDE it (BackfillExecutions takes the
        /// account.Executions + account.Strategies locks — never nested with
        /// subscribedAccountsLock, per the lock-order contract).
        /// </summary>
        private void BackfillSweep()
        {
            if (!initialized) return;
            try
            {
                List<Account> targets;
                lock (subscribedAccountsLock)
                    targets = subscribedAccounts.Keys.ToList();

                // v3.0.6 — on every PeriodicResyncEveryBeats-th beat, ALSO sweep
                // accounts with no active reconnect window (the normal-operation
                // safety net). Off-beats behave exactly as before: drain only the
                // bounded post-reconnect windows.
                bool periodic = (System.Threading.Interlocked.Increment(ref backfillBeatCounter)
                                 % PeriodicResyncEveryBeats) == 0;

                foreach (var account in targets)
                {
                    bool hasWindow = backfillSweepsRemaining.TryGetValue(account, out int remaining) && remaining > 0;
                    if (hasWindow)
                    {
                        BackfillExecutions(account);
                        if (remaining <= 1) backfillSweepsRemaining.TryRemove(account, out _);
                        else backfillSweepsRemaining[account] = remaining - 1;
                    }
                    else if (periodic)
                    {
                        BackfillExecutions(account);   // periodic catch-up safety net
                    }
                }

                // v3.0.9 — observability: the periodic net is otherwise SILENT
                // when it recovers nothing, so a stalled sweep is invisible (this
                // is exactly why the 2026-07-10 15:28 capture gap couldn't be
                // diagnosed). One concise line per ~30s proves the heartbeat sweep
                // actually fired; recovered fills still log their own lines.
                if (periodic && targets.Count > 0)
                    JournifiNTLog.Info("Sync.Backfill", $"Periodic resync fired — swept {targets.Count} subscribed account(s).");
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("Sync.Backfill", $"Backfill sweep: {ex.Message}");
            }
        }

        private void OnPositionUpdate(object sender, PositionEventArgs e)
        {
            if (!IsEnabled) return;
            SafeExecute(() =>
            {
                Position position = e.Position;
                if (position?.Instrument == null) return;
                Account account = sender as Account;
                string acctName = account?.Name ?? "Unknown";
                string instr = position.Instrument.FullName;
                string key = acctName + "|" + instr;

                // v3.0.3 — maintain the live-position mirror. NT docs (and the
                // AddOn dev reference) say the EVENT-ARG values (e.Quantity /
                // e.MarketPosition / e.AveragePrice) are the accurate post-update
                // state, so we trust those over the Position object's fields.
                // A flat position removes its key so the journal reads "absent ==
                // flat" deterministically.
                bool flat = e.MarketPosition == MarketPosition.Flat || e.Quantity == 0;
                if (flat)
                {
                    livePositions.TryRemove(key, out _);
                }
                else
                {
                    livePositions[key] = new LivePositionState
                    {
                        AccountName = acctName,
                        Instrument = instr,
                        MarketPosition = e.MarketPosition.ToString(),
                        Quantity = Math.Abs(e.Quantity),
                        AvgPrice = e.AveragePrice,
                        UpdatedAtUtc = DateTime.UtcNow
                    };
                }

                string status = flat ? "CLOSED"
                    : (e.MarketPosition == MarketPosition.Long ? "Long" : "Short");
                JournifiNTLog.Info("Sync.Pos",
                    $"{(flat ? "CLOSED" : "OPENED")}: {acctName} | {instr} | {status} x{Math.Abs(e.Quantity)}");
            });
        }

        // v3.0.6 — mirror the three broker balance items the journal's Accounts
        // tab needs (net-liquidation, session realized P&L, cash) from NT's
        // AccountItemUpdate stream into liveBalances. We report NT's RAW values —
        // on Rithmic/Bulenox feeds NetLiquidation is gross of commissions (CQG
        // carries them); the app applies the per-feed commission rule.
        private void OnAccountItemUpdate(object sender, AccountItemEventArgs e)
        {
            if (!IsEnabled) return;
            SafeExecute(() =>
            {
                if (e.AccountItem != AccountItem.NetLiquidation
                    && e.AccountItem != AccountItem.RealizedProfitLoss
                    && e.AccountItem != AccountItem.CashValue)
                    return;

                Account account = sender as Account;
                string acctName = account?.Name;
                if (string.IsNullOrEmpty(acctName)) return;

                var bal = liveBalances.GetOrAdd(acctName, n => new LiveAccountBalance { AccountName = n });
                lock (bal)
                {
                    // v3.0.10 — populate here TOO. This handler has its own
                    // GetOrAdd, so it can create an entry SeedAccountBalance never
                    // touches; seeding the connection in only one of the two sites
                    // leaves those entries reporting a null provider.
                    bal.Connection = JsonSafeConnectionName(account);
                    if (e.AccountItem == AccountItem.NetLiquidation) bal.NetLiquidation = e.Value;
                    else if (e.AccountItem == AccountItem.RealizedProfitLoss) bal.RealizedPnL = e.Value;
                    else if (e.AccountItem == AccountItem.CashValue) bal.CashValue = e.Value;
                    bal.UpdatedAtUtc = DateTime.UtcNow;
                }
            });
        }

        /// <summary>
        /// v3.0.10 — the account's NT connection (data provider) name, made safe
        /// for this file format. Returns "" when unresolvable.
        ///
        /// WHY THE SANITIZE, and why it is not paranoia: this writer's
        /// <c>EscapeJson</c> escapes backslash/quote on WRITE, but
        /// <c>ExtractString</c> does NOT unescape on READ — and
        /// <c>ExportBatchToFile</c> re-reads and re-writes the whole day file on
        /// every batch. So any string field containing a quote is TRUNCATED at
        /// that quote on the next cycle, and a backslash DOUBLES on every cycle,
        /// compounding all session. Connection names are user-authored in NT's
        /// connection dialog, so they are not guaranteed free of either.
        /// Stripping the two characters that break the round-trip keeps this
        /// field stable across the read/write cycle; real provider names
        /// ("Bulenox", "Apex Trader Funding") are unaffected.
        /// </summary>
        private static string JsonSafeConnectionName(Account account)
        {
            try
            {
                string name = account?.Connection?.Options?.Name;
                if (string.IsNullOrEmpty(name)) return "";
                return name.Replace("\\", "").Replace("\"", "");
            }
            catch { return ""; }
        }

        // v3.0.7 — read the account's current broker balances directly at subscribe
        // time (Account.Get), so flat/idle accounts have a value before their first
        // AccountItemUpdate. Values default to 0 pre-connection; the event stream
        // corrects them. Its own try/catch — a Get() hiccup never blocks subscribe.
        private void SeedAccountBalance(Account account)
        {
            if (account == null) return;
            SafeExecute(() =>
            {
                var bal = liveBalances.GetOrAdd(account.Name, n => new LiveAccountBalance { AccountName = n });
                lock (bal)
                {
                    // v3.0.10 — set INSIDE the lock, not in the GetOrAdd factory:
                    // the factory only runs when the entry is created, so a
                    // factory-only assignment would never refresh an entry that
                    // OnAccountItemUpdate created first, nor follow a reconnect
                    // onto a different provider.
                    bal.Connection     = JsonSafeConnectionName(account);
                    bal.NetLiquidation = account.Get(AccountItem.NetLiquidation, Currency.UsDollar);
                    bal.RealizedPnL    = account.Get(AccountItem.RealizedProfitLoss, Currency.UsDollar);
                    bal.CashValue      = account.Get(AccountItem.CashValue, Currency.UsDollar);
                    bal.UpdatedAtUtc   = DateTime.UtcNow;
                }
            });
        }

        #endregion

        #region ATM template lookup + cache

        /// <summary>
        /// Where an order came from. ATM template and strategy name are
        /// mutually exclusive: an ATM-managed manual trade has a non-empty
        /// <see cref="AtmTemplate"/> and no <see cref="StrategyName"/>; an
        /// automated NinjaScript strategy has an empty Template (so we capture
        /// its Name instead). A plain manual fill is AtmTemplate="Manual".
        /// </summary>
        private struct OrderOrigin
        {
            public string AtmTemplate;    // "Manual", a template name, or "" (automated)
            public string StrategyName;   // non-empty ONLY for automated strategies

            public OrderOrigin(string atmTemplate, string strategyName)
            {
                AtmTemplate = atmTemplate;
                StrategyName = strategyName;
            }
        }

        private OrderOrigin GetOrderOriginCached(Account account, Order order, Instrument instrument)
        {
            if (order == null || account == null) return new OrderOrigin("Manual", null);

            string orderId = order.OrderId;
            if (atmTemplateCache.TryGetValue(orderId, out OrderOrigin cached))
            {
                Interlocked.Increment(ref Stats.atmCacheHits);
                return cached;
            }
            Interlocked.Increment(ref Stats.atmCacheMisses);
            OrderOrigin origin = LookupOrderOrigin(account, order, instrument);
            atmTemplateCache[orderId] = origin;

            if (DateTime.UtcNow - lastCachePrune > CachePruneInterval)
                PruneCache();
            return origin;
        }

        private OrderOrigin LookupOrderOrigin(Account account, Order order, Instrument instrument)
        {
            try
            {
                lock (account.Strategies)
                {
                    foreach (StrategyBase strategy in account.Strategies)
                    {
                        if (strategy == null || strategy.State != State.Realtime) continue;
                        if (strategy.Instruments == null || strategy.Instruments.Length == 0) continue;
                        if (instrument != null && strategy.Instruments[0].FullName != instrument.FullName) continue;

                        if (strategy.Orders != null)
                        {
                            lock (strategy.Orders)
                            {
                                foreach (Order stratOrder in strategy.Orders)
                                {
                                    if (stratOrder != null && stratOrder.OrderId == order.OrderId)
                                    {
                                        // An ATM-managed (manual) trade carries a
                                        // non-empty ATM Template. An automated
                                        // NinjaScript strategy has an empty Template
                                        // — so when Template is blank we capture the
                                        // strategy's Name as the automation tag.
                                        // (NT docs: StrategyBase.Template = ATM
                                        // template name; .Name = configured strategy
                                        // name. The previous `Template ?? Name`
                                        // returned the empty string for automation
                                        // because "" is non-null, so Name never won.)
                                        string tmpl = strategy.Template;
                                        if (!string.IsNullOrEmpty(tmpl))
                                            return new OrderOrigin(tmpl, null);
                                        return new OrderOrigin("", strategy.Name);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("Sync", $"Order-origin lookup: {ex.Message}");
            }
            return new OrderOrigin("Manual", null);
        }

        private void PruneCache()
        {
            if (atmTemplateCache.Count > MaxCacheSize)
            {
                int removeCount = atmTemplateCache.Count / 2;
                var keysToRemove = atmTemplateCache.Keys.Take(removeCount).ToList();
                foreach (var key in keysToRemove)
                    atmTemplateCache.TryRemove(key, out _);
                JournifiNTLog.Info("Sync", $"ATM cache pruned: removed {removeCount} entries.");
            }

            // v3.0.1 — bound the processed-executions dedup set too. It
            // previously grew unbounded for the entire NT session (only the
            // ATM cache was pruned). Evicting arbitrary entries is safe:
            // ExportBatchToFile dedups against the on-disk file's ExecutionIds,
            // so the worst case for an evicted-then-re-emitted exec is a no-op
            // re-process — never a duplicate in the output file.
            if (processedExecutions.Count > MaxProcessedExecutions)
            {
                int removeCount = processedExecutions.Count / 2;
                var idsToRemove = processedExecutions.Keys.Take(removeCount).ToList();
                foreach (var id in idsToRemove)
                    processedExecutions.TryRemove(id, out _);
                JournifiNTLog.Info("Sync", $"Processed-exec set pruned: removed {removeCount} entries.");
            }

            lastCachePrune = DateTime.UtcNow;
        }

        #endregion

        #region Export processor + atomic file writes

        private async Task ExportProcessorLoop(CancellationToken ct)
        {
            JournifiNTLog.Info("Sync", "Export processor started (batch mode).");
            var batch = new List<JournifiSyncNTExecutionRecord>(MaxBatchSize);

            while (!ct.IsCancellationRequested)
            {
                try
                {
                    batch.Clear();
                    DateTime batchStart = DateTime.UtcNow;
                    while (pendingExports.TryDequeue(out var record))
                    {
                        batch.Add(record);
                        if (batch.Count >= MaxBatchSize) break;
                        if ((DateTime.UtcNow - batchStart).TotalMilliseconds > BatchWindowMs) break;
                    }

                    if (batch.Count > 0)
                    {
                        var byDate = batch.GroupBy(r => r.Timestamp.Date);
                        foreach (var dateGroup in byDate)
                            ExportBatchToFile(dateGroup.Key, dateGroup.ToList());
                        Stats.LastExportTime = DateTime.Now;
                    }

                    int delay = batch.Count > 0 ? ActiveDelayMs : IdleDelayMs;
                    await Task.Delay(delay, ct);
                }
                catch (OperationCanceledException) { break; }
                catch (Exception ex)
                {
                    JournifiNTLog.Error("Sync", "Export processor error", ex);
                    try { await Task.Delay(1000, ct); } catch { break; }
                }
            }

            // Final flush — drain anything still queued.
            while (pendingExports.TryDequeue(out var record))
                ExportBatchToFile(record.Timestamp.Date,
                    new List<JournifiSyncNTExecutionRecord> { record });
            JournifiNTLog.Info("Sync", "Export processor stopped.");
        }

        private void ExportBatchToFile(DateTime date, List<JournifiSyncNTExecutionRecord> records)
        {
            string fileName = $"executions_{date:yyyy-MM-dd}.json";
            string filePath = Path.Combine(JournifiNTPaths.SyncDir, fileName);

            lock (fileLock)
            {
                try
                {
                    var existingRecords = new List<JournifiSyncNTExecutionRecord>();
                    if (File.Exists(filePath))
                    {
                        string existing = File.ReadAllText(filePath);
                        existingRecords = DeserializeRecords(existing);
                    }

                    var existingIds = new HashSet<string>(existingRecords.Select(r => r.ExecutionId));
                    int newCount = 0;
                    foreach (var record in records)
                    {
                        if (!existingIds.Contains(record.ExecutionId))
                        {
                            existingRecords.Add(record);
                            newCount++;
                        }
                    }

                    // v3.0.5 — skip the rewrite when the batch added nothing new
                    // (every record already on disk). The bounded backfill sweep
                    // re-presents already-exported fills by design; without this
                    // guard each sweep would atomically rewrite the day file with
                    // byte-identical content. Nothing new => nothing to persist.
                    if (newCount == 0) return;

                    // v3.0.1 — durable atomic write via the shared chokepoint.
                    // The old delete-then-Move pattern had a crash window that
                    // could destroy the WHOLE day's executions (the file is
                    // fully rewritten each batch, so a half-completed rename
                    // left only the unread .tmp and the next batch restarted
                    // from empty). File.Replace under the helper is atomic.
                    string json = SerializeRecordsOptimized(existingRecords);
                    JournifiNTIO.AtomicWriteAllText(filePath, json);

                    Interlocked.Add(ref Stats.exportCount, newCount);
                }
                catch (Exception ex)
                {
                    JournifiNTLog.Error("Sync", $"Export to {fileName} failed", ex);
                }
            }
        }

        #endregion

        #region JSON serializer/deserializer (StringBuilder pool)

        private string SerializeRecordsOptimized(List<JournifiSyncNTExecutionRecord> records)
        {
            jsonBuilder.Clear();
            int estimatedSize = records.Count * 600;
            if (jsonBuilder.Capacity < estimatedSize)
                jsonBuilder.EnsureCapacity(estimatedSize);

            jsonBuilder.Append("[\n");
            for (int i = 0; i < records.Count; i++)
            {
                var r = records[i];
                jsonBuilder.Append("  {\n");
                AppendField("ExecutionId", r.ExecutionId);
                AppendField("Timestamp", r.Timestamp.ToString("o"));
                AppendField("AccountName", r.AccountName);
                // v3.0.10. DELIBERATELY placed here and not at the end:
                // AppendNumberLast("PointValue") below is the only emitter that
                // omits the trailing comma, so it must remain the LAST call.
                // Appending after it yields invalid JSON — and since the journal
                // parses executions_*.json with a real JSON parser, one malformed
                // object costs the ENTIRE DAY FILE, not one field.
                AppendField("ConnectionName", r.ConnectionName);
                AppendField("InstrumentName", r.InstrumentName);
                AppendField("Action", r.Action);
                AppendNumber("Quantity", r.Quantity);
                AppendNumber("Price", r.Price);
                AppendField("OrderType", r.OrderType);
                AppendField("OrderState", r.OrderState);
                AppendField("OrderId", r.OrderId);
                AppendField("AtmTemplate", r.AtmTemplate);
                AppendField("Strategy", r.Strategy);
                AppendNumber("Commission", r.Commission);
                AppendNumber("TickSize", r.TickSize);
                AppendNumberLast("PointValue", r.PointValue);
                jsonBuilder.Append("  }");
                if (i < records.Count - 1) jsonBuilder.Append(",");
                jsonBuilder.Append("\n");
            }
            jsonBuilder.Append("]");
            return jsonBuilder.ToString();
        }

        private void AppendField(string name, string value)
        {
            jsonBuilder.Append("    \"").Append(name).Append("\": \"")
                       .Append(EscapeJson(value ?? "")).Append("\",\n");
        }
        private void AppendNumber(string name, double value)
        {
            jsonBuilder.Append("    \"").Append(name).Append("\": ")
                       .Append(value.ToString(CultureInfo.InvariantCulture)).Append(",\n");
        }
        private void AppendNumberLast(string name, double value)
        {
            jsonBuilder.Append("    \"").Append(name).Append("\": ")
                       .Append(value.ToString(CultureInfo.InvariantCulture)).Append("\n");
        }
        private static string EscapeJson(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("\\", "\\\\").Replace("\"", "\\\"")
                    .Replace("\n", "\\n").Replace("\r", "\\r").Replace("\t", "\\t");
        }

        private List<JournifiSyncNTExecutionRecord> DeserializeRecords(string json)
        {
            var records = new List<JournifiSyncNTExecutionRecord>();
            if (string.IsNullOrWhiteSpace(json) || !json.TrimStart().StartsWith("["))
                return records;
            try
            {
                int depth = 0;
                int objStart = -1;
                for (int i = 0; i < json.Length; i++)
                {
                    char c = json[i];
                    if (c == '{')
                    {
                        if (depth == 0) objStart = i;
                        depth++;
                    }
                    else if (c == '}')
                    {
                        depth--;
                        if (depth == 0 && objStart >= 0)
                        {
                            string objJson = json.Substring(objStart, i - objStart + 1);
                            var record = ParseRecord(objJson);
                            if (record != null) records.Add(record);
                            objStart = -1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("Sync", $"JSON parse: {ex.Message}");
            }
            return records;
        }

        private static JournifiSyncNTExecutionRecord ParseRecord(string json)
        {
            try
            {
                return new JournifiSyncNTExecutionRecord
                {
                    ExecutionId = ExtractString(json, "ExecutionId"),
                    Timestamp = DateTime.Parse(ExtractString(json, "Timestamp"),
                        CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind),
                    AccountName = ExtractString(json, "AccountName"),
                    // v3.0.10. ExtractString returns "" for an absent key and
                    // cannot throw, which matters more than it looks: this whole
                    // initializer sits inside `catch { return null; }`, a null
                    // record is dropped by DeserializeRecords, and ExportBatchToFile
                    // then REWRITES the day file from that filtered list — so a
                    // throwing extraction does not skip a fill, it ERASES it from
                    // disk. Never add an extraction here that can throw.
                    //
                    // Rows written by an older AddOn legitimately lack this key and
                    // parse as "" — correct, and unavoidable: a new wire field is
                    // not retroactive. Rows already on disk only gain it when
                    // another new fill lands for that same date, and past dates
                    // never do. The journal must treat it as per-ROW optional.
                    ConnectionName = ExtractString(json, "ConnectionName"),
                    InstrumentName = ExtractString(json, "InstrumentName"),
                    Action = ExtractString(json, "Action"),
                    Quantity = (int)ExtractNumber(json, "Quantity"),
                    Price = ExtractNumber(json, "Price"),
                    OrderType = ExtractString(json, "OrderType"),
                    OrderState = ExtractString(json, "OrderState"),
                    OrderId = ExtractString(json, "OrderId"),
                    AtmTemplate = ExtractString(json, "AtmTemplate"),
                    Strategy = ExtractString(json, "Strategy"),
                    Commission = ExtractNumber(json, "Commission"),
                    TickSize = ExtractNumber(json, "TickSize"),
                    PointValue = ExtractNumber(json, "PointValue"),
                };
            }
            catch { return null; }
        }

        private static string ExtractString(string json, string key)
        {
            string pattern = $"\"{key}\": \"";
            int start = json.IndexOf(pattern);
            if (start < 0) return "";
            start += pattern.Length;
            int end = json.IndexOf("\"", start);
            return end < 0 ? "" : json.Substring(start, end - start);
        }
        private static double ExtractNumber(string json, string key)
        {
            string pattern = $"\"{key}\": ";
            int start = json.IndexOf(pattern);
            if (start < 0) return 0;
            start += pattern.Length;
            int end = start;
            while (end < json.Length && (char.IsDigit(json[end]) || json[end] == '.' || json[end] == '-'))
                end++;
            return double.TryParse(json.Substring(start, end - start),
                NumberStyles.Float, CultureInfo.InvariantCulture, out double r) ? r : 0;
        }

        #endregion

        #region Heartbeat

        // ninjatrader_heartbeat.json — written every 2s under JournifiSync\.
        // The Journifi AI desktop app uses this file's mtime to display the
        // "JournifiSync is connected" green dot. Same format/path as v2.0.1.
        private const string HeartbeatFileName = "ninjatrader_heartbeat.json";

        private void StartHeartbeat()
        {
            try
            {
                WriteHeartbeat(null);
                heartbeatTimer = new System.Threading.Timer(WriteHeartbeat, null,
                    HeartbeatIntervalMs, HeartbeatIntervalMs);
                JournifiNTLog.Info("Sync", "Heartbeat started.");
            }
            catch (Exception ex)
            {
                JournifiNTLog.Error("Sync", "Heartbeat start failed", ex);
            }
        }

        private void StopHeartbeat()
        {
            try
            {
                heartbeatTimer?.Dispose();
                heartbeatTimer = null;
                string path = Path.Combine(JournifiNTPaths.SyncDir, HeartbeatFileName);
                if (File.Exists(path)) File.Delete(path);
                // v3.0.3 — remove the position snapshot too, so the journal never
                // reconciles against stale broker truth while the AddOn is down.
                string posPath = Path.Combine(JournifiNTPaths.SyncDir, PositionsFileName);
                if (File.Exists(posPath)) File.Delete(posPath);
                JournifiNTLog.Info("Sync", "Heartbeat stopped.");
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("Sync", $"Heartbeat stop: {ex.Message}");
            }
        }

        private void WriteHeartbeat(object _)
        {
            // v3.0.1 — piggyback the account safety-sweep on the 2s heartbeat
            // so accounts created mid-session (esp. new Sim accounts that never
            // fire AccountStatusUpdate) get subscribed within ~2s. RescanAccounts
            // has its own try/catch, so it can't be swallowed by the silent
            // heartbeat catch below.
            RescanAccounts();

            // v3.0.5 — drain bounded execution-backfill windows: sweep each
            // account's Account.Executions for fills missed while we were down,
            // for a few cycles after every (re)subscribe. Has its own try/catch.
            BackfillSweep();

            // v3.0.3 — write the broker-position snapshot on the same 2s cadence.
            // Has its own try/catch so it can't be swallowed by the silent
            // heartbeat catch below, and runs off the timer thread (not the
            // execution hot path).
            WritePositionsSnapshot();

            try
            {
                string path = Path.Combine(JournifiNTPaths.SyncDir, HeartbeatFileName);
                string json = string.Format(CultureInfo.InvariantCulture,
@"{{
  ""app"": ""JournifiSync"",
  ""version"": ""{0}"",
  ""running"": {1},
  ""lastHeartbeat"": ""{2}"",
  ""accountCount"": {3},
  ""executionCount"": {4}
}}",
                    JournifiSyncNT.VERSION,
                    IsEnabled ? "true" : "false",
                    DateTime.UtcNow.ToString("o"),
                    Stats.AccountCount,   // lock-maintained mirror of subscribedAccounts.Count
                    Stats.ExecutionCount);
                File.WriteAllText(path, json);
            }
            catch { /* silent — don't spam logs from a 2s timer */ }
        }

        #endregion

        #region Position snapshot (v3.0.3 — broker-position ground truth)

        // positions_snapshot.json — written every 2s alongside the heartbeat.
        // Gives the journal NT's ACTUAL position per account (mirrored from the
        // PositionUpdate stream into livePositions) so it can reconcile its
        // execution-reconstructed open trades against broker truth:
        //   • journal shows OPEN but the account has no position row here
        //     (and the account IS in "accounts") → stranded/phantom open → auto-resolve;
        //   • a non-flat position row the journal isn't showing → a real lingering
        //     NT position to surface ("you're still short 9 on Sim 02M 09 EMA").
        // READ-ONLY truth — the AddOn never places or modifies orders.
        //
        // Contract: "accounts" lists every account we actively watch (subscribed
        // + sync-enabled). The journal treats "account in accounts but absent from
        // positions" as a CONFIDENT flat, and never auto-resolves an open on an
        // account NOT in "accounts" (no ground truth). The journal must also gate
        // on heartbeat freshness — a stale file means the AddOn is down.
        private const string PositionsFileName = "positions_snapshot.json";

        private void WritePositionsSnapshot()
        {
            if (!IsEnabled) return;
            try
            {
                // Snapshot subscribed account names under their lock, release,
                // THEN filter by enabled (IsAccountEnabled takes its own lock —
                // never nest the two).
                List<string> subNames;
                lock (subscribedAccountsLock)
                    subNames = subscribedAccounts.Keys.Select(a => a.Name).ToList();
                var scanned = subNames.Where(IsAccountEnabled).ToList();
                var scannedSet = new HashSet<string>(scanned, StringComparer.OrdinalIgnoreCase);

                var positions = livePositions.Values
                    .Where(p => p != null && p.AccountName != null && scannedSet.Contains(p.AccountName))
                    .ToList();

                var sb = new StringBuilder(1024);
                sb.Append("{\n");
                sb.Append("  \"app\": \"JournifiSync\",\n");
                sb.Append("  \"version\": \"").Append(JournifiSyncNT.VERSION).Append("\",\n");
                sb.Append("  \"writtenAt\": \"").Append(DateTime.UtcNow.ToString("o")).Append("\",\n");

                sb.Append("  \"accounts\": [");
                for (int i = 0; i < scanned.Count; i++)
                {
                    if (i > 0) sb.Append(", ");
                    sb.Append("\"").Append(EscapeJson(scanned[i])).Append("\"");
                }
                sb.Append("],\n");

                sb.Append("  \"positions\": [");
                for (int i = 0; i < positions.Count; i++)
                {
                    var p = positions[i];
                    sb.Append(i == 0 ? "\n" : ",\n");
                    sb.Append("    {\n");
                    sb.Append("      \"accountName\": \"").Append(EscapeJson(p.AccountName)).Append("\",\n");
                    sb.Append("      \"instrument\": \"").Append(EscapeJson(p.Instrument)).Append("\",\n");
                    sb.Append("      \"marketPosition\": \"").Append(EscapeJson(p.MarketPosition)).Append("\",\n");
                    sb.Append("      \"quantity\": ").Append(p.Quantity.ToString(CultureInfo.InvariantCulture)).Append(",\n");
                    sb.Append("      \"avgPrice\": ").Append(p.AvgPrice.ToString(CultureInfo.InvariantCulture)).Append(",\n");
                    sb.Append("      \"updatedAt\": \"").Append(p.UpdatedAtUtc.ToString("o")).Append("\"\n");
                    sb.Append("    }");
                }
                sb.Append(positions.Count > 0 ? "\n  ],\n" : "],\n");

                // v3.0.6 — per-account broker balances for the scanned accounts
                // that have reported an AccountItemUpdate. The journal prefers
                // these for NT-linked accounts (commission-aware per feed); an
                // account absent here just falls back to the journaled calc.
                var bals = scanned
                    .Select(n => liveBalances.TryGetValue(n, out var b) ? b : null)
                    .Where(b => b != null)
                    .ToList();
                sb.Append("  \"accountBalances\": [");
                for (int i = 0; i < bals.Count; i++)
                {
                    var b = bals[i];
                    double netLiq, realized, cash; DateTime upd; string conn;
                    lock (b) { netLiq = b.NetLiquidation; realized = b.RealizedPnL; cash = b.CashValue; upd = b.UpdatedAtUtc; conn = b.Connection; }
                    sb.Append(i == 0 ? "\n" : ",\n");
                    sb.Append("    {\n");
                    sb.Append("      \"accountName\": \"").Append(EscapeJson(b.AccountName)).Append("\",\n");
                    // v3.0.10 — the data provider. Emitted HERE, before updatedAt:
                    // that line is the last field and deliberately carries no
                    // trailing comma, so anything appended after it breaks the JSON.
                    sb.Append("      \"connection\": \"").Append(EscapeJson(conn ?? "")).Append("\",\n");
                    sb.Append("      \"netLiquidation\": ").Append(netLiq.ToString(CultureInfo.InvariantCulture)).Append(",\n");
                    sb.Append("      \"realizedPnL\": ").Append(realized.ToString(CultureInfo.InvariantCulture)).Append(",\n");
                    sb.Append("      \"cashValue\": ").Append(cash.ToString(CultureInfo.InvariantCulture)).Append(",\n");
                    sb.Append("      \"updatedAt\": \"").Append(upd.ToString("o")).Append("\"\n");
                    sb.Append("    }");
                }
                sb.Append(bals.Count > 0 ? "\n  ]\n" : "]\n");
                sb.Append("}");

                string path = Path.Combine(JournifiNTPaths.SyncDir, PositionsFileName);
                JournifiNTIO.AtomicWriteAllText(path, sb.ToString());
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("Sync", $"Position snapshot: {ex.Message}");
            }
        }

        #endregion

        #region Helpers

        private static void SafeExecute(Action action)
        {
            try { action(); }
            catch (Exception ex) { JournifiNTLog.Error("Sync", "SafeExecute caught", ex); }
        }

        #endregion
    }

    #endregion

    #region Data classes

    /// <summary>
    /// One execution row, the unit the journal's chokidar watcher consumes.
    /// DO NOT add or rename fields without updating tradeProcessor.js too.
    /// Adding fields is backward-compatible (the app's field-targeted parser
    /// ignores unknown keys); <c>Strategy</c> was added in v3.0.2 to tag
    /// automated NinjaScript-strategy fills — empty for manual/ATM trades.
    /// </summary>
    public class JournifiSyncNTExecutionRecord
    {
        public string ExecutionId { get; set; }
        public DateTime Timestamp { get; set; }
        public string AccountName { get; set; }
        /// <summary>
        /// v3.0.10 — RESTORED. The NT connection (data provider) this fill came
        /// through: "Bulenox", "Apex Trader Funding", "NinjaTrader Sim" — the
        /// value shown in NT's Account Data "Connection" column.
        ///
        /// This field existed in JournifiSync v1.0 and was dropped in the v1.2
        /// rewrite. Its two journal-side CONSUMERS were never removed:
        /// tradeProcessor.ts reads `firstEntry.ConnectionName` into
        /// `_journifiSync.connectionName`, and journifiSyncService.js derives
        /// `suggestedBroker` from it. Both have silently read undefined since
        /// 2026-02-24 — 223 trades carry a connection, the 4,465 after that date
        /// do not, and the account-mapping UI has suggested "Unknown" for five
        /// months. Restoring the producer revives both consumers unchanged.
        ///
        /// Why it matters beyond the mapping hint: which firm's feed a fill came
        /// through is the only per-fill evidence of execution quality. Two
        /// accounts filling the same decision through different providers is the
        /// measurement; without this field the fills are indistinguishable.
        /// </summary>
        public string ConnectionName { get; set; }
        public string InstrumentName { get; set; }
        public string Action { get; set; }
        public int Quantity { get; set; }
        public double Price { get; set; }
        public string OrderType { get; set; }
        public string OrderState { get; set; }
        public string OrderId { get; set; }
        public string AtmTemplate { get; set; }
        public string Strategy { get; set; }   // automated-strategy name, or "" (manual/ATM)
        public double Commission { get; set; }
        public double TickSize { get; set; }
        public double PointValue { get; set; }
    }

    /// <summary>
    /// One account's live position in a single instrument, mirrored from NT's
    /// PositionUpdate stream (v3.0.3). Serialized into positions_snapshot.json so
    /// the journal can reconcile reconstructed open trades against broker truth.
    /// Quantity is absolute (sign lives in MarketPosition).
    /// </summary>
    public class LivePositionState
    {
        public string AccountName { get; set; }
        public string Instrument { get; set; }
        public string MarketPosition { get; set; }  // "Long" / "Short"
        public int Quantity { get; set; }            // absolute contract count
        public double AvgPrice { get; set; }
        public DateTime UpdatedAtUtc { get; set; }
    }

    /// <summary>
    /// One account's live broker balances (v3.0.6), mirrored from NT's
    /// AccountItemUpdate stream. Serialized into positions_snapshot.json so the
    /// journal's Accounts tab can show broker truth for NT-linked accounts.
    /// NetLiquidation is NT's raw value — GROSS of commissions on Rithmic/Bulenox
    /// feeds (CQG carries them); the app applies the per-feed commission rule.
    /// </summary>
    public class LiveAccountBalance
    {
        public string AccountName { get; set; }
        /// <summary>
        /// v3.0.10 — the NT connection (data provider) serving this account.
        /// Captured at subscribe/update time because the snapshot writer resolves
        /// balances out of <c>liveBalances</c> BY ACCOUNT NAME and never holds an
        /// NT <c>Account</c> object, so it cannot reach Connection.Options.Name
        /// itself. Lets the journal group accounts by FIRM rather than by account,
        /// which is the axis execution quality actually varies on.
        /// </summary>
        public string Connection { get; set; }
        public double NetLiquidation { get; set; }
        public double RealizedPnL { get; set; }
        public double CashValue { get; set; }
        public DateTime UpdatedAtUtc { get; set; }
    }

    /// <summary>
    /// Stats exposed to the UI. Thread-safe counters live as fields with
    /// <c>internal</c> visibility so the module can <see cref="Interlocked"/>
    /// them; UI reads through the read-only property wrappers.
    /// </summary>
    public class JournifiSyncNTSyncStats
    {
        internal int executionCount;
        internal int exportCount;
        internal int atmCacheHits;
        internal int atmCacheMisses;

        public bool IsRunning { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime LastExecutionTime { get; set; }
        public DateTime LastExportTime { get; set; }
        public int AccountCount { get; set; }

        public int ExecutionCount => executionCount;
        public int ExportCount => exportCount;
        public int AtmCacheHits => atmCacheHits;
        public int AtmCacheMisses => atmCacheMisses;
        public double CacheHitRate
        {
            get
            {
                int total = atmCacheHits + atmCacheMisses;
                return total == 0 ? 0 : (atmCacheHits * 100.0 / total);
            }
        }
    }

    #endregion
}
