﻿#region Using declarations
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using NinjaTrader.NinjaScript;   // PrintTo enum (used by the logger)
#endregion

namespace NinjaTrader.Gui.NinjaScript
{
    // =====================================================================
    //  Shared infrastructure for JournifiSync NT
    // =====================================================================
    //
    //  • Paths       — filesystem layout (one place, no string duplication)
    //  • Settings    — POCO model + hand-rolled JSON serializer
    //  • Store       — singleton Load/Save with atomic temp+rename
    //  • Logger      — interleaved [Sync] / [Bars] log + NT Output mirror
    //  • Cache       — instrument lookup memoization for both modules
    //  • Migrator    — one-shot legacy settings.json reader (v1/v2 → v3)
    //
    //  Everything here is process-static, lazy-initialized, and thread-safe.
    //  Modules touch this through narrow public surfaces — they never read
    //  raw files or write JSON inline.
    //
    //  JSON dependency choice: NT8 ships Newtonsoft.Json.dll but AddOns
    //  can't reference external DLLs without UsesDll=true in Info.xml, which
    //  is a deployment hassle and a per-NT-version risk. The settings model
    //  is small enough to hand-serialize cleanly — see JournifiNTJson below.

    #region Paths

    /// <summary>
    /// All filesystem paths used by v3, in one place. Computed once on first
    /// touch; thereafter just static strings.
    ///
    /// Why we hardcode <c>C:\NinjaTrader8Data\</c> instead of asking NT for
    /// <c>Core.Globals.UserDataDir</c>:
    ///   • The Journifi AI desktop app's NinjaTraderBarSource + JournifiSync
    ///     watcher are BOTH hardcoded to read from this path. v3 must write
    ///     where the journal reads, full stop.
    ///   • JournifiSync v2 and JournifiBars v1 also hardcode this path, so
    ///     the migration story stays simple: legacy data is always here.
    ///   • Users who set up an <c>NinjaTrader 8</c> → <c>NinjaTrader8Data</c>
    ///     junction (a common convenience) see both paths point at the same
    ///     physical folder, so nothing changes for them.
    ///   • Users on a stock NT install with no junction get a top-level
    ///     <c>C:\NinjaTrader8Data\</c> folder created on first v3 run — same
    ///     behavior as v1/v2, so no new surprise.
    ///
    /// If we ever need to support a fully user-configurable output dir,
    /// it goes in <see cref="JournifiNTSettings"/> as an explicit override,
    /// NOT inferred from NT itself.
    /// </summary>
    internal static class JournifiNTPaths
    {
        public const string NT8DataRoot = @"C:\NinjaTrader8Data";

        // Per-module output folders kept at their existing legacy locations so
        // the journal-side readers (NinjaTraderBarSource + JournifiSync watcher)
        // see no path change during v3 rollout.
        public static readonly string SyncDir = Path.Combine(NT8DataRoot, "JournifiSync");
        public static readonly string BarsDir = Path.Combine(NT8DataRoot, "JournifiBars");

        // Unified v3 folder for the merged settings.json and the shared log.
        public static readonly string JournifiDir = Path.Combine(NT8DataRoot, "Journifi");
        public static readonly string SettingsPath = Path.Combine(JournifiDir, "settings.json");
        public static readonly string LogDir = Path.Combine(JournifiDir, "log");
        public static readonly string LogPath = Path.Combine(LogDir, "Journifi.log");
        public static readonly string LogErrorsPath = Path.Combine(LogDir, "Journifi_errors.log");

        // Legacy settings files we migrate from on first v3 run.
        public static readonly string LegacySyncSettingsPath = Path.Combine(SyncDir, "settings.json");
        public static readonly string LegacyBarsSettingsPath = Path.Combine(BarsDir, "settings.json");

        // Per-module status.json files (heartbeat — journal reads to detect
        // "is the AddOn alive"). Kept at legacy locations.
        public static readonly string SyncStatusPath = Path.Combine(SyncDir, "status.json");
        public static readonly string BarsStatusPath = Path.Combine(BarsDir, "status.json");

        /// <summary>
        /// Ensure every directory we own exists. Cheap to call repeatedly.
        /// </summary>
        public static void EnsureDirectories()
        {
            try
            {
                if (!Directory.Exists(NT8DataRoot)) Directory.CreateDirectory(NT8DataRoot);
                if (!Directory.Exists(JournifiDir)) Directory.CreateDirectory(JournifiDir);
                if (!Directory.Exists(LogDir)) Directory.CreateDirectory(LogDir);
                if (!Directory.Exists(SyncDir)) Directory.CreateDirectory(SyncDir);
                if (!Directory.Exists(BarsDir)) Directory.CreateDirectory(BarsDir);
            }
            catch { /* Logger isn't safe to call here — we ARE the bootstrap */ }
        }
    }

    /// <summary>
    /// Atomic file-write helper — the single chokepoint for durable writes
    /// (v3.0.1). Writes to a sibling <c>.tmp</c>, then swaps it into place
    /// with <see cref="File.Replace(string,string,string)"/> — an atomic NTFS
    /// operation when the destination exists — so a crash, AV kill, or power
    /// loss mid-write can never leave the destination truncated or missing.
    ///
    /// The OLD pattern (WriteAllText(tmp) → Delete(dest) → Move(tmp, dest))
    /// had a window between Delete and Move where the destination did not
    /// exist; a crash in that window destroyed the whole file with only the
    /// (journal-unread) .tmp surviving, and the next batch then restarted
    /// from an empty file — silently losing the entire day's executions /
    /// the month's bars. The executions_*.json and bars-CSV write paths both
    /// used that unsafe pattern; this consolidates all three durable writes
    /// (settings included) onto one safe path. Mirrors the Journifi journal's
    /// writeJsonAtomic contract.
    /// </summary>
    internal static class JournifiNTIO
    {
        public static void AtomicWriteAllText(string path, string content, Encoding encoding = null)
        {
            string tmp = path + ".tmp";
            if (encoding != null) File.WriteAllText(tmp, content, encoding);
            else                  File.WriteAllText(tmp, content);

            try
            {
                if (File.Exists(path))
                    File.Replace(tmp, path, null);   // atomic swap on NTFS; tolerates a concurrent reader lock better than Move
                else
                    File.Move(tmp, path);            // first write — nothing to replace
            }
            catch
            {
                // Swap failed — don't leave a stray .tmp. The destination is
                // untouched (Replace is atomic / Move is no-op on failure), so
                // no data is lost. Re-throw so the caller logs it.
                try { if (File.Exists(tmp)) File.Delete(tmp); } catch { }
                throw;
            }
        }
    }

    #endregion

    #region Settings model

    /// <summary>
    /// Root settings document persisted as <c>Journifi\settings.json</c>.
    /// </summary>
    public class JournifiNTSettings
    {
        /// <summary>The RUNNING build. Always the live constant — never loaded from disk.</summary>
        public string Version { get; set; } = JournifiSyncNT.VERSION;

        /// <summary>
        /// The build that last WROTE this file, for provenance only. Empty on a
        /// fresh install. Never written back as <c>Version</c>, or the stamp freezes
        /// at the first writer forever.
        /// </summary>
        public string WrittenByVersion { get; set; } = "";

        /// <summary>
        /// NT account FullName → Journifi accountId. Single source of truth
        /// for both modules. Empty by default; populated via the Mappings tab.
        /// </summary>
        public Dictionary<string, string> AccountMappings { get; set; }
            = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        public JournifiNTSyncSettings Sync { get; set; } = new JournifiNTSyncSettings();
        public JournifiNTBarsSettings Bars { get; set; } = new JournifiNTBarsSettings();

        public static JournifiNTSettings CreateDefault() => new JournifiNTSettings();
    }

    public class JournifiNTSyncSettings
    {
        /// <summary>Master kill switch for the sync module. False = no exec capture.</summary>
        public bool Enabled { get; set; } = true;

        /// <summary>
        /// Account FullNames the user has muted from sync. The module still
        /// observes their executions but doesn't write them. Persisted so the
        /// preference survives restarts.
        /// </summary>
        public List<string> DisabledAccounts { get; set; } = new List<string>();
    }

    public class JournifiNTBarsSettings
    {
        /// <summary>Master kill switch for the bars module.</summary>
        public bool Enabled { get; set; } = true;

        /// <summary>How far back the initial historical pull goes.</summary>
        public int HistoricalDays { get; set; } = 30;

        /// <summary>Informational today; auto-cleanup ships later.</summary>
        public int RetentionDays { get; set; } = 90;

        /// <summary>NT TradingHours instance name. Default works for CME index futures ETH.</summary>
        public string TradingHoursTemplate { get; set; } = "CME US Index Futures ETH";

        /// <summary>
        /// (v3.1+) When true, ignore user-configured per-symbol timeframes and
        /// subscribe to 1m only. Higher timeframes are then derived in
        /// JournifiAI via aggregation. Rationale: NT's BarsUpdate stream
        /// silently drops events under load (cash-open volume spikes are the
        /// repeatable trigger). Each additional subscription competes for the
        /// same event queue, so one subscription per symbol is more reliable
        /// than five. Defaults to TRUE for new installs; existing users can
        /// flip it off in settings to restore multi-TF subscription behavior.
        /// </summary>
        public bool SubscribeOneMinuteOnly { get; set; } = true;

        /// <summary>
        /// (v3.1+) How often to run the self-heal sweep that re-pulls recent
        /// historical bars and merges them into on-disk files. Compensates
        /// for live-stream drops — NT's historical BarsRequest API has full
        /// fidelity even when its live subscription stream is sparse. 0 to
        /// disable. Default 5 minutes is a good balance of catch-up speed vs.
        /// API call frequency.
        /// </summary>
        public int SelfHealIntervalMinutes { get; set; } = 5;

        /// <summary>
        /// (v3.1+) How many minutes back the self-heal sweep re-pulls each
        /// cycle. Must cover at least one full sweep interval plus the typical
        /// drop window. 60 min covers cash-open drop scenarios reliably.
        /// </summary>
        public int SelfHealLookbackMinutes { get; set; } = 60;

        public List<JournifiNTWatchedSymbol> WatchedSymbols { get; set; }
            = new List<JournifiNTWatchedSymbol>();

        /// <summary>
        /// (v3.0.4+) Execution-driven auto-roll. When true, a fill on a futures
        /// contract that isn't already subscribed auto-subscribes its bars, so
        /// the bar pull rolls itself every quarter (MNQM6→MNQU6) with zero manual
        /// steps. <see cref="WatchedSymbols"/> stays the manual/pinned set and is
        /// always honored — auto-roll only AUGMENTS it, never deletes a pin.
        /// Defaults TRUE; flip off to restore pure manual-watchlist behavior.
        /// </summary>
        public bool AutoRollContracts { get; set; } = true;

        /// <summary>
        /// (v3.0.4+) After a contract rolls, keep pulling the superseded one this
        /// many days so roll-week overlap trades (both contracts trade for a few
        /// days) still get bar data. After this, the old contract's BarsRequest
        /// is disposed by the self-heal sweep. History files stay on disk.
        /// </summary>
        public int RollRetentionDays { get; set; } = 7;

        /// <summary>
        /// (v3.0.4+) Persisted auto-managed contract set so a NT restart re-
        /// subscribes the right contract(s) without waiting for the day's first
        /// fill. Each entry is "ROOT|CONTRACT" (e.g. "MNQ|MNQU6") so the root is
        /// available for same-root supersession on the next fill after a restart.
        /// Managed entirely by the bars module; not user-edited.
        /// </summary>
        public List<string> AutoManagedContracts { get; set; } = new List<string>();
    }

    public class JournifiNTWatchedSymbol
    {
        /// <summary>NT <c>Instrument.FullName</c>, exact (e.g. <c>"MNQ 06-26"</c>).</summary>
        public string Symbol { get; set; }

        /// <summary>Subset of <c>{1m, 5m, 15m, 1h, 4h}</c>.</summary>
        public List<string> Timeframes { get; set; } = new List<string>();
    }

    #endregion

    #region JSON serializer (hand-rolled)

    /// <summary>
    /// Purpose-built JSON for <see cref="JournifiNTSettings"/>. Not a general
    /// JSON library — knows exactly the shape of our document and emits a
    /// human-editable, diff-friendly format with two-space indentation.
    ///
    /// Parser is tolerant of comments-as-extra-fields, trailing commas, and
    /// whitespace. Unparseable inputs fall back to defaults rather than
    /// throwing — a corrupted settings file should not kill the AddOn.
    /// </summary>
    internal static class JournifiNTJson
    {
        public static string Serialize(JournifiNTSettings s)
        {
            if (s == null) s = JournifiNTSettings.CreateDefault();
            var sb = new StringBuilder(2048);
            sb.Append("{\n");
            sb.Append("  \"_comment\": \"JournifiSync NT settings. Edit then restart NinjaTrader. The 'symbol' field under watchedSymbols must match Instrument.FullName exactly (e.g. 'MNQ 06-26').\",\n");
            sb.Append("  \"version\": \"").Append(Esc(s.Version)).Append("\",\n");

            // accountMappings
            sb.Append("  \"accountMappings\": {");
            if (s.AccountMappings != null && s.AccountMappings.Count > 0)
            {
                sb.Append("\n");
                var keys = s.AccountMappings.Keys.OrderBy(k => k, StringComparer.OrdinalIgnoreCase).ToList();
                for (int i = 0; i < keys.Count; i++)
                {
                    sb.Append("    \"").Append(Esc(keys[i])).Append("\": \"")
                      .Append(Esc(s.AccountMappings[keys[i]] ?? "")).Append("\"");
                    if (i < keys.Count - 1) sb.Append(",");
                    sb.Append("\n");
                }
                sb.Append("  ");
            }
            sb.Append("},\n");

            // sync
            var sync = s.Sync ?? new JournifiNTSyncSettings();
            sb.Append("  \"sync\": {\n");
            sb.Append("    \"enabled\": ").Append(sync.Enabled ? "true" : "false").Append(",\n");
            sb.Append("    \"disabledAccounts\": [");
            if (sync.DisabledAccounts != null && sync.DisabledAccounts.Count > 0)
            {
                for (int i = 0; i < sync.DisabledAccounts.Count; i++)
                {
                    if (i > 0) sb.Append(", ");
                    sb.Append("\"").Append(Esc(sync.DisabledAccounts[i] ?? "")).Append("\"");
                }
            }
            sb.Append("]\n");
            sb.Append("  },\n");

            // bars
            var bars = s.Bars ?? new JournifiNTBarsSettings();
            sb.Append("  \"bars\": {\n");
            sb.Append("    \"enabled\": ").Append(bars.Enabled ? "true" : "false").Append(",\n");
            sb.Append("    \"historicalDays\": ").Append(bars.HistoricalDays).Append(",\n");
            sb.Append("    \"retentionDays\": ").Append(bars.RetentionDays).Append(",\n");
            sb.Append("    \"tradingHoursTemplate\": \"").Append(Esc(bars.TradingHoursTemplate ?? "")).Append("\",\n");
            // v3.1+ — 1m-only subscription + self-heal sweep
            sb.Append("    \"subscribeOneMinuteOnly\": ").Append(bars.SubscribeOneMinuteOnly ? "true" : "false").Append(",\n");
            sb.Append("    \"selfHealIntervalMinutes\": ").Append(bars.SelfHealIntervalMinutes).Append(",\n");
            sb.Append("    \"selfHealLookbackMinutes\": ").Append(bars.SelfHealLookbackMinutes).Append(",\n");
            // v3.0.4+ — execution-driven auto-roll
            sb.Append("    \"autoRollContracts\": ").Append(bars.AutoRollContracts ? "true" : "false").Append(",\n");
            sb.Append("    \"rollRetentionDays\": ").Append(bars.RollRetentionDays).Append(",\n");
            sb.Append("    \"autoManagedContracts\": [");
            if (bars.AutoManagedContracts != null)
            {
                for (int i = 0; i < bars.AutoManagedContracts.Count; i++)
                {
                    if (i > 0) sb.Append(", ");
                    sb.Append("\"").Append(Esc(bars.AutoManagedContracts[i] ?? "")).Append("\"");
                }
            }
            sb.Append("],\n");
            sb.Append("    \"watchedSymbols\": [");
            if (bars.WatchedSymbols != null && bars.WatchedSymbols.Count > 0)
            {
                for (int i = 0; i < bars.WatchedSymbols.Count; i++)
                {
                    var w = bars.WatchedSymbols[i];
                    sb.Append("\n      {\n");
                    sb.Append("        \"symbol\": \"").Append(Esc(w.Symbol ?? "")).Append("\",\n");
                    sb.Append("        \"timeframes\": [");
                    if (w.Timeframes != null)
                    {
                        for (int j = 0; j < w.Timeframes.Count; j++)
                        {
                            if (j > 0) sb.Append(", ");
                            sb.Append("\"").Append(Esc(w.Timeframes[j] ?? "")).Append("\"");
                        }
                    }
                    sb.Append("]\n      }");
                    if (i < bars.WatchedSymbols.Count - 1) sb.Append(",");
                }
                sb.Append("\n    ");
            }
            sb.Append("]\n");
            sb.Append("  }\n");

            sb.Append("}\n");
            return sb.ToString();
        }

        public static JournifiNTSettings Deserialize(string json)
        {
            var s = JournifiNTSettings.CreateDefault();
            if (string.IsNullOrWhiteSpace(json)) return s;

            try
            {
                // version
                var m = Regex.Match(json, "\"version\"\\s*:\\s*\"([^\"]*)\"");
                // v3.0.11 — read into WrittenByVersion, NOT into Version.
                //
                // This used to load the on-disk string over the live constant and
                // then save it back, so the stamp froze at whatever wrote the file
                // FIRST and never moved. Chris's settings.json read "3.0.4-alpha"
                // while 3.0.11 was running — seven releases stale, and silently,
                // because nothing ever compared the two.
                //
                // Version now always reports the RUNNING build (the property
                // initializer); the disk value is kept as provenance only — the same
                // split the journal storage envelope uses (writtenBy vs APP_SCHEMA).
                if (m.Success) s.WrittenByVersion = m.Groups[1].Value;

                // accountMappings — flat string→string object
                string mapBody = ExtractTopLevelObjectBody(json, "accountMappings");
                if (!string.IsNullOrEmpty(mapBody))
                {
                    s.AccountMappings.Clear();
                    foreach (Match pair in Regex.Matches(mapBody,
                        "\"([^\"]+)\"\\s*:\\s*\"([^\"]*)\""))
                    {
                        var key = Unesc(pair.Groups[1].Value);
                        var val = Unesc(pair.Groups[2].Value);
                        if (!string.IsNullOrWhiteSpace(key))
                            s.AccountMappings[key] = val ?? "";
                    }
                }

                // sync.* (object body)
                string syncBody = ExtractTopLevelObjectBody(json, "sync");
                if (!string.IsNullOrEmpty(syncBody))
                {
                    var enabledMatch = Regex.Match(syncBody, "\"enabled\"\\s*:\\s*(true|false)");
                    if (enabledMatch.Success) s.Sync.Enabled = enabledMatch.Groups[1].Value == "true";

                    string daBody = ExtractTopLevelArrayBody(syncBody, "disabledAccounts");
                    if (!string.IsNullOrEmpty(daBody))
                    {
                        s.Sync.DisabledAccounts.Clear();
                        foreach (Match em in Regex.Matches(daBody, "\"([^\"]+)\""))
                            s.Sync.DisabledAccounts.Add(Unesc(em.Groups[1].Value));
                    }
                }

                // bars.* (object body)
                string barsBody = ExtractTopLevelObjectBody(json, "bars");
                if (!string.IsNullOrEmpty(barsBody))
                {
                    var enabledMatch = Regex.Match(barsBody, "\"enabled\"\\s*:\\s*(true|false)");
                    if (enabledMatch.Success) s.Bars.Enabled = enabledMatch.Groups[1].Value == "true";

                    var hdMatch = Regex.Match(barsBody, "\"historicalDays\"\\s*:\\s*(\\d+)");
                    if (hdMatch.Success && int.TryParse(hdMatch.Groups[1].Value, out int hd) && hd > 0)
                        s.Bars.HistoricalDays = hd;

                    var rdMatch = Regex.Match(barsBody, "\"retentionDays\"\\s*:\\s*(\\d+)");
                    if (rdMatch.Success && int.TryParse(rdMatch.Groups[1].Value, out int rd) && rd > 0)
                        s.Bars.RetentionDays = rd;

                    var thMatch = Regex.Match(barsBody, "\"tradingHoursTemplate\"\\s*:\\s*\"([^\"]*)\"");
                    if (thMatch.Success && !string.IsNullOrWhiteSpace(thMatch.Groups[1].Value))
                        s.Bars.TradingHoursTemplate = Unesc(thMatch.Groups[1].Value);

                    // v3.1+ — 1m-only subscription toggle + self-heal cadence.
                    // Parsing is defensive: missing fields fall back to the
                    // C# property defaults (true / 5 / 60), so older settings.json
                    // files upgrade cleanly to the new behavior without manual edits.
                    var oneMinMatch = Regex.Match(barsBody, "\"subscribeOneMinuteOnly\"\\s*:\\s*(true|false)");
                    if (oneMinMatch.Success) s.Bars.SubscribeOneMinuteOnly = oneMinMatch.Groups[1].Value == "true";

                    var shIntMatch = Regex.Match(barsBody, "\"selfHealIntervalMinutes\"\\s*:\\s*(\\d+)");
                    if (shIntMatch.Success && int.TryParse(shIntMatch.Groups[1].Value, out int shi) && shi >= 0)
                        s.Bars.SelfHealIntervalMinutes = shi;

                    var shLkMatch = Regex.Match(barsBody, "\"selfHealLookbackMinutes\"\\s*:\\s*(\\d+)");
                    if (shLkMatch.Success && int.TryParse(shLkMatch.Groups[1].Value, out int shl) && shl > 0)
                        s.Bars.SelfHealLookbackMinutes = shl;

                    // v3.0.4+ — auto-roll. Missing fields fall back to the C#
                    // defaults (true / 7 / empty), so older settings.json upgrade
                    // cleanly to auto-roll-on without a manual edit.
                    var autoRollMatch = Regex.Match(barsBody, "\"autoRollContracts\"\\s*:\\s*(true|false)");
                    if (autoRollMatch.Success) s.Bars.AutoRollContracts = autoRollMatch.Groups[1].Value == "true";

                    var rollRetMatch = Regex.Match(barsBody, "\"rollRetentionDays\"\\s*:\\s*(\\d+)");
                    if (rollRetMatch.Success && int.TryParse(rollRetMatch.Groups[1].Value, out int rr) && rr >= 0)
                        s.Bars.RollRetentionDays = rr;

                    // autoManagedContracts — flat string array ["ROOT|CONTRACT", …].
                    // Flat (no nesting), so a simple bracket-delimited match is safe.
                    var amcArr = Regex.Match(barsBody, "\"autoManagedContracts\"\\s*:\\s*\\[([^\\]]*)\\]");
                    if (amcArr.Success)
                    {
                        s.Bars.AutoManagedContracts = new List<string>();
                        foreach (Match cm in Regex.Matches(amcArr.Groups[1].Value, "\"([^\"]+)\""))
                            s.Bars.AutoManagedContracts.Add(Unesc(cm.Groups[1].Value));
                    }

                    // watchedSymbols — array of {symbol, timeframes:[…]}.
                    // Walk brackets so nested timeframes arrays don't fool a
                    // lazy regex (same fix v1.1.1 had to make).
                    string wsBody = ExtractTopLevelArrayBody(barsBody, "watchedSymbols");
                    if (!string.IsNullOrEmpty(wsBody))
                    {
                        s.Bars.WatchedSymbols.Clear();
                        var entryRegex = new Regex("\\{[^{}]*\\}", RegexOptions.Singleline);
                        foreach (Match em in entryRegex.Matches(wsBody))
                        {
                            string entryStr = em.Value;
                            var symMatch = Regex.Match(entryStr, "\"symbol\"\\s*:\\s*\"([^\"]+)\"");
                            if (!symMatch.Success) continue;
                            var entry = new JournifiNTWatchedSymbol { Symbol = Unesc(symMatch.Groups[1].Value) };
                            var tfArr = Regex.Match(entryStr, "\"timeframes\"\\s*:\\s*\\[([^\\]]*)\\]");
                            if (tfArr.Success)
                            {
                                foreach (Match tfm in Regex.Matches(tfArr.Groups[1].Value, "\"([^\"]+)\""))
                                    entry.Timeframes.Add(Unesc(tfm.Groups[1].Value));
                            }
                            if (entry.Timeframes.Count == 0) entry.Timeframes.Add("1m");
                            s.Bars.WatchedSymbols.Add(entry);
                        }
                    }
                }
            }
            catch
            {
                // Corrupted file → return whatever we parsed so far rather than throw.
                // Defaults already in place from CreateDefault.
            }

            return s;
        }

        /// <summary>
        /// Find the body of a top-level JSON array by key name, returning the
        /// string between the matching outer <c>[</c> and <c>]</c>. Walks
        /// brackets manually so nested arrays don't break a naive regex.
        /// Skips string literals so embedded <c>[</c>/<c>]</c> don't shift depth.
        /// </summary>
        private static string ExtractTopLevelArrayBody(string json, string keyName)
            => ExtractBalanced(json, keyName, '[', ']');

        /// <summary>Same idea, for JSON objects (<c>{ ... }</c>).</summary>
        private static string ExtractTopLevelObjectBody(string json, string keyName)
            => ExtractBalanced(json, keyName, '{', '}');

        private static string ExtractBalanced(string json, string keyName, char open, char close)
        {
            if (string.IsNullOrEmpty(json) || string.IsNullOrEmpty(keyName)) return "";

            var keyMatch = Regex.Match(json,
                "\"" + Regex.Escape(keyName) + "\"\\s*:\\s*\\" + open);
            if (!keyMatch.Success) return "";

            int start = keyMatch.Index + keyMatch.Length - 1;
            if (start < 0 || start >= json.Length || json[start] != open) return "";

            int depth = 1;
            bool inString = false;
            for (int i = start + 1; i < json.Length; i++)
            {
                char c = json[i];
                if (inString)
                {
                    if (c == '\\' && i + 1 < json.Length) { i++; continue; }
                    if (c == '"') inString = false;
                    continue;
                }
                if (c == '"') { inString = true; continue; }
                if (c == open) depth++;
                else if (c == close)
                {
                    depth--;
                    if (depth == 0) return json.Substring(start + 1, i - start - 1);
                }
            }
            return ""; // unbalanced — bail
        }

        private static string Esc(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("\\", "\\\\").Replace("\"", "\\\"")
                    .Replace("\n", "\\n").Replace("\r", "\\r").Replace("\t", "\\t");
        }

        private static string Unesc(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("\\n", "\n").Replace("\\r", "\r").Replace("\\t", "\t")
                    .Replace("\\\"", "\"").Replace("\\\\", "\\");
        }
    }

    #endregion

    #region Settings store (load/save)

    /// <summary>
    /// Process-static holder for the live <see cref="JournifiNTSettings"/>.
    /// Modules read <see cref="Current"/> at any time; writes flow through
    /// <see cref="Save"/> which serializes + atomically rewrites the file.
    ///
    /// First <see cref="Load"/> call also runs
    /// <see cref="JournifiNTLegacyMigrator.MigrateIfNeeded"/>, so a fresh v3
    /// install on a machine with v1/v2 data picks up watched symbols and
    /// disabled accounts automatically.
    /// </summary>
    internal static class JournifiNTSettingsStore
    {
        private static readonly object _lock = new object();
        private static JournifiNTSettings _current;
        private static bool _loaded;

        public static JournifiNTSettings Current
        {
            get
            {
                if (!_loaded) Load();
                return _current ?? (_current = JournifiNTSettings.CreateDefault());
            }
        }

        public static void Load()
        {
            lock (_lock)
            {
                JournifiNTPaths.EnsureDirectories();
                // Migration runs once — it creates settings.json if v1/v2 data
                // is present, otherwise no-ops.
                try { JournifiNTLegacyMigrator.MigrateIfNeeded(); }
                catch (Exception ex) { JournifiNTLog.Error("Shared", "Legacy migration failed", ex); }

                if (File.Exists(JournifiNTPaths.SettingsPath))
                {
                    try
                    {
                        string json = File.ReadAllText(JournifiNTPaths.SettingsPath);
                        _current = JournifiNTJson.Deserialize(json);
                        JournifiNTLog.Info("Shared",
                            $"Loaded settings: {_current.Sync.DisabledAccounts.Count} disabled accounts, " +
                            $"{_current.Bars.WatchedSymbols.Count} watched symbols, " +
                            $"{_current.AccountMappings.Count} mappings.");
                    }
                    catch (Exception ex)
                    {
                        JournifiNTLog.Error("Shared", "Settings load failed; using defaults", ex);
                        _current = JournifiNTSettings.CreateDefault();
                    }
                }
                else
                {
                    _current = JournifiNTSettings.CreateDefault();
                    SaveInternal(_current);
                    JournifiNTLog.Info("Shared", "Fresh settings.json created with defaults.");
                }
                _loaded = true;
            }
        }

        /// <summary>
        /// Persist the current settings. Caller may mutate <see cref="Current"/>
        /// directly then call Save, or pass an explicit replacement.
        /// Atomic: writes to .tmp first then renames, so a crash mid-write
        /// never leaves a half-flushed settings.json.
        /// </summary>
        public static bool Save(JournifiNTSettings replacement = null)
        {
            lock (_lock)
            {
                if (replacement != null) _current = replacement;
                if (_current == null) _current = JournifiNTSettings.CreateDefault();
                return SaveInternal(_current);
            }
        }

        private static bool SaveInternal(JournifiNTSettings settings)
        {
            try
            {
                JournifiNTPaths.EnsureDirectories();
                string json = JournifiNTJson.Serialize(settings);
                // v3.0.1 — via the shared atomic-write chokepoint (was an
                // inline copy of this same File.Replace pattern).
                JournifiNTIO.AtomicWriteAllText(JournifiNTPaths.SettingsPath, json, Encoding.UTF8);
                return true;
            }
            catch (Exception ex)
            {
                JournifiNTLog.Error("Shared", "Settings save failed", ex);
                return false;
            }
        }
    }

    #endregion

    #region Logger

    /// <summary>
    /// Single logger for both modules. Each call writes:
    ///   • The full line to <c>Journifi\log\Journifi.log</c>
    ///   • The full line to NT's Output Window (OutputTab1)
    ///   • If severity is Error, also to <c>Journifi_errors.log</c>
    ///
    /// Module name appears in brackets so a single tail can interleave both
    /// modules' history (<c>[Sync]</c> / <c>[Bars]</c> / <c>[Shared]</c> /
    /// <c>[Orchestrator]</c>). Thread-safe.
    /// </summary>
    internal static class JournifiNTLog
    {
        private static readonly object _writeLock = new object();

        public static void Info(string module, string message)
            => Write("INFO", module, message);

        public static void Warn(string module, string message)
            => Write("WARN", module, message);

        public static void Error(string module, string message, Exception ex = null)
        {
            var msg = ex == null ? message : $"{message} — {ex.GetType().Name}: {ex.Message}";
            Write("ERROR", module, msg);
        }

        private static void Write(string level, string module, string message)
        {
            string line = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff}] [{level}] [{module}] {message}";

            // Mirror to NT Output. Wrapped — NT initialization order or a
            // missing output tab must never crash logging.
            try { NinjaTrader.Code.Output.Process($"[JournifiSync NT] {line}", PrintTo.OutputTab1); }
            catch { /* ignore */ }

            // Mirror to disk under a lock.
            lock (_writeLock)
            {
                try
                {
                    JournifiNTPaths.EnsureDirectories();
                    File.AppendAllText(JournifiNTPaths.LogPath, line + Environment.NewLine, Encoding.UTF8);
                    if (level == "ERROR")
                        File.AppendAllText(JournifiNTPaths.LogErrorsPath, line + Environment.NewLine, Encoding.UTF8);
                }
                catch { /* ignore — best effort */ }
            }
        }
    }

    #endregion

    #region Instrument cache

    /// <summary>
    /// Shared memoization in front of <c>Cbi.Instrument.GetInstrument(name)</c>.
    /// Both modules look up the same NT contracts (MNQ 06-26 etc.); without a
    /// cache, each module pays the lookup cost — and a missed-cache lookup
    /// inside NT can block briefly on the contract database. Resolves are
    /// cached forever; <see cref="Invalidate"/> clears the table after a
    /// settings change or rollover.
    /// </summary>
    internal static class JournifiNTInstrumentCache
    {
        private static readonly ConcurrentDictionary<string, NinjaTrader.Cbi.Instrument> _cache
            = new ConcurrentDictionary<string, NinjaTrader.Cbi.Instrument>(StringComparer.OrdinalIgnoreCase);

        /// <summary>
        /// Returns the cached Instrument for <paramref name="fullName"/>, or
        /// resolves and caches it on first miss. Returns null if NT can't
        /// resolve the symbol (instrument not loaded, typo, etc.) — callers
        /// must null-check.
        /// </summary>
        public static NinjaTrader.Cbi.Instrument Resolve(string fullName)
        {
            if (string.IsNullOrWhiteSpace(fullName)) return null;
            return _cache.GetOrAdd(fullName, key =>
            {
                try { return NinjaTrader.Cbi.Instrument.GetInstrument(key); }
                catch { return null; }
            });
        }

        public static void Invalidate() => _cache.Clear();
    }

    #endregion

    #region Cross-assembly bridge

    /// <summary>
    /// Cross-assembly bridge so UI tabs survive an NT NinjaScript recompile
    /// without needing to be closed and reopened.
    ///
    /// The problem: when NT recompiles, the OLD assembly's <see cref="JournifiSyncNT"/>
    /// instance is terminated (its <c>Instance</c> static is set to null), and
    /// a NEW assembly is loaded with its own <c>Instance</c> static set to the
    /// fresh orchestrator. But any UI tab still hosted in a workspace window
    /// is an OLD-assembly object — it reads the OLD <c>JournifiSyncNT.Instance</c>
    /// (now null) and concludes "module not loaded."
    ///
    /// The fix: walk every loaded assembly looking for a type named
    /// <c>NinjaTrader.Gui.NinjaScript.JournifiSyncNT</c> with a non-null static
    /// <c>Instance</c>. Return that. UI tabs reach modules through this bridge's
    /// <see cref="Sync"/> / <see cref="Bars"/> dynamic properties, which use
    /// the DLR to resolve members at call time — so member access works even
    /// when caller and callee live in different assemblies.
    ///
    /// Cached the live instance to avoid the full assembly walk on every
    /// access; invalidates the cache when the cached instance's own
    /// <c>Instance</c> static returns null (signals it's the previous-old
    /// assembly and an even newer one exists).
    /// </summary>
    internal static class JournifiSyncNTBridge
    {
        private const string OrchestratorTypeName =
            "NinjaTrader.Gui.NinjaScript.JournifiSyncNT";

        private static object _cached;
        private static readonly object _cacheLock = new object();

        /// <summary>
        /// The live JournifiSyncNT orchestrator (as dynamic) or null. Use
        /// this instead of <c>JournifiSyncNT.Instance</c> from any code that
        /// might run after an NT recompile (i.e. all UI tabs).
        /// </summary>
        public static dynamic Instance => GetActiveInstance();

        public static dynamic Sync
        {
            get
            {
                // GetActiveInstance returns `object`, on which `.Sync` isn't
                // a known member. Cast to dynamic so DLR resolves at runtime.
                dynamic inst = GetActiveInstance();
                if (inst == null) return null;
                try { return inst.Sync; } catch { return null; }
            }
        }

        public static dynamic Bars
        {
            get
            {
                dynamic inst = GetActiveInstance();
                if (inst == null) return null;
                try { return inst.Bars; } catch { return null; }
            }
        }

        /// <summary>True if a live orchestrator is reachable from this caller.</summary>
        public static bool IsAlive => GetActiveInstance() != null;

        private static object GetActiveInstance()
        {
            // Fast path: same-assembly direct read. If this returns non-null
            // we're in the same assembly as the live orchestrator — no bridge
            // needed.
            try
            {
                var direct = JournifiSyncNT.Instance;
                if (direct != null)
                {
                    lock (_cacheLock) _cached = null; // direct works, drop stale cache
                    return direct;
                }
            }
            catch { /* fall through */ }

            // Re-check cached cross-assembly handle.
            lock (_cacheLock)
            {
                if (_cached != null)
                {
                    if (IsStillActive(_cached)) return _cached;
                    _cached = null;
                }
            }

            // Slow path: scan all loaded assemblies for the type with a live
            // Instance static. Skip well-known framework/NT runtime assemblies
            // to keep the walk cheap.
            try
            {
                foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
                {
                    var asmName = asm.GetName().Name ?? "";
                    if (asmName.StartsWith("System") ||
                        asmName.StartsWith("Microsoft") ||
                        asmName.StartsWith("mscorlib") ||
                        asmName.StartsWith("netstandard") ||
                        asmName.StartsWith("WindowsBase") ||
                        asmName.StartsWith("Presentation") ||
                        asmName.StartsWith("UIAutomation") ||
                        asmName.StartsWith("Newtonsoft"))
                        continue;

                    Type t;
                    try { t = asm.GetType(OrchestratorTypeName); }
                    catch { continue; }
                    if (t == null) continue;

                    var prop = t.GetProperty("Instance",
                        BindingFlags.Public | BindingFlags.Static);
                    var inst = prop?.GetValue(null);
                    if (inst != null)
                    {
                        lock (_cacheLock) _cached = inst;
                        return inst;
                    }
                }
            }
            catch { /* return null below */ }
            return null;
        }

        private static bool IsStillActive(object inst)
        {
            try
            {
                var prop = inst.GetType().GetProperty("Instance",
                    BindingFlags.Public | BindingFlags.Static);
                return prop?.GetValue(null) != null;
            }
            catch { return false; }
        }
    }

    #endregion

    #region Journifi AI heartbeat reader

    /// <summary>
    /// Reads the desktop app's heartbeat file
    /// (<c>JournifiSync\journifi_heartbeat.json</c>, written every few seconds
    /// by <c>electron\main.cjs</c>) so the Dashboard can show whether the
    /// journal is currently running and watching for trades.
    ///
    /// Fresh = heartbeat written within <see cref="StaleThreshold"/>.
    /// Beyond that we consider the journal disconnected.
    /// </summary>
    internal static class JournifiAIHeartbeatReader
    {
        public static readonly TimeSpan StaleThreshold = TimeSpan.FromSeconds(10);

        public class Snapshot
        {
            public bool Found;
            public bool Fresh;
            public TimeSpan Age;
            public string Version;
            public DateTime LastHeartbeatUtc;
        }

        public static Snapshot Read()
        {
            var snap = new Snapshot();
            try
            {
                string path = Path.Combine(JournifiNTPaths.SyncDir, "journifi_heartbeat.json");
                if (!File.Exists(path)) return snap;
                snap.Found = true;

                string json = File.ReadAllText(path);

                var verMatch = Regex.Match(json, "\"version\"\\s*:\\s*\"([^\"]*)\"");
                if (verMatch.Success) snap.Version = verMatch.Groups[1].Value;

                var hbMatch = Regex.Match(json, "\"lastHeartbeat\"\\s*:\\s*\"([^\"]*)\"");
                if (hbMatch.Success &&
                    DateTime.TryParse(hbMatch.Groups[1].Value,
                        System.Globalization.CultureInfo.InvariantCulture,
                        System.Globalization.DateTimeStyles.RoundtripKind,
                        out var hb))
                {
                    snap.LastHeartbeatUtc = hb.ToUniversalTime();
                    snap.Age = DateTime.UtcNow - snap.LastHeartbeatUtc;
                    snap.Fresh = snap.Age <= StaleThreshold;
                }
            }
            catch { /* return whatever we got */ }
            return snap;
        }
    }

    #endregion

    #region Legacy migrator

    /// <summary>
    /// One-shot first-run helper: reads the legacy
    /// <c>JournifiSync\settings.json</c> (just <c>disabledAccounts</c>) and
    /// <c>JournifiBars\settings.json</c> (full JournifiBarsConfig), and
    /// COPIES their data into <c>Journifi\settings.json</c>.
    ///
    /// Important: we do NOT rename or otherwise touch the legacy files.
    /// During the v3 parallel-running window, JournifiSync v2.0.1 and
    /// JournifiBars v1.1.x continue reading their own settings.json — any
    /// destructive action on those files would silently break the legacy
    /// AddOns. After verifying v3 works the user uninstalls v1/v2 via NT's
    /// AddOn manager; the legacy data folders can stay (harmless) or be
    /// deleted manually.
    ///
    /// Idempotent: returns false immediately on subsequent runs because
    /// <c>Journifi\settings.json</c> already exists.
    /// </summary>
    internal static class JournifiNTLegacyMigrator
    {
        public static bool MigrateIfNeeded()
        {
            // Already migrated? Bail.
            if (File.Exists(JournifiNTPaths.SettingsPath)) return false;

            bool foundSyncLegacy = File.Exists(JournifiNTPaths.LegacySyncSettingsPath);
            bool foundBarsLegacy = File.Exists(JournifiNTPaths.LegacyBarsSettingsPath);
            if (!foundSyncLegacy && !foundBarsLegacy) return false; // fresh install

            JournifiNTLog.Info("Migrator",
                $"Importing legacy settings (sync={foundSyncLegacy}, bars={foundBarsLegacy}) → Journifi\\settings.json");
            JournifiNTLog.Info("Migrator",
                "  Legacy files are read-only during import; JournifiSync v2 / JournifiBars v1 keep using their own copies.");

            var merged = JournifiNTSettings.CreateDefault();

            // Legacy sync settings: { "disabledAccounts": ["…", "…"] }
            if (foundSyncLegacy)
            {
                try
                {
                    string raw = File.ReadAllText(JournifiNTPaths.LegacySyncSettingsPath);
                    var arrMatch = Regex.Match(raw,
                        "\"disabledAccounts\"\\s*:\\s*\\[([^\\]]*)\\]");
                    if (arrMatch.Success)
                    {
                        foreach (Match em in Regex.Matches(arrMatch.Groups[1].Value, "\"([^\"]+)\""))
                            merged.Sync.DisabledAccounts.Add(em.Groups[1].Value);
                    }
                    JournifiNTLog.Info("Migrator",
                        $"  Sync legacy: {merged.Sync.DisabledAccounts.Count} disabled account(s) imported.");
                }
                catch (Exception ex)
                {
                    JournifiNTLog.Error("Migrator", "Sync legacy read failed", ex);
                }
            }

            // Legacy bars settings: full JournifiBarsConfig JSON. Reuse our
            // own deserializer by stuffing the legacy doc under a "bars": {…}
            // wrapper — same field names, so it parses straight through.
            if (foundBarsLegacy)
            {
                try
                {
                    string raw = File.ReadAllText(JournifiNTPaths.LegacyBarsSettingsPath);
                    string wrapped = "{ \"bars\": " + raw + " }";
                    var parsed = JournifiNTJson.Deserialize(wrapped);
                    if (parsed?.Bars != null)
                    {
                        merged.Bars.HistoricalDays = parsed.Bars.HistoricalDays;
                        merged.Bars.RetentionDays = parsed.Bars.RetentionDays;
                        if (!string.IsNullOrWhiteSpace(parsed.Bars.TradingHoursTemplate))
                            merged.Bars.TradingHoursTemplate = parsed.Bars.TradingHoursTemplate;
                        merged.Bars.WatchedSymbols = parsed.Bars.WatchedSymbols
                            ?? new List<JournifiNTWatchedSymbol>();
                    }
                    JournifiNTLog.Info("Migrator",
                        $"  Bars legacy: {merged.Bars.WatchedSymbols.Count} watched symbol(s) imported, " +
                        $"historicalDays={merged.Bars.HistoricalDays}, " +
                        $"tradingHours='{merged.Bars.TradingHoursTemplate}'.");
                }
                catch (Exception ex)
                {
                    JournifiNTLog.Error("Migrator", "Bars legacy read failed", ex);
                }
            }

            bool saved = JournifiNTSettingsStore.Save(merged);
            if (!saved)
            {
                JournifiNTLog.Error("Migrator", "Import failed — unified settings.json could not be written.");
                return false;
            }

            JournifiNTLog.Info("Migrator",
                "Import complete. Edit Journifi\\settings.json via the JournifiSync NT UI; legacy files remain in place.");
            return true;
        }

        /// <summary>
        /// Result of a force-rerun, used by the About tab to show a summary.
        /// </summary>
        public class RerunResult
        {
            public bool Ran;
            public bool Saved;
            public int SyncDisabledAccountsMerged;
            public int BarsSymbolsMerged;
            public string Message;
        }

        /// <summary>
        /// Manual re-import — read the legacy settings.json files NOW and
        /// MERGE their contents into the current Journifi\settings.json.
        /// Unlike <see cref="MigrateIfNeeded"/>, this doesn't bail when
        /// Journifi\settings.json exists; instead it unions the legacy
        /// disabled-accounts + watched-symbols into whatever's already there,
        /// preserving v3-specific config (accountMappings, etc.) untouched.
        ///
        /// Triggered by the "Re-run Migration" button on the About tab.
        /// Useful when the user installs v1/v2 data AFTER v3 was set up, or
        /// wants to re-pull a setting that got cleared.
        /// </summary>
        public static RerunResult ForceRerun()
        {
            var result = new RerunResult();
            try
            {
                bool foundSync = File.Exists(JournifiNTPaths.LegacySyncSettingsPath);
                bool foundBars = File.Exists(JournifiNTPaths.LegacyBarsSettingsPath);
                if (!foundSync && !foundBars)
                {
                    result.Message = "No legacy settings files found in JournifiSync\\ or JournifiBars\\ folders.";
                    return result;
                }

                var current = JournifiNTSettingsStore.Current ?? JournifiNTSettings.CreateDefault();

                // Sync legacy — union disabled accounts (don't drop user's
                // v3-only additions).
                if (foundSync)
                {
                    try
                    {
                        string raw = File.ReadAllText(JournifiNTPaths.LegacySyncSettingsPath);
                        var arrMatch = Regex.Match(raw,
                            "\"disabledAccounts\"\\s*:\\s*\\[([^\\]]*)\\]");
                        if (arrMatch.Success)
                        {
                            var existing = new HashSet<string>(
                                current.Sync.DisabledAccounts ?? new List<string>(),
                                StringComparer.OrdinalIgnoreCase);
                            foreach (Match em in Regex.Matches(arrMatch.Groups[1].Value, "\"([^\"]+)\""))
                            {
                                if (existing.Add(em.Groups[1].Value))
                                    result.SyncDisabledAccountsMerged++;
                            }
                            current.Sync.DisabledAccounts = existing.ToList();
                        }
                    }
                    catch (Exception ex)
                    {
                        JournifiNTLog.Error("Migrator", "ForceRerun: sync legacy read failed", ex);
                    }
                }

                // Bars legacy — union watched symbols (match by Symbol name
                // case-insensitive). Also pull historicalDays etc. if the
                // legacy value differs from default.
                if (foundBars)
                {
                    try
                    {
                        string raw = File.ReadAllText(JournifiNTPaths.LegacyBarsSettingsPath);
                        string wrapped = "{ \"bars\": " + raw + " }";
                        var parsed = JournifiNTJson.Deserialize(wrapped);
                        if (parsed?.Bars != null)
                        {
                            // Adopt non-default scalar settings only if the user
                            // hasn't already customized them in v3.
                            if (current.Bars.HistoricalDays == 30 && parsed.Bars.HistoricalDays != 30)
                                current.Bars.HistoricalDays = parsed.Bars.HistoricalDays;
                            if (current.Bars.RetentionDays == 90 && parsed.Bars.RetentionDays != 90)
                                current.Bars.RetentionDays = parsed.Bars.RetentionDays;

                            // Union the watched-symbols lists.
                            if (current.Bars.WatchedSymbols == null)
                                current.Bars.WatchedSymbols = new List<JournifiNTWatchedSymbol>();
                            var existing = new HashSet<string>(
                                current.Bars.WatchedSymbols.Select(w => w.Symbol ?? ""),
                                StringComparer.OrdinalIgnoreCase);
                            foreach (var w in parsed.Bars.WatchedSymbols ?? new List<JournifiNTWatchedSymbol>())
                            {
                                if (string.IsNullOrWhiteSpace(w.Symbol)) continue;
                                if (existing.Contains(w.Symbol)) continue;
                                current.Bars.WatchedSymbols.Add(w);
                                existing.Add(w.Symbol);
                                result.BarsSymbolsMerged++;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        JournifiNTLog.Error("Migrator", "ForceRerun: bars legacy read failed", ex);
                    }
                }

                result.Ran = true;
                result.Saved = JournifiNTSettingsStore.Save(current);
                result.Message = result.Saved
                    ? $"Imported {result.SyncDisabledAccountsMerged} disabled account(s) + " +
                      $"{result.BarsSymbolsMerged} watched symbol(s)."
                    : "Save failed after merge — see log.";
                JournifiNTLog.Info("Migrator",
                    $"ForceRerun: {result.Message} (sync={foundSync}, bars={foundBars})");
            }
            catch (Exception ex)
            {
                result.Message = $"ForceRerun error: {ex.Message}";
                JournifiNTLog.Error("Migrator", "ForceRerun failed", ex);
            }
            return result;
        }
    }

    #endregion
}
