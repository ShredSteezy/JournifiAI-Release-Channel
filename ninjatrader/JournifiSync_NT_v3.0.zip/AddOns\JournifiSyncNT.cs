#region Using declarations
using System;
using System.Collections.Generic;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.Gui.NinjaScript
{
    /// <summary>
    /// JournifiSync NT — unified NinjaTrader 8 AddOn for the Journifi AI journal.
    ///
    /// Replaces the previously separate JournifiSync (executions) and
    /// JournifiBars (bars) AddOns with one orchestrator that runs both as
    /// isolated modules. The "NT" suffix is brand convention so the same
    /// product line can grow to other platforms (JournifiSync QT for
    /// Quantower, JournifiSync SC for SierraCharts, JournifiSync Volumetrica)
    /// while sharing the journal's wire format.
    ///
    /// File layout (NT compiles all .cs in Custom\AddOns\ as one unit):
    ///
    ///   JournifiSyncNT.cs              ← this file: AddOnBase, lifecycle,
    ///                                    module orchestration, version
    ///   JournifiSyncNT.Shared.cs       ← settings persistence, account
    ///                                    mappings, instrument cache, logger
    ///   JournifiSyncNT.SyncModule.cs   ← execution capture, FIFO grouping,
    ///                                    JSON export to JournifiSync\
    ///   JournifiSyncNT.BarsModule.cs   ← BarsRequest pulls, live append,
    ///                                    monthly CSV writes to JournifiBars\
    ///   JournifiSyncNT.UI.Tabs.cs      ← NTWindow shell, factory, menu,
    ///                                    Dashboard + Sync + Bars + Mappings
    ///                                    tab pages
    ///
    /// Module isolation contract: each module's lifecycle calls
    /// (Initialize/Active/Terminated) are wrapped in a per-module try/catch
    /// at the orchestrator boundary in this file's OnStateChange. A single
    /// module crashing must NOT propagate to the other module or to NT
    /// itself. The orchestrator logs the failure and continues.
    ///
    /// Output folders intentionally keep the legacy paths so the journal-side
    /// readers (JournifiSync watcher + NinjaTraderBarSource) need zero
    /// changes during the rollout:
    ///
    ///   C:\NinjaTrader8Data\JournifiSync\        — execution JSONs
    ///   C:\NinjaTrader8Data\JournifiBars\        — bar CSVs + status.json
    ///   C:\NinjaTrader8Data\Journifi\            — unified settings + log
    ///                                              (new in v3, holds the
    ///                                              shared mappings + the
    ///                                              merged settings.json)
    ///
    /// On first run we COPY the legacy settings.json files from the two
    /// per-module folders into the new unified Journifi\settings.json,
    /// leaving the originals intact so v1/v2 keep working during the
    /// parallel-running window.
    ///
    /// Status: v3.0.0-alpha — Phases 1-4 done (scaffold, shared infra,
    /// window shell, SyncModule lift). BarsModule (Phase 5) and the tab
    /// content (Phases 6-9) still to come. During parallel running with
    /// JournifiSync v2.0.1, both AddOns capture the same executions and
    /// dedup by ExecutionId — output is identical regardless of which one
    /// "wins" a given file write race.
    ///
    /// Developed for AlphaWolfTrader by Claude (Anthropic). v3.0 — May 2026.
    /// </summary>
    public class JournifiSyncNT : AddOnBase
    {
        #region Singleton & static access

        private static JournifiSyncNT instance;
        public static JournifiSyncNT Instance => instance;

        #endregion

        #region Constants

        public const string VERSION = "3.0.10-alpha";
        public const string ADDON_NAME = "JournifiSync NT";

        #endregion

        #region Modules

        // Tabs reach modules via JournifiSyncNTBridge (not directly through
        // Instance.Sync / Instance.Bars) because the static Instance is
        // assembly-local: after an NT recompile, old-assembly tabs reading
        // the old-assembly static get null. The Bridge walks all loaded
        // assemblies to find the live JournifiSyncNT and dispatches via
        // dynamic. Public visibility on these properties is required so
        // the DLR can resolve them across assembly boundaries.
        public JournifiSyncNTSyncModule Sync { get; private set; }
        public JournifiSyncNTBarsModule Bars { get; private set; }

        #endregion

        #region Lifecycle

        // Module hooks land here in subsequent phases. Each module call MUST
        // go through TryRunModule() to honor the isolation contract.
        protected override void OnStateChange()
        {
            switch (State)
            {
                case State.SetDefaults:
                    Description = ADDON_NAME + " — unified Journifi AI sync (executions + bars) for NinjaTrader 8.";
                    Name = ADDON_NAME;
                    break;

                case State.Configure:
                    instance = this;
                    // Phase 2: bootstrap shared infrastructure. Load() runs the
                    // legacy migrator on first call (so v1/v2 settings come
                    // forward automatically) and primes the in-memory settings.
                    TryRunModule("Shared", "Bootstrap", () =>
                    {
                        JournifiNTPaths.EnsureDirectories();
                        JournifiNTLog.Info("Orchestrator", new string('=', 60));
                        JournifiNTLog.Info("Orchestrator", $"{ADDON_NAME} v{VERSION} Starting...");
                        JournifiNTLog.Info("Orchestrator", $"Data root: {JournifiNTPaths.NT8DataRoot}");
                        JournifiNTLog.Info("Orchestrator", $"Settings:  {JournifiNTPaths.SettingsPath}");
                        JournifiNTLog.Info("Orchestrator", new string('=', 60));
                        JournifiNTSettingsStore.Load();
                    });
                    // Create module instances. We instantiate at Configure but
                    // delay Initialize (which subscribes to NT events + starts
                    // background tasks) until Active, mirroring v1/v2's order.
                    TryRunModule("Sync", "Construct", () => Sync = new JournifiSyncNTSyncModule());
                    TryRunModule("Bars", "Construct", () => Bars = new JournifiSyncNTBarsModule());
                    break;

                case State.Active:
                    // Each module starts its own event subscriptions + tasks.
                    // TryRunModule ensures one's failure can't kill the other.
                    TryRunModule("Sync", "Initialize", () => Sync?.Initialize());
                    TryRunModule("Bars", "Initialize", () => Bars?.Initialize());
                    break;

                case State.Terminated:
                    // Bounded shutdown — each module awaits its own task with
                    // a short timeout inside Cleanup. Order matters slightly:
                    // Bars first (lighter teardown, releases BarsRequests),
                    // Sync second (drains its export queue).
                    TryRunModule("Bars", "Cleanup", () => Bars?.Cleanup());
                    TryRunModule("Sync", "Cleanup", () => Sync?.Cleanup());
                    TryRunModule("Shared", "Shutdown", () =>
                    {
                        JournifiNTLog.Info("Orchestrator", $"{ADDON_NAME} v{VERSION} shutting down.");
                    });
                    instance = null;
                    break;
            }
        }

        #endregion

        #region Settings accessors (used by bridge for cross-assembly UI)

        // The Mappings tab edits accountMappings. After an NT recompile,
        // the old-assembly tab's JournifiNTSettingsStore.Current static
        // points at stale data (loaded by the old assembly). To keep edits
        // landing in the live settings store, the tab calls these methods
        // through JournifiSyncNTBridge, which resolves to the NEW assembly's
        // orchestrator — and from inside these methods the SettingsStore
        // static resolves to the NEW assembly's static.
        //
        // Returns/accepts plain Dictionary so cross-assembly DLR dispatch
        // doesn't trip on a custom POCO type's identity.

        public Dictionary<string, string> GetAccountMappings()
        {
            var src = JournifiNTSettingsStore.Current?.AccountMappings;
            return src == null
                ? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
                : new Dictionary<string, string>(src, StringComparer.OrdinalIgnoreCase);
        }

        public bool SetAccountMappings(Dictionary<string, string> map)
        {
            var settings = JournifiNTSettingsStore.Current;
            if (settings == null) return false;
            settings.AccountMappings = map ?? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            return JournifiNTSettingsStore.Save();
        }

        /// <summary>
        /// Returns a string describing the result of a legacy-migration
        /// re-run. Triggered by the About tab's "Re-run Migration" button.
        /// Returns the message via the bridge as a plain string for cross-
        /// assembly safety; the underlying RerunResult struct can hold
        /// counts but the UI only renders the message line.
        /// </summary>
        public string RerunLegacyMigration()
        {
            var result = JournifiNTLegacyMigrator.ForceRerun();
            // Reload the modules' in-memory caches so the new merged data
            // takes effect without an NT restart.
            try { Sync?.ReloadSettings(); } catch { }
            try { Bars?.ReloadSettings(); } catch { }
            return result?.Message ?? "Migration result unavailable.";
        }

        #endregion

        #region Module orchestration

        /// <summary>
        /// Run a module lifecycle action inside its own try/catch boundary.
        /// A module's failure is logged but never thrown to the caller — the
        /// other module and NT itself stay healthy. Returns true if the
        /// action completed cleanly, false on caught exception.
        /// </summary>
        /// <param name="moduleName">Display name used in the log line.</param>
        /// <param name="phase">Lifecycle phase ("Initialize", "Active", "Cleanup").</param>
        /// <param name="action">The module call. Should be idempotent and
        /// catch its own expected failures internally — TryRunModule is a
        /// safety net, not a substitute for module-level error handling.</param>
        internal static bool TryRunModule(string moduleName, string phase, Action action)
        {
            if (action == null) return false;
            try
            {
                action();
                return true;
            }
            catch (Exception ex)
            {
                try
                {
                    // Phase 2 wires the shared logger; until then we route
                    // through NT's Output window directly.
                    NinjaTrader.Code.Output.Process(
                        $"[JournifiSync NT] [ERROR] {moduleName}.{phase} failed: {ex.Message}",
                        PrintTo.OutputTab1);
                }
                catch { /* swallow — never let logging crash the orchestrator */ }
                return false;
            }
        }

        #endregion
    }
}
