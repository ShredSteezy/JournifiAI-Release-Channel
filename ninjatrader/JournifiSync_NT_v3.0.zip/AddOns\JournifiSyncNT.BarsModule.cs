#region Using declarations
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.Gui.NinjaScript
{
    // =====================================================================
    //  BarsModule — historical + live OHLCV bar export
    // =====================================================================
    //
    //  Ported from JournifiBars v1.1.1 (NinjaTrader/AddOns/JournifiBars_v1.0/
    //  JournifiBars.cs) with the same seam-level changes as SyncModule:
    //
    //    Removed                          Replaced with
    //    ─────────────────────────────────────────────────────────────────
    //    AddOnBase base class             plain class, lifecycle driven by
    //                                     the orchestrator
    //    OnStateChange()                  Initialize() / Cleanup()
    //    Local outputFolder hardcoded     JournifiNTPaths.BarsDir
    //    Local settings.json reader       JournifiNTSettingsStore.Bars.*
    //    Local JournifiBarsConfig POCO    JournifiNTBarsSettings (from Shared)
    //    Local WatchedSymbolEntry POCO    JournifiNTWatchedSymbol (from Shared)
    //    LogMessage(level, msg)           JournifiNTLog.Info / .Warn / .Error
    //    BarRow class                     JournifiSyncNTBarRow (renamed to
    //                                     avoid collision with v1.1.1's BarRow)
    //    JournifiBarsStats class          JournifiSyncNTBarsStats
    //
    //  EVERYTHING ELSE — the historical .Request() callback, the connect-
    //  watcher polling, monthly CSV files with overwrite-on-duplicate dedup,
    //  atomic temp+rename writes, TradingHours fallback, ToUnixSeconds
    //  Local-time handling, ParseTimeframe supporting {1m, 5m, 15m, 1h, 4h,
    //  60m, 240m} — is a verbatim carry-forward of the v1.1.1 behavior. The
    //  journal-side NinjaTraderBarSource reads
    //  `<SYMBOL>\<YYYY-MM>_<TF>.csv` files at the unchanged BarsDir path with
    //  zero updates required.
    //
    //  REFACTORED in v3.0: the live-bar pipeline uses the official
    //  <c>BarsUpdateEventArgs.MinIndex/MaxIndex</c> properties on the .Update
    //  event PLUS a per-REQUEST <c>LiveState.Forming</c> index (v3.0.14; the
    //  per-key watermark before it had an off-by-one in the new-bar range and
    //  wrote every SECOND closed bar — Measurement Day 2026-10-31 §D). The index
    //  isn't there to infer "new bar" from Count growth (v1.1.1's approach,
    //  which missed late corrections) — instead it lets us distinguish three
    //  cases:
    //    1. New bar closed   → MaxIndex grew → write the now-closed bars,
    //                           exclude the new in-progress one
    //    2. Late correction  → MinIndex < watermark → honor NT's range
    //    3. In-progress tick → MaxIndex == watermark → SKIP
    //  Case 3 is critical: NT fires Update on every tick (potentially
    //  many per second per symbol × per timeframe), and the pre-watermark
    //  refactor rewrote the entire monthly CSV each time. Writing only on
    //  bar-close keeps the disk file at most one timeframe-period stale,
    //  which is fine for trade-card rendering (the trade is in the past).

    #region Module class

    public class JournifiSyncNTBarsModule
    {
        #region Constants

        // Connect-watcher cadence — poll every 30s for the first connected
        // data-feed if the initial startup pull bailed because no feeds were
        // active. The watcher fires PullAllWatchedSymbols on the first poll
        // that finds a feed, then self-cancels.
        private const int CONNECT_WATCHER_INTERVAL_MS = 30_000;
        private const int CONNECT_WATCHER_MAX_ATTEMPTS = 20;

        // Heartbeat — how often status.json gets refreshed so the journal
        // can render "AddOn is alive". Doesn't affect bar pull cadence.
        private const int HEARTBEAT_MS = 30_000;

        // Initial pull delay — give NT time to finish connecting feeds
        // before we fire BarsRequests (which fail silently on disconnected
        // feeds).
        private const int INITIAL_PULL_DELAY_MS = 5_000;

        // v3.0.14 — pull protection window. A historical pull may not overwrite a
        // bar the live path wrote if that bar closed within this many seconds:
        // the live path saw every tick, the historical server may lag the tape
        // (measured 2026-10-31: pulls revised live-written closed bars 173 of
        // ~905 times; 34 of 935 pulls ended 2–6 minutes behind). The next pull,
        // five minutes later, is free to revise the same bar.
        private const int PULL_PROTECT_RECENT_SEC = 90;

        // v3.0.14 — the pull's own LAST returned bar is protected from the pull only
        // while it is this recent: a server behind the tape (the measured tail is
        // 2–6 min) is not authoritative for its newest bar, but a session's last
        // bar hours old is not "a server behind the tape", and the next pull must
        // be free to correct it (second refute pass).
        private const int PULL_PROTECT_LAST_MIN = 10;

        // v3.0.14 — a live Update that arrives BEFORE the request's historical
        // callback (no seed yet) writes at most this many bars below the one that
        // just closed. Bounds the telemetry a wide pre-callback event would skew,
        // and the write goes through the pull's protection window because the
        // key's PREVIOUS request may have written those rows live.
        private const int PRE_SEED_MAX_BARS = 3;

        #endregion

        #region Fields

        public JournifiSyncNTBarsStats Stats { get; } = new JournifiSyncNTBarsStats();

        // Settings cached pointer so we re-read the latest values on each
        // call (UI mutations land in the store directly).
        private JournifiNTBarsSettings BarsSettings => JournifiNTSettingsStore.Current.Bars;

        // Lifecycle
        private CancellationTokenSource cts;
        private System.Threading.Timer heartbeatTimer;
        private System.Threading.Timer connectWatcherTimer;
        private int connectWatcherAttempts;
        private bool firstPullDone;
        private bool initialized;

        // Per-(symbol, tf) state
        private readonly object fileLock = new object();
        private readonly object configLock = new object();
        private readonly ConcurrentDictionary<string, BarsRequest> activeRequests
            = new ConcurrentDictionary<string, BarsRequest>();

        // v3.0.14 — per-REQUEST live state. `Forming` is the index of the bar
        // NinjaTrader is still building, as last seen through THIS request's own
        // Update / Request callbacks (-1 before either fires). An index is only
        // meaningful inside one request's series: a 30-day startup pull and a
        // 60-minute heal pull of the same (symbol, tf) have different index
        // spaces, and the pre-3.0.14 string-keyed watermark let a disposed
        // request's late event corrupt its replacement's state. StartBarsRequest
        // creates one per request and the two closures capture it; a superseded
        // request can only ever touch its own object.
        private sealed class LiveState
        {
            public int Forming = -1;
            public string Source = "pull";
            // First index of a live range whose write FAILED (read abort, folder or
            // write exception), -1 when none. The next live range starts here, so
            // the live path itself re-offers the bar; without it the advance-
            // before-write made a failed live write final (refuters 2026-11-08).
            public int RetryFrom = -1;
        }

        // v3.0.14 — per-(symbol, tf) telemetry for the Bars Integrity indicator
        // (status.json `live.perKey`): "feed alive" and "last close" per key, so
        // one silent key is visible beside a healthy one. Diagnostics only — the
        // range rule reads LiveState, never this.
        private sealed class KeyState
        {
            public DateTime LastUpdateAt = DateTime.MinValue;
            public DateTime LastCloseAt = DateTime.MinValue;
            public int Forming = -1;
        }
        private readonly ConcurrentDictionary<string, KeyState> keyStates
            = new ConcurrentDictionary<string, KeyState>();

        // Session counters
        private DateTime lastWriteAt = DateTime.MinValue;
        private DateTime lastUpdateFireAt = DateTime.MinValue;
        private long barsWrittenSinceStart;

        // v3.0.14 — Bars Integrity counters (status.json `live` / `pulls`).
        private long liveClosesTotal;        // closed bars written by the SEEDED live path, one per bar per key (fallback writes excluded)
        private long liveCatchUpWrites;      // live writes that covered more than one closed bar
        private long liveFallbackWrites;     // live writes before this request had a seed
        private long liveCorrections;        // NT reported a change to an older closed bar
        private long pullsAborted;           // month-file writes that did not complete (read abort, folder or write failure)
        private long pullsFailed;            // BarsRequest callbacks that returned an error; a UserAbort counts only on the key's CURRENT request (one this module already removed is a supersession, not counted)
        private long pullsEmpty;             // callbacks that returned NO bars — a closed-market heal window, not a failure
        private bool lastPullOk;             // the last callback succeeded or was empty (lastAt / lastSource move on failures too)
        private bool lastPullEmpty;          // the last callback was an EMPTY heal window (the card says so; a quiet pull reads new 0 too)
        private long healPullsWithRevisions; // heal pulls that changed at least one row outside the protection window
        private DateTime lastPullAt = DateTime.MinValue;
        private string lastPullSource = "none";   // one of six fixed literals (none + the five triggers; a defensive "unknown" no caller can produce), never free text — JsonEscape is minimal
        private int lastPullNew, lastPullChanged, lastPullProtected;
        private bool selfHealSkippedOffline;

        // Per-symbol last-write tracking — exposes which specific watched
        // symbol is lagging (e.g., MNQ writing every 5m but ES went silent).
        // Distinct from the global `lastWriteAt` which only tracks the
        // most-recent write across all symbols.
        private readonly ConcurrentDictionary<string, DateTime> lastWritePerSymbol
            = new ConcurrentDictionary<string, DateTime>();

        // v3.1+ — Self-heal sweep state. Compensates for NT's BarsUpdate
        // live stream dropping events under load. Runs every
        // SelfHealIntervalMinutes (default 5), re-pulls the last
        // SelfHealLookbackMinutes of 1m bars via a fresh BarsRequest, and
        // merges them into the file using the same dedup as live writes.
        private System.Threading.Timer selfHealTimer;
        private DateTime lastSelfHealAt = DateTime.MinValue;
        private long selfHealRunsTotal;        // # of sweep cycles fired
        private long selfHealBarsFilled;       // # of NEW bars added (vs already-on-disk)
        private long selfHealBarsRevised;      // # of bars whose OHLCV changed on re-pull

        // v3.0.4+ — execution-driven auto-roll. The auto-managed contract set is
        // separate from (and additive to) the manual WatchedSymbols. A fill on a
        // not-yet-subscribed futures contract (SyncModule → NoteTradedContract)
        // adds it here and subscribes its bars; same-root predecessors are marked
        // for retirement after RollRetentionDays. Persisted as "ROOT|CONTRACT" so
        // a restart re-subscribes the right contract without a fresh fill. All
        // access is guarded by autoLock.
        private sealed class AutoContractState
        {
            public string Root;            // MasterInstrument.Name, e.g. "MNQ"
            public DateTime? RetireAtUtc;   // null = active; set = superseded, retire when due
        }
        private readonly object autoLock = new object();
        private readonly Dictionary<string, AutoContractState> autoContracts
            = new Dictionary<string, AutoContractState>(StringComparer.OrdinalIgnoreCase);

        #endregion

        #region Public API surface (UI + orchestrator)

        public bool IsEnabled => BarsSettings.Enabled;
        public string OutputFolder => JournifiNTPaths.BarsDir;
        public string SettingsFilePath => JournifiNTPaths.SettingsPath;
        public long BarsWrittenSinceStart => Interlocked.Read(ref barsWrittenSinceStart);
        public DateTime LastWriteAt => lastWriteAt;
        // Last time NinjaTrader fired an OnBarsLiveUpdate for ANY watched
        // symbol/timeframe, regardless of whether the write actually changed
        // disk state. This is the "feed is alive" health signal — distinct
        // from LastWriteAt which only moves when bytes change on disk. The
        // distinction matters because in-progress tick updates + matched-
        // already-on-disk dedup both return without bumping LastWriteAt,
        // even though NT is clearly still streaming.
        public DateTime LastUpdateFireAt => lastUpdateFireAt;
        // Snapshot of last-write times keyed by symbol — exposes which
        // specific watched symbol is lagging when one feed goes silent
        // while others stay healthy. Empty when no writes have happened yet.
        public IReadOnlyDictionary<string, DateTime> LastWritePerSymbol
        {
            get
            {
                // Defensive copy so UI iteration can't race the producer.
                var snapshot = new Dictionary<string, DateTime>(lastWritePerSymbol.Count);
                foreach (var kvp in lastWritePerSymbol) snapshot[kvp.Key] = kvp.Value;
                return snapshot;
            }
        }
        public string[] ConnectedFeedNames => GetConnectedConnectionNames();

        // v3.1+ — Self-heal sweep visibility for the dashboard.
        public DateTime LastSelfHealAt => lastSelfHealAt;
        public long SelfHealRunsTotal => Interlocked.Read(ref selfHealRunsTotal);
        public long SelfHealBarsFilled => Interlocked.Read(ref selfHealBarsFilled);
        public long SelfHealBarsRevised => Interlocked.Read(ref selfHealBarsRevised);
        public bool SelfHealEnabled => (BarsSettings?.SelfHealIntervalMinutes ?? 0) > 0;

        // v3.0.14 — Bars Integrity for the dashboard.
        public long LiveClosesTotal => Interlocked.Read(ref liveClosesTotal);
        public long LiveCatchUpWrites => Interlocked.Read(ref liveCatchUpWrites);
        public DateTime LastPullAt => lastPullAt;
        public string LastPullSummary => lastPullAt == DateTime.MinValue
            ? "—"
            : !lastPullOk
                ? $"{lastPullSource}: FAILED (see log)"
                : lastPullEmpty
                    ? $"{lastPullSource}: no bars in the window"
                    : $"{lastPullSource}: new {lastPullNew}, changed {lastPullChanged}, protected {lastPullProtected}";

        public void SetEnabled(bool enabled)
        {
            BarsSettings.Enabled = enabled;
            Stats.IsRunning = enabled;
            JournifiNTSettingsStore.Save();
            JournifiNTLog.Info("Bars", $"Bars {(enabled ? "enabled" : "disabled")}");
        }

        /// <summary>
        /// Public read-only snapshot of the watched symbols list. Returns
        /// fresh list copies so the UI can display without holding the lock.
        /// </summary>
        public List<JournifiNTWatchedSymbol> GetWatchedSymbolsSnapshot()
        {
            lock (configLock)
            {
                var watched = BarsSettings.WatchedSymbols ?? new List<JournifiNTWatchedSymbol>();
                return watched.Select(w => new JournifiNTWatchedSymbol
                {
                    Symbol = w.Symbol,
                    Timeframes = new List<string>(w.Timeframes ?? new List<string>())
                }).ToList();
            }
        }

        /// <summary>
        /// Add a symbol to the watched list and persist. Returns false if
        /// already present (case-insensitive) or input is invalid.
        /// </summary>
        public bool AddWatchedSymbol(string symbolFullName, IEnumerable<string> timeframes)
        {
            if (string.IsNullOrWhiteSpace(symbolFullName)) return false;
            string sym = symbolFullName.Trim();
            var tfList = (timeframes ?? new List<string>())
                .Where(t => !string.IsNullOrWhiteSpace(t))
                .Select(t => t.Trim())
                .Distinct()
                .ToList();
            if (tfList.Count == 0) tfList.Add("1m");

            lock (configLock)
            {
                if (BarsSettings.WatchedSymbols == null)
                    BarsSettings.WatchedSymbols = new List<JournifiNTWatchedSymbol>();
                if (BarsSettings.WatchedSymbols.Any(w =>
                    string.Equals(w.Symbol, sym, StringComparison.OrdinalIgnoreCase)))
                {
                    return false;
                }
                BarsSettings.WatchedSymbols.Add(new JournifiNTWatchedSymbol
                {
                    Symbol = sym,
                    Timeframes = tfList
                });
            }
            JournifiNTSettingsStore.Save();
            JournifiNTLog.Info("Bars", $"Added watched symbol: {sym} ({string.Join(",", tfList)})");
            return true;
        }

        /// <summary>
        /// Remove a symbol from the watched list, persist, and cancel any
        /// active BarsRequests for it. Returns true if removed.
        /// </summary>
        public bool RemoveWatchedSymbol(string symbolFullName)
        {
            if (string.IsNullOrWhiteSpace(symbolFullName)) return false;
            bool removed;
            lock (configLock)
            {
                if (BarsSettings.WatchedSymbols == null) return false;
                int before = BarsSettings.WatchedSymbols.Count;
                BarsSettings.WatchedSymbols.RemoveAll(w =>
                    string.Equals(w.Symbol, symbolFullName, StringComparison.OrdinalIgnoreCase));
                removed = BarsSettings.WatchedSymbols.Count < before;
            }
            if (removed)
            {
                JournifiNTSettingsStore.Save();
                // Tear down any active live-update subscriptions for this symbol —
                // otherwise BarsRequest keeps firing and appending to a file the
                // user no longer wants tracked.
                var keysToDrop = activeRequests.Keys
                    .Where(k => k.StartsWith(symbolFullName + "|", StringComparison.OrdinalIgnoreCase))
                    .ToArray();
                foreach (var k in keysToDrop)
                {
                    if (activeRequests.TryRemove(k, out BarsRequest req))
                    {
                        try { req?.Dispose(); } catch { /* gone */ }
                    }
                    keyStates.TryRemove(k, out _);
                }
                JournifiNTLog.Info("Bars",
                    $"Removed watched symbol: {symbolFullName} (cancelled {keysToDrop.Length} live subscription(s))");
            }
            return removed;
        }

        /// <summary>
        /// Manually re-pull bars for all watched symbols. Also restarts the
        /// connect-watcher if no feeds were connected at trigger time.
        /// </summary>
        public void ResyncAll()
        {
            firstPullDone = false;
            PullAllWatchedSymbols("manual-resync");

            // If pull found no feeds, ensure the connect-watcher is running
            // so we'll auto-retry when one appears. Handles the case where
            // the original watcher gave up after MAX_ATTEMPTS.
            if (!firstPullDone && connectWatcherTimer == null && cts != null)
            {
                connectWatcherAttempts = 0;
                JournifiNTLog.Info("Bars",
                    "Resync found no feeds — restarting connect-watcher to retry when one appears.");
                connectWatcherTimer = new System.Threading.Timer(
                    _ => SafeExecute(CheckConnectAndRetry),
                    null,
                    CONNECT_WATCHER_INTERVAL_MS,
                    CONNECT_WATCHER_INTERVAL_MS);
            }
        }

        /// <summary>Refresh in-memory settings cache. Called by the UI tab after edits.</summary>
        public void ReloadSettings()
        {
            JournifiNTLog.Info("Bars",
                $"Settings reloaded ({BarsSettings.WatchedSymbols?.Count ?? 0} watched symbol(s), " +
                $"historicalDays={BarsSettings.HistoricalDays})");
        }

        #endregion

        #region Lifecycle

        public void Initialize()
        {
            if (initialized)
            {
                JournifiNTLog.Warn("Bars", "Initialize called twice — ignoring.");
                return;
            }
            try
            {
                if (!Directory.Exists(JournifiNTPaths.BarsDir))
                    Directory.CreateDirectory(JournifiNTPaths.BarsDir);

                JournifiNTLog.Info("Bars", $"Output folder: {JournifiNTPaths.BarsDir}");
                JournifiNTLog.Info("Bars",
                    $"Watched: {BarsSettings.WatchedSymbols?.Count ?? 0} symbol(s), " +
                    $"historical={BarsSettings.HistoricalDays}d, " +
                    $"tradingHours='{BarsSettings.TradingHoursTemplate}'");

                if ((BarsSettings.WatchedSymbols?.Count ?? 0) == 0)
                {
                    JournifiNTLog.Info("Bars",
                        "No watched symbols configured. Add some via the Bars tab and they'll be pulled immediately.");
                }

                // v3.0.4+ — rehydrate the persisted auto-roll set so the startup
                // pull below re-subscribes the right contract(s) without waiting
                // for the day's first fill.
                RehydrateAutoContracts();

                cts = new CancellationTokenSource();
                Stats.IsRunning = true;
                Stats.StartTime = DateTime.Now;

                // Schedule the initial pull on a 5s delay so NT has time to
                // connect data feeds before we fire BarsRequests.
                Task.Run(async () =>
                {
                    try
                    {
                        await Task.Delay(INITIAL_PULL_DELAY_MS, cts.Token);
                        if (cts.IsCancellationRequested) return;
                        PullAllWatchedSymbols("startup");
                    }
                    catch (OperationCanceledException) { /* expected on shutdown */ }
                    catch (Exception ex)
                    {
                        JournifiNTLog.Error("Bars", "Initial pull failed", ex);
                    }
                });

                // Heartbeat — keep status.json fresh so the journal knows we're alive.
                heartbeatTimer = new System.Threading.Timer(
                    _ => SafeExecute(WriteStatus), null,
                    1000, HEARTBEAT_MS);

                // Connect-watcher — see CheckConnectAndRetry for the bounded
                // retry semantics. Starts one watcher tick AFTER the scheduled
                // startup pull so we don't race it.
                connectWatcherAttempts = 0;
                firstPullDone = false;
                connectWatcherTimer = new System.Threading.Timer(
                    _ => SafeExecute(CheckConnectAndRetry), null,
                    INITIAL_PULL_DELAY_MS + CONNECT_WATCHER_INTERVAL_MS,
                    CONNECT_WATCHER_INTERVAL_MS);

                initialized = true;
                JournifiNTLog.Info("Bars", "Module initialized successfully.");
            }
            catch (Exception ex)
            {
                JournifiNTLog.Error("Bars", "Initialization failed", ex);
            }
        }

        public void Cleanup()
        {
            if (!initialized) return;
            try
            {
                JournifiNTLog.Info("Bars", "Module shutting down...");

                cts?.Cancel();
                heartbeatTimer?.Dispose();
                heartbeatTimer = null;
                connectWatcherTimer?.Dispose();
                connectWatcherTimer = null;
                // v3.1+ — tear down self-heal timer
                selfHealTimer?.Dispose();
                selfHealTimer = null;

                // Dispose any in-flight BarsRequests — without Dispose() the
                // request keeps internal subscriptions alive past assembly
                // unload, including the live-Update callback we registered.
                foreach (var kvp in activeRequests.ToArray())
                {
                    // Remove BEFORE disposing, like every other removal site: the
                    // UserAbort NT raises for the disposal then finds no current
                    // request and is logged as superseded, never as a failure.
                    // Dispose what was REMOVED (a sweep still in flight may have
                    // replaced the key since the snapshot) and the snapshot's value
                    // too when it differs — nothing leaks a live-Update subscription.
                    activeRequests.TryRemove(kvp.Key, out BarsRequest current);
                    try { current?.Dispose(); } catch { /* gone */ }
                    if (!ReferenceEquals(current, kvp.Value))
                        try { kvp.Value?.Dispose(); } catch { /* gone */ }
                }
                activeRequests.Clear();
                keyStates.Clear();
                // v3.0.4+ — drop the in-memory auto-set; it rehydrates from the
                // persisted settings on the next Initialize.
                lock (autoLock) { autoContracts.Clear(); }

                // Final status flush with isRunning=false so the journal
                // shows accurate "stopped" state.
                Stats.IsRunning = false;
                SafeExecute(WriteStatus);

                JournifiNTLog.Info("Bars",
                    $"Shutdown complete. Bars written this session: {barsWrittenSinceStart}");

                cts?.Dispose();
                initialized = false;
            }
            catch (Exception ex)
            {
                JournifiNTLog.Error("Bars", "Cleanup error", ex);
            }
        }

        #endregion

        #region Bar pull mechanics

        private void PullAllWatchedSymbols(string trigger)
        {
            var watched = BarsSettings.WatchedSymbols;
            // v3.0.4+ — auto-managed (rolled) contracts are pulled alongside the
            // manual watchlist, so "nothing to pull" must consider both.
            List<string> autoToPull;
            lock (autoLock) { autoToPull = autoContracts.Keys.ToList(); }
            if ((watched == null || watched.Count == 0) && autoToPull.Count == 0)
            {
                JournifiNTLog.Info("Bars", $"PullAll ({trigger}): nothing to pull.");
                // Set firstPullDone so the connect-watcher self-cancels on its
                // next tick. With zero watched symbols there's nothing to
                // retry; polling would just spam the log every 30s for 20
                // attempts. The watcher will resume automatically the next
                // time AddWatchedSymbol → ResyncAll re-arms it.
                firstPullDone = true;
                return;
            }

            // Pre-flight connection check — BarsRequest silently returns empty
            // when no feed is connected, so log loudly upfront.
            string[] connectedNames = GetConnectedConnectionNames();
            if (connectedNames.Length == 0)
            {
                JournifiNTLog.Warn("Bars",
                    $"PullAll ({trigger}): no data-feed connections active. " +
                    "BarsRequests will return no data until you connect to a provider in NT.");
                return;
            }
            JournifiNTLog.Info("Bars",
                $"PullAll ({trigger}): connected feeds → {string.Join(", ", connectedNames)}");

            DateTime fromDate = NtNow.AddDays(-BarsSettings.HistoricalDays).Date;   // NT's clock: a replay pulls the replay's window
            DateTime toDate = NtNow;

            // Null-safe: `watched` may legitimately be null here now that the
            // guard above lets an auto-contracts-only pull through (fresh install
            // that never pinned a manual symbol). Use this count in every log line
            // below instead of dereferencing `watched.Count` directly.
            int watchedCount = watched?.Count ?? 0;
            JournifiNTLog.Info("Bars",
                $"PullAll ({trigger}): {watchedCount} symbol(s), from {fromDate:yyyy-MM-dd} to {toDate:yyyy-MM-dd}");

            // v3.1+ — when SubscribeOneMinuteOnly is enabled, force the
            // subscription list to just ["1m"] regardless of what the user
            // configured per symbol. Higher timeframes are derived in
            // JournifiAI via aggregation. Rationale documented on the
            // JournifiNTBarsSettings.SubscribeOneMinuteOnly property.
            //
            // We honor user-configured TFs when the toggle is OFF so existing
            // installs that opt out keep their prior multi-TF behavior.
            bool oneMinOnly = BarsSettings?.SubscribeOneMinuteOnly ?? false;
            var effectiveTfs = oneMinOnly
                ? new List<string> { "1m" }
                : (List<string>)null;

            int requestsFired = 0;
            foreach (var entry in (watched ?? new List<JournifiNTWatchedSymbol>()))
            {
                if (cts == null || cts.IsCancellationRequested) return;
                var tfsToFire = effectiveTfs ?? (entry.Timeframes ?? new List<string>());
                foreach (string tf in tfsToFire)
                {
                    try
                    {
                        StartBarsRequest(entry.Symbol, tf, fromDate, toDate, trigger);
                        requestsFired++;
                    }
                    catch (Exception ex)
                    {
                        JournifiNTLog.Error("Bars",
                            $"StartBarsRequest failed for {entry.Symbol} {tf}", ex);
                    }
                }
            }

            // v3.0.4+ — pull the auto-managed (rolled) contracts on the same feed
            // pre-flight. Their TF set honors SubscribeOneMinuteOnly (else the
            // union of the watchlist's TFs) — see EffectiveAutoTfs.
            if (autoToPull.Count > 0)
            {
                var autoTfs = EffectiveAutoTfs();
                foreach (string contract in autoToPull)
                {
                    if (cts == null || cts.IsCancellationRequested) return;
                    foreach (string tf in autoTfs)
                    {
                        try
                        {
                            StartBarsRequest(contract, tf, fromDate, toDate, trigger);
                            requestsFired++;
                        }
                        catch (Exception ex)
                        {
                            JournifiNTLog.Error("Bars",
                                $"StartBarsRequest failed for auto-contract {contract} {tf}", ex);
                        }
                    }
                }
                JournifiNTLog.Info("Bars",
                    $"PullAll ({trigger}): auto-roll set → {string.Join(", ", autoToPull)} ({autoTfs.Count} TF each).");
            }

            if (requestsFired > 0)
            {
                firstPullDone = true;
                JournifiNTLog.Info("Bars",
                    oneMinOnly
                        ? $"PullAll: subscribed to 1m only ({watchedCount} symbols + {autoToPull.Count} auto); higher TFs derived in JournifiAI."
                        : $"PullAll: subscribed to user-configured timeframes ({watchedCount} symbols + {autoToPull.Count} auto).");
                // Kick off the self-heal sweep loop now that initial pulls
                // are queued. EnsureSelfHealTimer is idempotent — safe to
                // call on every PullAll even if a timer already exists.
                EnsureSelfHealTimer();
            }
        }

        /// <summary>
        /// Connect-watcher tick. See header comments — three exit paths:
        ///   1. firstPullDone is true → self-dispose
        ///   2. MAX_ATTEMPTS exceeded → log hint, self-dispose
        ///   3. Feed appears → fire delayed pull (which flips firstPullDone
        ///      and triggers exit 1 on the next tick)
        /// </summary>
        private void CheckConnectAndRetry()
        {
            if (firstPullDone)
            {
                try { connectWatcherTimer?.Dispose(); } catch { /* gone */ }
                connectWatcherTimer = null;
                return;
            }

            connectWatcherAttempts++;
            if (connectWatcherAttempts > CONNECT_WATCHER_MAX_ATTEMPTS)
            {
                int elapsedSec = (connectWatcherAttempts - 1) * CONNECT_WATCHER_INTERVAL_MS / 1000;
                JournifiNTLog.Warn("Bars",
                    $"Connect-watcher giving up after {connectWatcherAttempts - 1} attempts " +
                    $"({elapsedSec}s without a connected feed). Connect a provider and click Resync.");
                try { connectWatcherTimer?.Dispose(); } catch { /* gone */ }
                connectWatcherTimer = null;
                return;
            }

            string[] feeds = GetConnectedConnectionNames();
            if (feeds.Length == 0) return; // still no feed; wait for next tick

            JournifiNTLog.Info("Bars",
                $"Connect-watcher: feed(s) now active ({string.Join(", ", feeds)}) — " +
                $"firing delayed pull (attempt {connectWatcherAttempts}).");
            PullAllWatchedSymbols("delayed-connect");
        }

        private static string[] GetConnectedConnectionNames()
        {
            var names = new List<string>();
            try
            {
                lock (Connection.Connections)
                {
                    foreach (Connection c in Connection.Connections)
                    {
                        if (c?.Status == ConnectionStatus.Connected)
                        {
                            string name = c.Options?.Name ?? c.Options?.Provider.ToString() ?? "Unknown";
                            names.Add(name);
                        }
                    }
                }
            }
            catch { /* best-effort */ }
            return names.ToArray();
        }

        private void StartBarsRequest(string symbolFullName, string timeframe,
            DateTime fromDate, DateTime toDate, string source)
        {
            // Route the lookup through our shared cache (single dict shared
            // with SyncModule, so repeated lookups for the same contract are
            // free after the first hit).
            Instrument instrument = JournifiNTInstrumentCache.Resolve(symbolFullName);
            if (instrument == null)
            {
                JournifiNTLog.Error("Bars",
                    $"Instrument not found: '{symbolFullName}'. Open a chart or watchlist with it in NT first.");
                return;
            }

            BarsPeriod period = ParseTimeframe(timeframe);
            if (period == null)
            {
                JournifiNTLog.Error("Bars",
                    $"Unsupported timeframe '{timeframe}' for {symbolFullName}. Supported: 1m, 5m, 15m, 1h, 4h.");
                return;
            }

            string key = $"{symbolFullName}|{timeframe}";

            // Dispose any in-flight prior request for this (symbol, tf) so
            // Resync doesn't pile them up. The replacement gets its own LiveState
            // below; the old request's state dies with its closures.
            if (activeRequests.TryRemove(key, out BarsRequest old))
            {
                try { old.Dispose(); } catch { /* gone */ }
            }

            // Resolve TradingHours with a safe fallback. NT's per-feed default
            // ("CME US Index Futures ETH") may not exist on every install;
            // fall back to "Default 24 x 7" which ships with every NT8.
            TradingHours th = TradingHours.Get(BarsSettings.TradingHoursTemplate);
            if (th == null)
            {
                JournifiNTLog.Warn("Bars",
                    $"TradingHours template '{BarsSettings.TradingHoursTemplate}' not found; " +
                    "falling back to 'Default 24 x 7'");
                th = TradingHours.Get("Default 24 x 7");
            }

            var request = new BarsRequest(instrument, fromDate, toDate)
            {
                BarsPeriod = period,
                TradingHours = th
            };
            activeRequests[key] = request;
            var state = new LiveState { Source = string.IsNullOrEmpty(source) ? "unknown" : source };

            // Two subscriptions on the same request. Subscribe to .Update
            // FIRST so any updates that arrive concurrently with the
            // historical load are captured (race-safe). Both the request
            // and the event args are passed through to the handler: we
            // need request.Bars (type Bars) for the actual data and
            // e.MinIndex/e.MaxIndex for the range NT says changed. Both
            // closures capture THIS request's LiveState (v3.0.14).
            request.Update += (sender, e) =>
            {
                SafeExecute(() => OnBarsLiveUpdate(symbolFullName, timeframe, request, e, state));
            };

            request.Request(new Action<BarsRequest, ErrorCode, string>((req, errorCode, errorMessage) =>
            {
                SafeExecute(() => OnBarsResult(symbolFullName, timeframe, req, errorCode, errorMessage, state));
            }));
        }

        private void OnBarsResult(string symbolFullName, string timeframe,
            BarsRequest request, ErrorCode errorCode, string errorMessage, LiveState state)
        {
            string source = state?.Source ?? "unknown";
            string key = $"{symbolFullName}|{timeframe}";
            // Only the key's CURRENT request moves the pull block / telemetry: a
            // request this module disposed itself (a resync during a sweep) may
            // still call back. NT's own @Volume reads UserAbort as "disposed".
            bool currentRequest = activeRequests.TryGetValue(key, out BarsRequest liveReq) && ReferenceEquals(liveReq, request);
            if (errorCode == ErrorCode.UserAbort)
            {
                if (currentRequest)
                {
                    // NinjaTrader aborted the key's LIVE request on its own (this
                    // module removes a key before it disposes a request, so its own
                    // disposals never arrive here as current): the key is silent
                    // until the next sweep — a failure, not a supersession (third pass).
                    JournifiNTLog.Warn("Bars",
                        $"BarsRequest {symbolFullName} {timeframe} ({source}): aborted by NinjaTrader while still the key's live request.");
                    NotePullFailed(source);
                }
                else
                {
                    JournifiNTLog.Info("Bars", $"BarsRequest {symbolFullName} {timeframe} ({source}): superseded before it completed.");
                }
                return;
            }
            if (errorCode != ErrorCode.NoError)
            {
                JournifiNTLog.Error("Bars",
                    $"BarsRequest {symbolFullName} {timeframe} ({source}): {errorCode} — {errorMessage}");
                if (currentRequest) NotePullFailed(source);
                return;
            }
            if (request?.Bars == null || request.Bars.Count == 0)
            {
                if (source == "heal")
                {
                    // An EMPTY heal pull is not a failed one: its 60-minute window over
                    // a closed market (every weekend, every holiday) legitimately holds
                    // no bars (second refute pass — the first cut read FAILED all weekend).
                    JournifiNTLog.Info("Bars",
                        $"BarsRequest {symbolFullName} {timeframe} ({source}): no bars in the {(BarsSettings?.SelfHealLookbackMinutes ?? 60)}-minute window " +
                        "(market closed, or no recent history for this key)");
                    if (currentRequest) NotePullEmpty(source);
                }
                else
                {
                    // A 30-day window with NO bars is a feed or instrument problem (an
                    // expired contract, no data for the symbol) — a failure, as 3.0.13
                    // warned (third refute pass: the second fold read it as healthy).
                    JournifiNTLog.Warn("Bars",
                        $"BarsRequest {symbolFullName} {timeframe} ({source}): no bars returned for a {(BarsSettings?.HistoricalDays ?? 30)}-day window " +
                        "(data feed may not have history for this instrument)");
                    if (currentRequest) NotePullFailed(source);
                }
                return;
            }

            int count = request.Bars.Count;

            // v3.0.14 — "the last returned bar may be a currently in-progress bar"
            // (NT help guide, BarsRequest). A forming bar's close stamp is still
            // ahead of NinjaTrader's clock, and it is NOT written: pre-3.0.14 the
            // pull persisted it as a final row and the walk read it (the 10/15
            // case in Measurement Day §D). The live path writes it once it closes,
            // because `Forming` is seeded to it below. Compared in NT's own frame
            // (NtNow vs GetTime), never through ToUnixSeconds, so a Windows-zone ≠
            // NT-zone install cannot misjudge it.
            bool formingExcluded = request.Bars.GetTime(count - 1) > NtNow;
            int lastToWrite = formingExcluded ? count - 2 : count - 1;

            // The pull's own LAST returned bar never overwrites an existing row: a
            // historical server that is behind the tape (34 of 935 pulls ended 2–6 min
            // behind, Measurement Day §D) is not authoritative for its newest bar, and
            // the live path's row saw every tick. A MISSING row is still filled.
            long protectLastUnix = lastToWrite >= 0
                && (NtNow - request.Bars.GetTime(lastToWrite)).TotalMinutes <= PULL_PROTECT_LAST_MIN   // only while RECENT (see the constant)
                ? ToUnixSeconds(request.Bars.GetTime(lastToWrite))
                : long.MinValue;
            WriteCounts c = lastToWrite >= 0
                ? WriteBarsRange(symbolFullName, timeframe, request.Bars, 0, lastToWrite, PULL_PROTECT_RECENT_SEC, protectLastUnix)
                : new WriteCounts();

            // Seed this request's forming index. Whatever the last index holds (the
            // forming bar, or the last closed bar when the market is shut), the first
            // Update with a larger MaxIndex writes [Forming .. MaxIndex-1]: a forming
            // bar gets its final values exactly once, a closed one re-merges as a
            // no-op. Per-request state — a superseded request seeding its own object
            // is harmless, so no identity guard; the bars above were worth writing
            // either way (the writer is idempotent).
            if (state != null) lock (state) { state.Forming = count - 1; }
            // Telemetry only for the key's CURRENT request (a superseded request's
            // late callback must not touch a retired key's row — see OnBarsLiveUpdate).
            if (currentRequest)
                keyStates.GetOrAdd(key, _ => new KeyState()).Forming = count - 1;

            int total = c.New + c.Changed;
            if (total > 0)
            {
                Interlocked.Add(ref barsWrittenSinceStart, total);
                lastWriteAt = DateTime.Now;
                lastWritePerSymbol[symbolFullName] = DateTime.Now;
            }
            if (source == "heal")
            {
                Interlocked.Add(ref selfHealBarsFilled, c.New);
                Interlocked.Add(ref selfHealBarsRevised, c.Changed);
                if (c.Changed > 0) Interlocked.Increment(ref healPullsWithRevisions);
            }
            if (c.Failed > 0) Interlocked.Add(ref pullsAborted, c.Failed);
            if (currentRequest)
            {
                lastPullAt = DateTime.Now;
                lastPullSource = source;
                lastPullOk = true;
                lastPullEmpty = false;
                lastPullNew = c.New;
                lastPullChanged = c.Changed;
                lastPullProtected = c.Protected;
            }

            // One line per pull, ALWAYS — a superseded request's late success too
            // (its rows are merged, idempotently; the block is not its to move). A
            // quiet, connected market reads new=0 after the fix. `changed` is
            // telemetry for the tick-authority research (historical and real-time
            // bars differ legitimately, volume especially) — never the fixed/broken
            // discriminator.
            JournifiNTLog.Info("Bars",
                $"{symbolFullName} {timeframe}: {source} pull [0..{lastToWrite}] of {count}: " +
                $"new={c.New} changed={c.Changed} protected={c.Protected}" +
                (c.Failed > 0 ? $" aborted={c.Failed}" : "") +
                $" forming={(formingExcluded ? "excluded" : "none")}" +
                (currentRequest ? "" : " (superseded)"));
            if (currentRequest)
                JournifiNTLog.Info("Bars", $"{symbolFullName} {timeframe}: subscribed to live bar updates ({source})");
        }

        /// <summary>
        /// A callback that returned an error or no bars still moves the pull block:
        /// before this, status.json / the Bars card showed the last SUCCESSFUL
        /// callback, so a feed that kept failing read "last pull 2 min ago" forever
        /// (refuters 2026-11-08). The counts read 0 for a failed pull.
        /// </summary>
        private void NotePullFailed(string source)
        {
            Interlocked.Increment(ref pullsFailed);
            lastPullAt = DateTime.Now;
            lastPullSource = source;
            lastPullOk = false;
            lastPullEmpty = false;
            lastPullNew = 0;
            lastPullChanged = 0;
            lastPullProtected = 0;
        }

        /// <summary>A callback with no bars: the window was empty (closed market), the pull itself worked.</summary>
        private void NotePullEmpty(string source)
        {
            Interlocked.Increment(ref pullsEmpty);
            lastPullAt = DateTime.Now;
            lastPullSource = source;
            lastPullOk = true;
            lastPullEmpty = true;
            lastPullNew = 0;
            lastPullChanged = 0;
            lastPullProtected = 0;
        }

        /// <summary>
        /// Live bar event — the v3.0.14 range rule. <c>state.Forming</c> is the
        /// index of the bar NinjaTrader is still building, as last seen through
        /// THIS request:
        ///
        ///   • tick on the forming bar (MaxIndex == Forming) → no write; the
        ///     per-key "feed alive" stamp only. NT fires Update on every tick, so
        ///     this is the branch that keeps the CSV from being rewritten per tick.
        ///   • new bar(s) opened (MaxIndex &gt; Forming) → write
        ///     [Forming .. MaxIndex-1]: the bar that WAS forming has just closed and
        ///     is written now with its final values; MaxIndex is the new forming bar
        ///     and is excluded. Forming := MaxIndex. "catch-up" when the range holds
        ///     more than one bar (a lagging pull seeded low, or NT delivered several
        ///     closes in one event after a stall).
        ///   • first event before any seed (Forming == -1) → write
        ///     [max(min(MinIndex, MaxIndex-1), MaxIndex-1-PRE_SEED_MAX_BARS) .. MaxIndex-1] through the
        ///     pull's protection window and seed ("fallback"): at most four bars,
        ///     because the key's previous request may have written them live.
        ///   • correction (MinIndex &lt; Forming) → NT revised older bars: write
        ///     [MinIndex .. MaxIndex-1] when the range reaches the forming bar, else
        ///     [MinIndex .. MaxIndex] (every bar in it is closed); bars it closes
        ///     count as closes too.
        ///   • a FAILED write leaves its first index in RetryFrom: the next range
        ///     starts there, and the flag clears only when a write COVERED it up to
        ///     the last closed bar (a successful correction below it keeps the flag).
        ///
        /// Pre-3.0.14 the new-bar branch started at Forming+1 — an off-by-one — so
        /// every other close produced an empty range, Forming did not advance on
        /// those closes, the file received every SECOND closed bar between pulls,
        /// and the pull-time partial was never re-written (Measurement Day
        /// 2026-10-31 §D; the refuters' trace is in docs/design/
        /// AddOn_3.0.14_Build_Spec_2026-11-08.md §A1). The memo's proposed reorder
        /// of the empty-range return and the watermark update would, on its own,
        /// have stopped the live path writing anything: the range rule is the fix.
        ///
        /// OHLCV is read from <c>request.Bars</c> (type <c>Bars</c>) rather than
        /// <c>e.BarsSeries</c>; they reference the same series. (BarsUpdateEventArgs
        /// has no ErrorCode on 8.1.x — only the Request() callback does.)
        /// </summary>
        private void OnBarsLiveUpdate(string symbolFullName, string timeframe,
            BarsRequest request, BarsUpdateEventArgs e, LiveState state)
        {
            if (e == null || request?.Bars == null || state == null) return;
            if (e.MaxIndex < e.MinIndex) return; // empty range — nothing to do

            // "Feed alive" stamps BEFORE any branching — global and per key — so
            // the dashboard can tell "NT is streaming" apart from "bytes hit disk".
            DateTime now = DateTime.Now;
            lastUpdateFireAt = now;
            string key = $"{symbolFullName}|{timeframe}";
            // Per-key telemetry is stamped only by the key's CURRENT request: a
            // disposed request's late event must not resurrect a retired key's
            // row (RemoveWatchedSymbol / auto-roll) in status.json. LiveState is
            // per request and needs no such guard (spec A2).
            bool currentRequest = activeRequests.TryGetValue(key, out BarsRequest liveReq) && ReferenceEquals(liveReq, request);
            KeyState ks = currentRequest ? keyStates.GetOrAdd(key, _ => new KeyState()) : null;
            if (ks != null) ks.LastUpdateAt = now;

            int writeFrom, writeTo, closes;
            string reason;
            lock (state)
            {
                int forming = state.Forming;
                if (forming >= 0 && e.MinIndex < forming)
                {
                    writeFrom = e.MinIndex;
                    writeTo = e.MaxIndex >= forming ? e.MaxIndex - 1 : e.MaxIndex;
                    reason = "correction";
                    // A correction that reaches past the forming bar also CLOSES
                    // bars forming .. MaxIndex-1 — those count as closes, not only
                    // as a correction (refuters 2026-11-08).
                    closes = e.MaxIndex > forming ? e.MaxIndex - forming : 0;
                }
                else if (e.MaxIndex > forming)
                {
                    if (forming >= 0)
                    {
                        writeFrom = forming;
                        reason = (e.MaxIndex - 1) > forming ? "catch-up" : "new bar";
                    }
                    else
                    {
                        // No seed yet: write the closed bars the event names, at
                        // most PRE_SEED_MAX_BARS below the one that just closed (a
                        // multi-bar event before the callback is a correction or a
                        // catch-up we cannot tell apart; the callback's merge covers
                        // the rest with its protections), and seed on its MaxIndex.
                        writeFrom = Math.Max(Math.Min(e.MinIndex, e.MaxIndex - 1), e.MaxIndex - 1 - PRE_SEED_MAX_BARS);
                        reason = "fallback";
                    }
                    writeFrom = Math.Max(0, writeFrom);
                    writeTo = e.MaxIndex - 1;
                    closes = writeTo - writeFrom + 1;
                }
                else
                {
                    return; // tick on the forming bar — the no-op branch
                }
                // A FAILED earlier write left its first index in RetryFrom: start
                // there, so the live path itself re-offers the bar (idempotent merge).
                if (state.RetryFrom >= 0 && state.RetryFrom < writeFrom)
                {
                    writeFrom = state.RetryFrom;
                    if (reason == "new bar") reason = "catch-up";
                }
                // Advance BEFORE writing: a repeated Update for the same MaxIndex is
                // then a no-op even if the write below throws.
                if (e.MaxIndex > forming) { state.Forming = e.MaxIndex; if (ks != null) ks.Forming = e.MaxIndex; }
            }
            if (writeTo < writeFrom) return;

            if (reason == "correction") Interlocked.Increment(ref liveCorrections);
            // closesTotal counts closes the SEEDED live path wrote: a fallback (no
            // seed yet) usually re-writes a bar the key's previous request already
            // counted — one per heal sweep — so it stays in fallbackWrites alone.
            if (closes > 0 && reason != "fallback") Interlocked.Add(ref liveClosesTotal, closes);
            if (reason == "catch-up") Interlocked.Increment(ref liveCatchUpWrites);
            if (reason == "fallback") Interlocked.Increment(ref liveFallbackWrites);

            // The live path protects NOTHING (protectRecentSec 0 → an empty window;
            // the sentinel is long.MaxValue inside the writer — the first cut's
            // long.MinValue protected EVERY existing row, second refute pass), with
            // one exception: a pre-seed fallback writes through the pull's window.
            int protectSec = reason == "fallback" ? PULL_PROTECT_RECENT_SEC : 0;
            WriteCounts c = WriteBarsRange(symbolFullName, timeframe, request.Bars, writeFrom, writeTo, protectSec, long.MinValue);
            lock (state)
            {
                if (c.Failed > 0)
                    state.RetryFrom = state.RetryFrom < 0 ? writeFrom : Math.Min(state.RetryFrom, writeFrom);
                else if (state.RetryFrom >= 0 && writeFrom <= state.RetryFrom && writeTo >= state.Forming - 1)
                    state.RetryFrom = -1;   // cleared only by a write that COVERED the failed range up to the last closed bar — judged
                                            // against the LIVE Forming, so an earlier-decided success cannot clear a later-decided failure
            }
            if (ks != null) ks.LastCloseAt = now;

            int total = c.New + c.Changed;
            if (total > 0)
            {
                Interlocked.Add(ref barsWrittenSinceStart, total);
                lastWriteAt = DateTime.Now;
                lastWritePerSymbol[symbolFullName] = DateTime.Now;
            }
            // One line per close, to the disk log only — never NinjaTrader's Output
            // tab (about 1,440 lines a day per 1m key). Consecutive indices are the
            // proof the rule holds; pre-3.0.14 they advanced by two.
            JournifiNTLog.Info("Bars",
                $"{symbolFullName} {timeframe}: live close ({reason}) [{writeFrom}..{writeTo}] " +
                $"new={c.New} changed={c.Changed} protected={c.Protected}" + (c.Failed > 0 ? $" aborted={c.Failed}" : ""),
                mirrorToOutput: false);
        }

        #endregion

        #region Self-heal sweep (v3.1+)

        /// <summary>
        /// Lazily start the self-heal Timer. Idempotent — safe to call from
        /// every PullAllWatchedSymbols; only the first call actually creates
        /// the timer. Honors the SelfHealIntervalMinutes setting; 0 disables.
        /// </summary>
        private void EnsureSelfHealTimer()
        {
            if (selfHealTimer != null) return;
            int min = BarsSettings?.SelfHealIntervalMinutes ?? 0;
            if (min <= 0)
            {
                JournifiNTLog.Info("Bars", "Self-heal sweep disabled (SelfHealIntervalMinutes=0).");
                return;
            }
            int intervalMs = min * 60 * 1000;
            // First fire after the full interval (not immediately) — gives the
            // initial historical pull time to land its bars + watermark before
            // the sweep races them.
            selfHealTimer = new System.Threading.Timer(_ => SafeSelfHealSweep(),
                null, intervalMs, intervalMs);
            JournifiNTLog.Info("Bars",
                $"Self-heal sweep armed: every {min} min, looks back {BarsSettings.SelfHealLookbackMinutes} min.");
        }

        private void SafeSelfHealSweep()
        {
            // v3.0.4+ — retire superseded auto-roll contracts past their grace
            // window first (own try so a hiccup can't block the heal sweep).
            try { RetireExpiredAutoContracts(); }
            catch (Exception ex)
            {
                JournifiNTLog.Error("Bars", "Auto-roll retirement sweep crashed", ex);
            }
            try { SelfHealSweep(); }
            catch (Exception ex)
            {
                JournifiNTLog.Error("Bars", "Self-heal sweep crashed", ex);
            }
        }

        /// <summary>
        /// Re-pull the last SelfHealLookbackMinutes of 1m bars for each
        /// watched symbol via a fresh BarsRequest, then merge into the file
        /// using the WriteMonthlyFile dedup logic. Fills gaps left by the
        /// live BarsUpdate stream (which silently drops events under load).
        ///
        /// Why 1m specifically: this is the smallest TF, so a 1-hour lookback
        /// catches the most granular drops. Higher TFs are derived in
        /// JournifiAI via aggregation, so 1m is the only file that needs
        /// healing.
        ///
        /// Each sweep fires N BarsRequests (one per watched symbol). They run
        /// in parallel via NT's threading. Results are routed through the
        /// SAME OnBarsResult callback used by initial pulls, so the existing
        /// WriteBarsRange + dedup pipeline handles the merge with no special
        /// casing.
        /// </summary>
        private void SelfHealSweep()
        {
            if (cts == null || cts.IsCancellationRequested) return;
            if (!IsEnabled) return;

            // v3.0.14 — never sweep without a connected feed. Pre-3.0.14 a sweep
            // during a disconnect replaced the working live subscription with a
            // request whose historical load failed before it could seed, so the
            // key went silent until the first sweep after the reconnect.
            if (GetConnectedConnectionNames().Length == 0)
            {
                if (!selfHealSkippedOffline)
                    JournifiNTLog.Info("Bars", "Self-heal sweep skipped: no data-feed connection is active (resumes when one connects).");
                selfHealSkippedOffline = true;
                return;
            }
            selfHealSkippedOffline = false;

            int lookbackMin = BarsSettings?.SelfHealLookbackMinutes ?? 60;
            DateTime fromDate = NtNow.AddMinutes(-lookbackMin);   // NT's clock, like the comparisons the pull makes
            DateTime toDate = NtNow;

            List<JournifiNTWatchedSymbol> watched = GetWatchedSymbolsSnapshot();
            // v3.0.4+ — heal auto-rolled contracts too. A freshly-rolled contract
            // is exactly as exposed to the cash-open BarsUpdate-drop the sweep was
            // built for as a pinned symbol, so it must be re-pulled here. Snapshot
            // the keys (not under the sweep's path) and union with the manual set.
            List<string> autoToHeal = (AutoManagedContractsSnapshot ?? new List<string>()).ToList();
            if (watched.Count == 0 && autoToHeal.Count == 0) return;

            Interlocked.Increment(ref selfHealRunsTotal);
            lastSelfHealAt = DateTime.Now;

            int fired = 0;
            foreach (var entry in watched)
            {
                if (cts.IsCancellationRequested) return;
                if (string.IsNullOrWhiteSpace(entry.Symbol)) continue;
                try
                {
                    // Always 1m, regardless of SubscribeOneMinuteOnly setting.
                    // Higher TFs aggregate from 1m on the JournifiAI side, so
                    // healing 1m heals everything downstream.
                    StartBarsRequest(entry.Symbol, "1m", fromDate, toDate, "heal");
                    fired++;
                }
                catch (Exception ex)
                {
                    JournifiNTLog.Warn("Bars",
                        $"Self-heal request failed for {entry.Symbol} 1m: {ex.Message}");
                }
            }

            // Auto-rolled contracts (skip any already covered by a manual pin).
            var watchedNames = new HashSet<string>(
                watched.Where(w => !string.IsNullOrWhiteSpace(w.Symbol)).Select(w => w.Symbol),
                StringComparer.OrdinalIgnoreCase);
            foreach (var contract in autoToHeal)
            {
                if (cts.IsCancellationRequested) return;
                if (string.IsNullOrWhiteSpace(contract) || watchedNames.Contains(contract)) continue;
                try
                {
                    StartBarsRequest(contract, "1m", fromDate, toDate, "heal");
                    fired++;
                }
                catch (Exception ex)
                {
                    JournifiNTLog.Warn("Bars",
                        $"Self-heal request failed for auto-contract {contract} 1m: {ex.Message}");
                }
            }

            if (fired > 0)
            {
                JournifiNTLog.Info("Bars",
                    $"Self-heal sweep #{selfHealRunsTotal}: fired {fired} 1m request(s), " +
                    $"window {fromDate:HH:mm}–{toDate:HH:mm}. Dedup determines actual writes.");
            }
        }

        #endregion

        #region Auto-roll (v3.0.4+ — execution-driven contract subscription)

        /// <summary>Read-only snapshot of the auto-managed contract set (for status/UI).</summary>
        public IReadOnlyList<string> AutoManagedContractsSnapshot
        {
            get { lock (autoLock) { return autoContracts.Keys.ToList(); } }
        }

        /// <summary>
        /// Execution-driven auto-roll entry point. Called by the Sync module on
        /// each enabled-account FUTURES fill. If the traded contract isn't already
        /// actively auto-subscribed, subscribe its bars and mark any same-root
        /// predecessor for retirement after RollRetentionDays. Fire-and-forget +
        /// self-contained try/catch — a bars hiccup must never break execution
        /// capture. Cheap no-op on every fill once the contract is subscribed.
        /// </summary>
        public void NoteTradedContract(Instrument instrument)
        {
            try
            {
                if (!BarsSettings.AutoRollContracts) return;
                if (instrument?.MasterInstrument == null) return;
                // Futures only — never try to "roll" an equity/option. (The Sync
                // caller already gates on this; double-gate is cheap + safe.)
                if (instrument.MasterInstrument.InstrumentType != InstrumentType.Future) return;

                string root = instrument.MasterInstrument.Name;     // "MNQ"   (reliable NT API)
                string contract = instrument.FullName;              // "MNQU6" / "MNQ 06-26"
                if (string.IsNullOrWhiteSpace(root) || string.IsNullOrWhiteSpace(contract)) return;

                bool subscribeNow = false;
                lock (autoLock)
                {
                    // Already actively tracked → cheap no-op (the common per-fill path).
                    if (autoContracts.TryGetValue(contract, out var existing) && existing.RetireAtUtc == null)
                        return;

                    // (Re)activate this contract.
                    autoContracts[contract] = new AutoContractState { Root = root, RetireAtUtc = null };

                    // Supersede any OTHER still-active contract of the SAME root —
                    // it keeps pulling through RollRetentionDays (roll-week overlap)
                    // then gets retired by the self-heal sweep. Mutating the value's
                    // field doesn't alter the dictionary's structure, so iterating
                    // here is safe.
                    DateTime retireAt = DateTime.UtcNow.AddDays(Math.Max(0, BarsSettings.RollRetentionDays));
                    foreach (var kv in autoContracts)
                    {
                        if (string.Equals(kv.Key, contract, StringComparison.OrdinalIgnoreCase)) continue;
                        if (kv.Value.RetireAtUtc == null &&
                            string.Equals(kv.Value.Root, root, StringComparison.OrdinalIgnoreCase))
                        {
                            kv.Value.RetireAtUtc = retireAt;
                            JournifiNTLog.Info("Bars",
                                $"Auto-roll: {kv.Key} superseded by {contract} (root {root}); retiring in {BarsSettings.RollRetentionDays}d.");
                        }
                    }

                    PersistAutoSet(); // caller holds autoLock
                    subscribeNow = true;
                }

                if (subscribeNow)
                {
                    JournifiNTLog.Info("Bars", $"Auto-roll: new contract {contract} (root {root}) — subscribing bars.");
                    SubscribeAutoContract(contract);
                    // Ensure the self-heal/retirement timer is running so the new
                    // contract gets healed + predecessors retired.
                    EnsureSelfHealTimer();
                }
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("Bars", $"NoteTradedContract failed: {ex.Message}");
            }
        }

        /// <summary>Subscribe bars for one auto-managed contract across the effective TF set.</summary>
        private void SubscribeAutoContract(string contract)
        {
            DateTime fromDate = NtNow.AddDays(-BarsSettings.HistoricalDays).Date;   // NT's clock: a replay pulls the replay's window
            DateTime toDate = NtNow;
            foreach (string tf in EffectiveAutoTfs())
            {
                try { StartBarsRequest(contract, tf, fromDate, toDate, "auto-roll"); }
                catch (Exception ex)
                {
                    JournifiNTLog.Error("Bars", $"Auto-roll StartBarsRequest failed for {contract} {tf}", ex);
                }
            }
        }

        /// <summary>
        /// TF set for auto-managed contracts. Honors SubscribeOneMinuteOnly (1m
        /// only — higher TFs aggregate in JournifiAI); otherwise the union of the
        /// watchlist's configured TFs so a rolled contract matches the user's
        /// existing coverage, falling back to the full supported set.
        /// </summary>
        private List<string> EffectiveAutoTfs()
        {
            if (BarsSettings?.SubscribeOneMinuteOnly ?? false)
                return new List<string> { "1m" };

            var tfs = new List<string>();
            lock (configLock)
            {
                var watched = BarsSettings?.WatchedSymbols;
                if (watched != null)
                {
                    foreach (var w in watched)
                    {
                        if (w?.Timeframes == null) continue;
                        foreach (var tf in w.Timeframes)
                            if (!string.IsNullOrWhiteSpace(tf) && !tfs.Contains(tf)) tfs.Add(tf);
                    }
                }
            }
            if (tfs.Count == 0) tfs.AddRange(new[] { "1m", "5m", "15m", "1h", "4h" });
            return tfs;
        }

        /// <summary>Write the active auto-set to settings as "ROOT|CONTRACT". CALLER MUST HOLD autoLock.</summary>
        private void PersistAutoSet()
        {
            var list = new List<string>(autoContracts.Count);
            foreach (var kv in autoContracts)
                list.Add((kv.Value.Root ?? "") + "|" + kv.Key);
            BarsSettings.AutoManagedContracts = list;
            JournifiNTSettingsStore.Save();
        }

        /// <summary>
        /// Dispose BarsRequests for superseded contracts whose grace window has
        /// elapsed, drop them from the auto-set, and persist. History files stay
        /// on disk. Runs on the self-heal timer (resource hygiene, not correctness).
        /// </summary>
        private void RetireExpiredAutoContracts()
        {
            DateTime nowUtc = DateTime.UtcNow;
            var toRetire = new List<string>();
            lock (autoLock)
            {
                foreach (var kv in autoContracts)
                    if (kv.Value.RetireAtUtc.HasValue && kv.Value.RetireAtUtc.Value <= nowUtc)
                        toRetire.Add(kv.Key);
                if (toRetire.Count == 0) return;
                foreach (var c in toRetire) autoContracts.Remove(c);
                PersistAutoSet();
            }

            // Dispose live subscriptions for retired contracts (outside autoLock).
            foreach (var contract in toRetire)
            {
                var keys = activeRequests.Keys
                    .Where(k => k.StartsWith(contract + "|", StringComparison.OrdinalIgnoreCase))
                    .ToArray();
                foreach (var k in keys)
                {
                    if (activeRequests.TryRemove(k, out BarsRequest req))
                    {
                        try { req?.Dispose(); } catch { /* gone */ }
                    }
                    keyStates.TryRemove(k, out _);
                }
                JournifiNTLog.Info("Bars",
                    $"Auto-roll: retired superseded contract {contract} (disposed {keys.Length} subscription(s); history kept).");
            }
        }

        /// <summary>
        /// Rebuild the in-memory auto-set from the persisted "ROOT|CONTRACT" list
        /// on startup, so the startup pull re-subscribes the right contract(s)
        /// without waiting for the day's first fill. All rehydrated entries are
        /// active (RetireAtUtc=null); the next fill re-asserts same-root supersession.
        /// </summary>
        private void RehydrateAutoContracts()
        {
            try
            {
                var persisted = BarsSettings?.AutoManagedContracts;
                if (persisted == null || persisted.Count == 0) return;
                string joined;
                lock (autoLock)
                {
                    autoContracts.Clear();
                    foreach (var s in persisted)
                    {
                        if (string.IsNullOrWhiteSpace(s)) continue;
                        int bar = s.IndexOf('|');
                        if (bar <= 0 || bar >= s.Length - 1) continue;
                        string root = s.Substring(0, bar);
                        string contract = s.Substring(bar + 1);
                        if (!string.IsNullOrWhiteSpace(contract))
                            autoContracts[contract] = new AutoContractState { Root = root, RetireAtUtc = null };
                    }
                    joined = string.Join(", ", autoContracts.Keys);
                }
                JournifiNTLog.Info("Bars", $"Auto-roll: rehydrated persisted contract(s): {joined}");
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("Bars", $"Auto-roll rehydrate failed: {ex.Message}");
            }
        }

        #endregion

        #region File output (write pipeline)

        /// <summary>
        /// Outcome of one write (v3.0.14): rows added, rows revised, rows left as
        /// the live path wrote them (pull protection), month-file writes that did
        /// not complete (read abort, folder or write failure). Total written =
        /// New + Changed.
        /// </summary>
        private struct WriteCounts
        {
            public int New;
            public int Changed;
            public int Protected;
            public int Failed;
        }

        /// <summary>
        /// Walk a bar range [fromIdx..toIdx] inclusive, group by year-month,
        /// and dispatch to WriteMonthlyFile per month. <paramref name="protectRecentSec"/>
        /// is PULL_PROTECT_RECENT_SEC for a pull and 0 for the live path.
        /// </summary>
        private WriteCounts WriteBarsRange(string symbolFullName, string timeframe, Bars bars, int fromIdx, int toIdx,
            int protectRecentSec, long protectLastUnix)
        {
            var total = new WriteCounts();
            if (bars == null || bars.Count == 0) return total;
            if (fromIdx < 0) fromIdx = 0;
            if (toIdx >= bars.Count) toIdx = bars.Count - 1;
            if (toIdx < fromIdx) return total;

            var byMonth = new SortedDictionary<string, List<JournifiSyncNTBarRow>>();
            for (int i = fromIdx; i <= toIdx; i++)
            {
                DateTime t = bars.GetTime(i);
                long unixSec = ToUnixSeconds(t);
                string monthKey = t.ToString("yyyy-MM", CultureInfo.InvariantCulture);
                if (!byMonth.TryGetValue(monthKey, out var list))
                {
                    list = new List<JournifiSyncNTBarRow>();
                    byMonth[monthKey] = list;
                }
                list.Add(new JournifiSyncNTBarRow
                {
                    TimeUnix = unixSec,
                    Open    = bars.GetOpen(i),
                    High    = bars.GetHigh(i),
                    Low     = bars.GetLow(i),
                    Close   = bars.GetClose(i),
                    Volume  = bars.GetVolume(i),
                });
            }

            foreach (var kvp in byMonth)
            {
                WriteCounts c = WriteMonthlyFile(symbolFullName, timeframe, kvp.Key, kvp.Value, protectRecentSec, protectLastUnix);
                total.New += c.New;
                total.Changed += c.Changed;
                total.Protected += c.Protected;
                total.Failed += c.Failed;
            }
            return total;
        }

        #endregion

        #region File output (atomic, dedup-on-merge)

        private WriteCounts WriteMonthlyFile(string symbolFullName, string timeframe,
            string monthKey, List<JournifiSyncNTBarRow> bars, int protectRecentSec, long protectLastUnix)
        {
            var result = new WriteCounts();
            if (bars == null || bars.Count == 0) return result;

            string sanitizedSym = SanitizePathPart(symbolFullName);
            string symDir = Path.Combine(JournifiNTPaths.BarsDir, sanitizedSym);
            if (!Directory.Exists(symDir))
            {
                try { Directory.CreateDirectory(symDir); }
                catch (Exception ex)
                {
                    JournifiNTLog.Error("Bars",
                        $"Could not create symbol folder '{symDir}'", ex);
                    result.Failed = 1;
                    return result;
                }
            }

            string filePath = Path.Combine(symDir, $"{monthKey}_{timeframe}.csv");

            lock (fileLock)
            {
                try
                {
                    // Merge existing + new by Unix timestamp, OVERWRITE on
                    // duplicate. When a bar transitions from forming to closed,
                    // the live path re-emits it with final OHLC values and the
                    // existing row yields to the closed version.
                    var byTime = new Dictionary<long, JournifiSyncNTBarRow>();

                    if (File.Exists(filePath))
                    {
                        // v3.0.14 — a read FAILURE aborts the merge. Pre-3.0.14 the
                        // reader returned an empty list on ANY exception and the merge
                        // then rewrote the whole month with only the incoming rows:
                        // the executions writer's ParseRecord erase trap, on a path
                        // that now writes once a minute. A missing file is "start
                        // empty"; anything else is "do not touch the file this pass".
                        if (!TryReadCsvBars(filePath, out var existingRows, out int malformed))
                        {
                            result.Failed = 1;
                            JournifiNTLog.Error("Bars",
                                $"WriteMonthlyFile {filePath}: existing file could not be read — merge ABORTED, " +
                                $"{bars.Count} incoming row(s) not written this pass (a pull retries on its next cycle; " +
                                "the live path re-offers the range on its next close)");
                            return result;
                        }
                        if (malformed > 0)
                            JournifiNTLog.Warn("Bars", $"WriteMonthlyFile {filePath}: {malformed} malformed row(s) dropped on merge");
                        foreach (var existing in existingRows)
                            byTime[existing.TimeUnix] = existing;
                    }

                    // v3.0.14 — pull protection (see PULL_PROTECT_RECENT_SEC). The
                    // threshold goes through ToUnixSeconds with its Kind STRIPPED, so it
                    // takes exactly the conversion the bar stamps took (Unspecified →
                    // treated as Local): whatever Kind Globals.Now carries, the two
                    // numbers share one frame and the comparison cannot be off by a zone.
                    // No window (the live path) = a threshold NOTHING satisfies, so
                    // long.MaxValue: the first cut wrote long.MinValue here and
                    // `>=` was true for every stamp — the live path could never
                    // revise an existing row (second refute pass, 2026-11-08).
                    long protectAfter = protectRecentSec > 0
                        ? ToUnixSeconds(DateTime.SpecifyKind(NtNow, DateTimeKind.Unspecified)) - protectRecentSec
                        : long.MaxValue;

                    foreach (var b in bars)
                    {
                        if (!byTime.TryGetValue(b.TimeUnix, out var existing))
                        {
                            result.New++;
                        }
                        else if (existing.Open != b.Open || existing.High != b.High ||
                                 existing.Low  != b.Low  || existing.Close != b.Close ||
                                 existing.Volume != b.Volume)
                        {
                            if (b.TimeUnix >= protectAfter || b.TimeUnix == protectLastUnix)
                            {
                                result.Protected++;   // keep the live path's row (recent, or the pull's own newest bar)
                                continue;
                            }
                            result.Changed++;
                        }
                        else
                        {
                            continue;   // identical — nothing to do
                        }
                        byTime[b.TimeUnix] = b;
                    }

                    if (result.New == 0 && result.Changed == 0) return result;

                    var merged = byTime.Values.ToList();
                    merged.Sort((a, b) => a.TimeUnix.CompareTo(b.TimeUnix));

                    var sb = new StringBuilder(merged.Count * 64);
                    sb.Append("time,open,high,low,close,volume\n");
                    foreach (var b in merged)
                    {
                        sb.Append(b.TimeUnix).Append(',');
                        sb.Append(b.Open.ToString("R", CultureInfo.InvariantCulture)).Append(',');
                        sb.Append(b.High.ToString("R", CultureInfo.InvariantCulture)).Append(',');
                        sb.Append(b.Low.ToString("R", CultureInfo.InvariantCulture)).Append(',');
                        sb.Append(b.Close.ToString("R", CultureInfo.InvariantCulture)).Append(',');
                        sb.Append(b.Volume.ToString(CultureInfo.InvariantCulture)).Append('\n');
                    }

                    // v3.0.1 — durable atomic write via the shared chokepoint
                    // (was delete-then-Move, which could lose the whole month's
                    // bars on a crash mid-rename).
                    JournifiNTIO.AtomicWriteAllText(filePath, sb.ToString());

                    return result;
                }
                catch (Exception ex)
                {
                    JournifiNTLog.Error("Bars", $"WriteMonthlyFile {filePath}", ex);
                    result.Failed = 1;
                    return result;
                }
            }
        }

        /// <summary>
        /// Lightweight CSV reader for the headered format we write. Tolerates
        /// extra whitespace and counts malformed rows. Intentionally NOT
        /// RFC-4180 — we own the writer too. Returns FALSE when the file exists
        /// but could not be read (a sharing violation, a half-written file): the
        /// caller must then leave the file alone (v3.0.14). A missing file reads
        /// as empty and TRUE.
        /// </summary>
        private static bool TryReadCsvBars(string filePath, out List<JournifiSyncNTBarRow> rows, out int malformed)
        {
            rows = new List<JournifiSyncNTBarRow>();
            malformed = 0;
            string[] lines;
            try { lines = File.ReadAllLines(filePath); }
            catch (FileNotFoundException) { return true; }
            catch (DirectoryNotFoundException) { return true; }
            catch { return false; }

            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                if (string.IsNullOrWhiteSpace(line)) continue;
                if (i == 0 && line.StartsWith("time,", StringComparison.OrdinalIgnoreCase)) continue;

                string[] parts = line.Split(',');
                if (parts.Length < 5) { malformed++; continue; }

                if (!long.TryParse(parts[0].Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out long tm)) { malformed++; continue; }
                if (!double.TryParse(parts[1].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out double o)) { malformed++; continue; }
                if (!double.TryParse(parts[2].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out double h)) { malformed++; continue; }
                if (!double.TryParse(parts[3].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out double l)) { malformed++; continue; }
                if (!double.TryParse(parts[4].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out double c)) { malformed++; continue; }
                long v = 0;
                if (parts.Length >= 6) long.TryParse(parts[5].Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out v);

                rows.Add(new JournifiSyncNTBarRow { TimeUnix = tm, Open = o, High = h, Low = l, Close = c, Volume = v });
            }
            return true;
        }

        #endregion

        #region Status heartbeat

        private void WriteStatus()
        {
            try
            {
                var sb = new StringBuilder(512);
                sb.Append("{\n");
                sb.Append("  \"version\": \"").Append(JournifiSyncNT.VERSION).Append("\",\n");
                sb.Append("  \"isRunning\": ").Append(Stats.IsRunning ? "true" : "false").Append(",\n");
                sb.Append("  \"startedAt\": \"").Append(Stats.StartTime.ToString("o", CultureInfo.InvariantCulture)).Append("\",\n");
                sb.Append("  \"lastWriteAt\": ");
                if (lastWriteAt == DateTime.MinValue) sb.Append("null");
                else sb.Append('"').Append(lastWriteAt.ToString("o", CultureInfo.InvariantCulture)).Append('"');
                sb.Append(",\n");
                // "Feed alive" signal — moves on every NT update fire, even
                // when no bytes change on disk. Lets the journal side tell
                // "NT is streaming, no new bars" apart from "NT is silent."
                sb.Append("  \"lastUpdateFireAt\": ");
                if (lastUpdateFireAt == DateTime.MinValue) sb.Append("null");
                else sb.Append('"').Append(lastUpdateFireAt.ToString("o", CultureInfo.InvariantCulture)).Append('"');
                sb.Append(",\n");
                sb.Append("  \"barsWrittenSinceStart\": ").Append(barsWrittenSinceStart).Append(",\n");
                // Per-symbol last-write — surfaces which specific watched
                // symbol is lagging when one feed stalls but others keep
                // writing. Useful for the "trade MNQ but watching ES" config
                // mismatch where the global lastWriteAt looks healthy but the
                // user's actually-trading symbol hasn't been touched.
                sb.Append("  \"lastWritePerSymbol\": {");
                bool firstSym = true;
                foreach (var kvp in lastWritePerSymbol)
                {
                    if (!firstSym) sb.Append(", ");
                    sb.Append('"').Append(JsonEscape(kvp.Key)).Append("\": \"");
                    sb.Append(kvp.Value.ToString("o", CultureInfo.InvariantCulture)).Append('"');
                    firstSym = false;
                }
                sb.Append("},\n");
                // v3.1+ — self-heal sweep telemetry. Lets the JournifiAI
                // side surface "addon is healing N gaps per sweep" insight
                // and warn when the sweep itself is silent for too long.
                sb.Append("  \"selfHeal\": {\n");
                sb.Append("    \"enabled\": ").Append(SelfHealEnabled ? "true" : "false").Append(",\n");
                sb.Append("    \"intervalMinutes\": ").Append(BarsSettings?.SelfHealIntervalMinutes ?? 0).Append(",\n");
                sb.Append("    \"lookbackMinutes\": ").Append(BarsSettings?.SelfHealLookbackMinutes ?? 0).Append(",\n");
                sb.Append("    \"lastSweepAt\": ");
                if (lastSelfHealAt == DateTime.MinValue) sb.Append("null");
                else sb.Append('"').Append(lastSelfHealAt.ToString("o", CultureInfo.InvariantCulture)).Append('"');
                sb.Append(",\n");
                sb.Append("    \"runsTotal\": ").Append(Interlocked.Read(ref selfHealRunsTotal)).Append(",\n");
                sb.Append("    \"barsFilled\": ").Append(Interlocked.Read(ref selfHealBarsFilled)).Append(",\n");
                sb.Append("    \"barsRevised\": ").Append(Interlocked.Read(ref selfHealBarsRevised)).Append("\n");
                sb.Append("  },\n");
                // v3.0.14 — Bars Integrity: the live path and the pulls, separately,
                // so "the live path writes every bar" and "pulls find nothing to
                // fill" can each be read. Every field is optional to a reader (an
                // AddOn ≤ 3.0.13 writes none); `isRunning` alone is not liveness —
                // age the stamps. Last member of each block carries no comma (the
                // AppendNumberLast trap, status.json edition).
                sb.Append("  \"live\": {\n");
                sb.Append("    \"closesTotal\": ").Append(Interlocked.Read(ref liveClosesTotal)).Append(",\n");
                sb.Append("    \"catchUpWrites\": ").Append(Interlocked.Read(ref liveCatchUpWrites)).Append(",\n");
                sb.Append("    \"fallbackWrites\": ").Append(Interlocked.Read(ref liveFallbackWrites)).Append(",\n");
                sb.Append("    \"corrections\": ").Append(Interlocked.Read(ref liveCorrections)).Append(",\n");
                sb.Append("    \"perKey\": {");
                bool firstKey = true;
                foreach (var kvp in keyStates)
                {
                    if (!firstKey) sb.Append(", ");
                    sb.Append('"').Append(JsonEscape(kvp.Key)).Append("\": {\"lastUpdateAt\": ");
                    AppendTimeOrNull(sb, kvp.Value.LastUpdateAt);
                    sb.Append(", \"lastCloseAt\": ");
                    AppendTimeOrNull(sb, kvp.Value.LastCloseAt);
                    sb.Append(", \"forming\": ").Append(kvp.Value.Forming).Append('}');
                    firstKey = false;
                }
                sb.Append("}\n");
                sb.Append("  },\n");
                sb.Append("  \"pulls\": {\n");
                sb.Append("    \"lastAt\": ");
                AppendTimeOrNull(sb, lastPullAt);
                sb.Append(",\n");
                sb.Append("    \"lastSource\": \"").Append(JsonEscape(lastPullSource)).Append("\",\n");
                sb.Append("    \"lastOk\": ").Append(lastPullOk ? "true" : "false").Append(",\n");
                sb.Append("    \"lastNew\": ").Append(lastPullNew).Append(",\n");
                sb.Append("    \"lastChanged\": ").Append(lastPullChanged).Append(",\n");
                sb.Append("    \"lastProtected\": ").Append(lastPullProtected).Append(",\n");
                sb.Append("    \"healPullsWithRevisions\": ").Append(Interlocked.Read(ref healPullsWithRevisions)).Append(",\n");
                sb.Append("    \"empty\": ").Append(Interlocked.Read(ref pullsEmpty)).Append(",\n");
                sb.Append("    \"failed\": ").Append(Interlocked.Read(ref pullsFailed)).Append(",\n");
                sb.Append("    \"aborted\": ").Append(Interlocked.Read(ref pullsAborted)).Append("\n");
                sb.Append("  },\n");
                sb.Append("  \"subscribeOneMinuteOnly\": ").Append(BarsSettings?.SubscribeOneMinuteOnly == true ? "true" : "false").Append(",\n");
                // v3.0.4+ — execution-driven auto-roll visibility.
                sb.Append("  \"autoRoll\": {\n");
                sb.Append("    \"enabled\": ").Append(BarsSettings?.AutoRollContracts == true ? "true" : "false").Append(",\n");
                sb.Append("    \"contracts\": [");
                var autoSnapshot = AutoManagedContractsSnapshot;
                for (int i = 0; i < autoSnapshot.Count; i++)
                {
                    if (i > 0) sb.Append(", ");
                    sb.Append('"').Append(JsonEscape(autoSnapshot[i])).Append('"');
                }
                sb.Append("]\n");
                sb.Append("  },\n");
                sb.Append("  \"watchedSymbols\": [");
                var watched = BarsSettings?.WatchedSymbols;
                if (watched != null)
                {
                    for (int i = 0; i < watched.Count; i++)
                    {
                        if (i > 0) sb.Append(", ");
                        sb.Append('"').Append(JsonEscape(watched[i].Symbol)).Append('"');
                    }
                }
                sb.Append("]\n");
                sb.Append("}\n");

                lock (fileLock)
                {
                    // v3.0.14 — atomic, so the journal's reader never sees a half-written file.
                    JournifiNTIO.AtomicWriteAllText(JournifiNTPaths.BarsStatusPath, sb.ToString());
                }
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("Bars", $"WriteStatus failed: {ex.Message}");
            }
        }

        #endregion

        #region Helpers

        private static BarsPeriod ParseTimeframe(string tf)
        {
            if (string.IsNullOrWhiteSpace(tf)) return null;
            // NT8's BarsPeriodType has no native "Hour" — hourly bars are
            // expressed as Minute with the appropriate multiplier (60, 240).
            switch (tf.Trim().ToLowerInvariant())
            {
                case "1m":   return new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, Value = 1 };
                case "5m":   return new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, Value = 5 };
                case "15m":  return new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, Value = 15 };
                case "1h":   return new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, Value = 60 };
                case "60m":  return new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, Value = 60 };
                case "4h":   return new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, Value = 240 };
                case "240m": return new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, Value = 240 };
                default:     return null;
            }
        }

        /// <summary>
        /// Convert NT's bar timestamp to Unix seconds. NT's GetTime returns
        /// a DateTime in NT's configured local timezone with Kind=Unspecified;
        /// we treat as Local. The journal-side parser re-anchors on read.
        /// </summary>
        private static long ToUnixSeconds(DateTime dt)
        {
            try
            {
                if (dt.Kind == DateTimeKind.Unspecified)
                    dt = DateTime.SpecifyKind(dt, DateTimeKind.Local);
                return ((DateTimeOffset)dt).ToUnixTimeSeconds();
            }
            catch
            {
                return ((DateTimeOffset)DateTime.SpecifyKind(dt, DateTimeKind.Utc)).ToUnixTimeSeconds();
            }
        }

        private static string SanitizePathPart(string s)
        {
            if (string.IsNullOrEmpty(s)) return "_";
            var bad = Path.GetInvalidFileNameChars();
            var sb = new StringBuilder(s.Length);
            foreach (char c in s)
                sb.Append(Array.IndexOf(bad, c) >= 0 ? '_' : c);
            return sb.ToString().Trim();
        }

        private static string JsonEscape(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("\\", "\\\\").Replace("\"", "\\\"");
        }

        private static void AppendTimeOrNull(StringBuilder sb, DateTime t)
        {
            if (t == DateTime.MinValue) sb.Append("null");
            else sb.Append('"').Append(t.ToString("o", CultureInfo.InvariantCulture)).Append('"');
        }

        /// <summary>
        /// v3.0.14 — NinjaTrader's own clock in the frame <c>Bars.GetTime</c> uses
        /// (the replay clock under Playback, else <c>Core.Globals.Now</c> — see
        /// <c>JournifiNTClock</c> in Shared.cs, the ONE helper for both modules).
        /// Bar times are compared against THIS, never against the host clock, so a
        /// Windows-zone ≠ NT-zone install cannot misjudge a forming bar.
        /// </summary>
        private static DateTime NtNow => JournifiNTClock.Now;

        private static void SafeExecute(Action action)
        {
            try { action(); }
            catch (Exception ex) { JournifiNTLog.Error("Bars", "SafeExecute caught", ex); }
        }

        #endregion
    }

    #endregion

    #region Data classes

    /// <summary>
    /// One row of OHLCV bar data. Time is Unix seconds (UTC anchor) so the
    /// journal-side parser can interpret without timezone ambiguity.
    /// Schema identical to v1.1.1's BarRow — renamed only to avoid the
    /// type-name collision while v1 is still installed.
    /// </summary>
    public class JournifiSyncNTBarRow
    {
        public long TimeUnix { get; set; }
        public double Open { get; set; }
        public double High { get; set; }
        public double Low { get; set; }
        public double Close { get; set; }
        public long Volume { get; set; }
    }

    public class JournifiSyncNTBarsStats
    {
        public bool IsRunning { get; set; }
        public DateTime StartTime { get; set; }
    }

    #endregion
}
