#region Using declarations
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.Gui.NinjaScript
{
    // =====================================================================
    //  BarsModule — historical + live OHLCV bar export
    // =====================================================================
    //
    //  Ported from JournifiBars v1.1.1 (NinjaTrader/AddOns/JournifiBars_v1.0/
    //  JournifiBars.cs) with the same seam-level changes as SyncModule:
    //
    //    Removed                          Replaced with
    //    ─────────────────────────────────────────────────────────────────
    //    AddOnBase base class             plain class, lifecycle driven by
    //                                     the orchestrator
    //    OnStateChange()                  Initialize() / Cleanup()
    //    Local outputFolder hardcoded     JournifiNTPaths.BarsDir
    //    Local settings.json reader       JournifiNTSettingsStore.Bars.*
    //    Local JournifiBarsConfig POCO    JournifiNTBarsSettings (from Shared)
    //    Local WatchedSymbolEntry POCO    JournifiNTWatchedSymbol (from Shared)
    //    LogMessage(level, msg)           JournifiNTLog.Info / .Warn / .Error
    //    BarRow class                     JournifiSyncNTBarRow (renamed to
    //                                     avoid collision with v1.1.1's BarRow)
    //    JournifiBarsStats class          JournifiSyncNTBarsStats
    //
    //  EVERYTHING ELSE — the historical .Request() callback, the connect-
    //  watcher polling, monthly CSV files with overwrite-on-duplicate dedup,
    //  atomic temp+rename writes, TradingHours fallback, ToUnixSeconds
    //  Local-time handling, ParseTimeframe supporting {1m, 5m, 15m, 1h, 4h,
    //  60m, 240m} — is a verbatim carry-forward of the v1.1.1 behavior. The
    //  journal-side NinjaTraderBarSource reads
    //  `<SYMBOL>\<YYYY-MM>_<TF>.csv` files at the unchanged BarsDir path with
    //  zero updates required.
    //
    //  REFACTORED in v3.0: the live-bar pipeline uses the official
    //  <c>BarsUpdateEventArgs.MinIndex/MaxIndex</c> properties on the .Update
    //  event PLUS a per-key <c>maxWrittenIndex</c> watermark. The watermark
    //  isn't there to infer "new bar" from Count growth (v1.1.1's approach,
    //  which missed late corrections) — instead it lets us distinguish three
    //  cases:
    //    1. New bar closed   → MaxIndex grew → write the now-closed bars,
    //                           exclude the new in-progress one
    //    2. Late correction  → MinIndex < watermark → honor NT's range
    //    3. In-progress tick → MaxIndex == watermark → SKIP
    //  Case 3 is critical: NT fires Update on every tick (potentially
    //  many per second per symbol × per timeframe), and the pre-watermark
    //  refactor rewrote the entire monthly CSV each time. Writing only on
    //  bar-close keeps the disk file at most one timeframe-period stale,
    //  which is fine for trade-card rendering (the trade is in the past).

    #region Module class

    public class JournifiSyncNTBarsModule
    {
        #region Constants

        // Connect-watcher cadence — poll every 30s for the first connected
        // data-feed if the initial startup pull bailed because no feeds were
        // active. The watcher fires PullAllWatchedSymbols on the first poll
        // that finds a feed, then self-cancels.
        private const int CONNECT_WATCHER_INTERVAL_MS = 30_000;
        private const int CONNECT_WATCHER_MAX_ATTEMPTS = 20;

        // Heartbeat — how often status.json gets refreshed so the journal
        // can render "AddOn is alive". Doesn't affect bar pull cadence.
        private const int HEARTBEAT_MS = 30_000;

        // Initial pull delay — give NT time to finish connecting feeds
        // before we fire BarsRequests (which fail silently on disconnected
        // feeds).
        private const int INITIAL_PULL_DELAY_MS = 5_000;

        #endregion

        #region Fields

        public JournifiSyncNTBarsStats Stats { get; } = new JournifiSyncNTBarsStats();

        // Settings cached pointer so we re-read the latest values on each
        // call (UI mutations land in the store directly).
        private JournifiNTBarsSettings BarsSettings => JournifiNTSettingsStore.Current.Bars;

        // Lifecycle
        private CancellationTokenSource cts;
        private System.Threading.Timer heartbeatTimer;
        private System.Threading.Timer connectWatcherTimer;
        private int connectWatcherAttempts;
        private bool firstPullDone;
        private bool initialized;

        // Per-(symbol, tf) state
        private readonly object fileLock = new object();
        private readonly object configLock = new object();
        private readonly ConcurrentDictionary<string, BarsRequest> activeRequests
            = new ConcurrentDictionary<string, BarsRequest>();

        // Per-(symbol, tf) high-water mark of the highest bar index we've
        // written to disk. Used to distinguish three cases on each Update:
        //   1. New bar(s) arrived (MaxIndex > prevMax) → write the now-
        //      closed bars, skip the new in-progress one
        //   2. Late correction (MinIndex < prevMax) → honor NT's full range
        //   3. In-progress tick on current bar → skip (would otherwise
        //      cause every tick to rewrite the CSV)
        private readonly ConcurrentDictionary<string, int> maxWrittenIndex
            = new ConcurrentDictionary<string, int>();

        // Session counters
        private DateTime lastWriteAt = DateTime.MinValue;
        private DateTime lastUpdateFireAt = DateTime.MinValue;
        private long barsWrittenSinceStart;

        // Per-symbol last-write tracking — exposes which specific watched
        // symbol is lagging (e.g., MNQ writing every 5m but ES went silent).
        // Distinct from the global `lastWriteAt` which only tracks the
        // most-recent write across all symbols.
        private readonly ConcurrentDictionary<string, DateTime> lastWritePerSymbol
            = new ConcurrentDictionary<string, DateTime>();

        // v3.1+ — Self-heal sweep state. Compensates for NT's BarsUpdate
        // live stream dropping events under load. Runs every
        // SelfHealIntervalMinutes (default 5), re-pulls the last
        // SelfHealLookbackMinutes of 1m bars via a fresh BarsRequest, and
        // merges them into the file using the same dedup as live writes.
        private System.Threading.Timer selfHealTimer;
        private DateTime lastSelfHealAt = DateTime.MinValue;
        private long selfHealRunsTotal;        // # of sweep cycles fired
        private long selfHealBarsFilled;       // # of NEW bars added (vs already-on-disk)
        private long selfHealBarsRevised;      // # of bars whose OHLCV changed on re-pull

        // v3.0.4+ — execution-driven auto-roll. The auto-managed contract set is
        // separate from (and additive to) the manual WatchedSymbols. A fill on a
        // not-yet-subscribed futures contract (SyncModule → NoteTradedContract)
        // adds it here and subscribes its bars; same-root predecessors are marked
        // for retirement after RollRetentionDays. Persisted as "ROOT|CONTRACT" so
        // a restart re-subscribes the right contract without a fresh fill. All
        // access is guarded by autoLock.
        private sealed class AutoContractState
        {
            public string Root;            // MasterInstrument.Name, e.g. "MNQ"
            public DateTime? RetireAtUtc;   // null = active; set = superseded, retire when due
        }
        private readonly object autoLock = new object();
        private readonly Dictionary<string, AutoContractState> autoContracts
            = new Dictionary<string, AutoContractState>(StringComparer.OrdinalIgnoreCase);

        #endregion

        #region Public API surface (UI + orchestrator)

        public bool IsEnabled => BarsSettings.Enabled;
        public string OutputFolder => JournifiNTPaths.BarsDir;
        public string SettingsFilePath => JournifiNTPaths.SettingsPath;
        public long BarsWrittenSinceStart => Interlocked.Read(ref barsWrittenSinceStart);
        public DateTime LastWriteAt => lastWriteAt;
        // Last time NinjaTrader fired an OnBarsLiveUpdate for ANY watched
        // symbol/timeframe, regardless of whether the write actually changed
        // disk state. This is the "feed is alive" health signal — distinct
        // from LastWriteAt which only moves when bytes change on disk. The
        // distinction matters because in-progress tick updates + matched-
        // already-on-disk dedup both return without bumping LastWriteAt,
        // even though NT is clearly still streaming.
        public DateTime LastUpdateFireAt => lastUpdateFireAt;
        // Snapshot of last-write times keyed by symbol — exposes which
        // specific watched symbol is lagging when one feed goes silent
        // while others stay healthy. Empty when no writes have happened yet.
        public IReadOnlyDictionary<string, DateTime> LastWritePerSymbol
        {
            get
            {
                // Defensive copy so UI iteration can't race the producer.
                var snapshot = new Dictionary<string, DateTime>(lastWritePerSymbol.Count);
                foreach (var kvp in lastWritePerSymbol) snapshot[kvp.Key] = kvp.Value;
                return snapshot;
            }
        }
        public string[] ConnectedFeedNames => GetConnectedConnectionNames();

        // v3.1+ — Self-heal sweep visibility for the dashboard.
        public DateTime LastSelfHealAt => lastSelfHealAt;
        public long SelfHealRunsTotal => Interlocked.Read(ref selfHealRunsTotal);
        public long SelfHealBarsFilled => Interlocked.Read(ref selfHealBarsFilled);
        public long SelfHealBarsRevised => Interlocked.Read(ref selfHealBarsRevised);
        public bool SelfHealEnabled => (BarsSettings?.SelfHealIntervalMinutes ?? 0) > 0;

        public void SetEnabled(bool enabled)
        {
            BarsSettings.Enabled = enabled;
            Stats.IsRunning = enabled;
            JournifiNTSettingsStore.Save();
            JournifiNTLog.Info("Bars", $"Bars {(enabled ? "enabled" : "disabled")}");
        }

        /// <summary>
        /// Public read-only snapshot of the watched symbols list. Returns
        /// fresh list copies so the UI can display without holding the lock.
        /// </summary>
        public List<JournifiNTWatchedSymbol> GetWatchedSymbolsSnapshot()
        {
            lock (configLock)
            {
                var watched = BarsSettings.WatchedSymbols ?? new List<JournifiNTWatchedSymbol>();
                return watched.Select(w => new JournifiNTWatchedSymbol
                {
                    Symbol = w.Symbol,
                    Timeframes = new List<string>(w.Timeframes ?? new List<string>())
                }).ToList();
            }
        }

        /// <summary>
        /// Add a symbol to the watched list and persist. Returns false if
        /// already present (case-insensitive) or input is invalid.
        /// </summary>
        public bool AddWatchedSymbol(string symbolFullName, IEnumerable<string> timeframes)
        {
            if (string.IsNullOrWhiteSpace(symbolFullName)) return false;
            string sym = symbolFullName.Trim();
            var tfList = (timeframes ?? new List<string>())
                .Where(t => !string.IsNullOrWhiteSpace(t))
                .Select(t => t.Trim())
                .Distinct()
                .ToList();
            if (tfList.Count == 0) tfList.Add("1m");

            lock (configLock)
            {
                if (BarsSettings.WatchedSymbols == null)
                    BarsSettings.WatchedSymbols = new List<JournifiNTWatchedSymbol>();
                if (BarsSettings.WatchedSymbols.Any(w =>
                    string.Equals(w.Symbol, sym, StringComparison.OrdinalIgnoreCase)))
                {
                    return false;
                }
                BarsSettings.WatchedSymbols.Add(new JournifiNTWatchedSymbol
                {
                    Symbol = sym,
                    Timeframes = tfList
                });
            }
            JournifiNTSettingsStore.Save();
            JournifiNTLog.Info("Bars", $"Added watched symbol: {sym} ({string.Join(",", tfList)})");
            return true;
        }

        /// <summary>
        /// Remove a symbol from the watched list, persist, and cancel any
        /// active BarsRequests for it. Returns true if removed.
        /// </summary>
        public bool RemoveWatchedSymbol(string symbolFullName)
        {
            if (string.IsNullOrWhiteSpace(symbolFullName)) return false;
            bool removed;
            lock (configLock)
            {
                if (BarsSettings.WatchedSymbols == null) return false;
                int before = BarsSettings.WatchedSymbols.Count;
                BarsSettings.WatchedSymbols.RemoveAll(w =>
                    string.Equals(w.Symbol, symbolFullName, StringComparison.OrdinalIgnoreCase));
                removed = BarsSettings.WatchedSymbols.Count < before;
            }
            if (removed)
            {
                JournifiNTSettingsStore.Save();
                // Tear down any active live-update subscriptions for this symbol —
                // otherwise BarsRequest keeps firing and appending to a file the
                // user no longer wants tracked.
                var keysToDrop = activeRequests.Keys
                    .Where(k => k.StartsWith(symbolFullName + "|", StringComparison.OrdinalIgnoreCase))
                    .ToArray();
                foreach (var k in keysToDrop)
                {
                    if (activeRequests.TryRemove(k, out BarsRequest req))
                    {
                        try { req?.Dispose(); } catch { /* gone */ }
                    }
                    maxWrittenIndex.TryRemove(k, out _);
                }
                JournifiNTLog.Info("Bars",
                    $"Removed watched symbol: {symbolFullName} (cancelled {keysToDrop.Length} live subscription(s))");
            }
            return removed;
        }

        /// <summary>
        /// Manually re-pull bars for all watched symbols. Also restarts the
        /// connect-watcher if no feeds were connected at trigger time.
        /// </summary>
        public void ResyncAll()
        {
            firstPullDone = false;
            PullAllWatchedSymbols("manual-resync");

            // If pull found no feeds, ensure the connect-watcher is running
            // so we'll auto-retry when one appears. Handles the case where
            // the original watcher gave up after MAX_ATTEMPTS.
            if (!firstPullDone && connectWatcherTimer == null && cts != null)
            {
                connectWatcherAttempts = 0;
                JournifiNTLog.Info("Bars",
                    "Resync found no feeds — restarting connect-watcher to retry when one appears.");
                connectWatcherTimer = new System.Threading.Timer(
                    _ => SafeExecute(CheckConnectAndRetry),
                    null,
                    CONNECT_WATCHER_INTERVAL_MS,
                    CONNECT_WATCHER_INTERVAL_MS);
            }
        }

        /// <summary>Refresh in-memory settings cache. Called by the UI tab after edits.</summary>
        public void ReloadSettings()
        {
            JournifiNTLog.Info("Bars",
                $"Settings reloaded ({BarsSettings.WatchedSymbols?.Count ?? 0} watched symbol(s), " +
                $"historicalDays={BarsSettings.HistoricalDays})");
        }

        #endregion

        #region Lifecycle

        public void Initialize()
        {
            if (initialized)
            {
                JournifiNTLog.Warn("Bars", "Initialize called twice — ignoring.");
                return;
            }
            try
            {
                if (!Directory.Exists(JournifiNTPaths.BarsDir))
                    Directory.CreateDirectory(JournifiNTPaths.BarsDir);

                JournifiNTLog.Info("Bars", $"Output folder: {JournifiNTPaths.BarsDir}");
                JournifiNTLog.Info("Bars",
                    $"Watched: {BarsSettings.WatchedSymbols?.Count ?? 0} symbol(s), " +
                    $"historical={BarsSettings.HistoricalDays}d, " +
                    $"tradingHours='{BarsSettings.TradingHoursTemplate}'");

                if ((BarsSettings.WatchedSymbols?.Count ?? 0) == 0)
                {
                    JournifiNTLog.Info("Bars",
                        "No watched symbols configured. Add some via the Bars tab and they'll be pulled immediately.");
                }

                // v3.0.4+ — rehydrate the persisted auto-roll set so the startup
                // pull below re-subscribes the right contract(s) without waiting
                // for the day's first fill.
                RehydrateAutoContracts();

                cts = new CancellationTokenSource();
                Stats.IsRunning = true;
                Stats.StartTime = DateTime.Now;

                // Schedule the initial pull on a 5s delay so NT has time to
                // connect data feeds before we fire BarsRequests.
                Task.Run(async () =>
                {
                    try
                    {
                        await Task.Delay(INITIAL_PULL_DELAY_MS, cts.Token);
                        if (cts.IsCancellationRequested) return;
                        PullAllWatchedSymbols("startup");
                    }
                    catch (OperationCanceledException) { /* expected on shutdown */ }
                    catch (Exception ex)
                    {
                        JournifiNTLog.Error("Bars", "Initial pull failed", ex);
                    }
                });

                // Heartbeat — keep status.json fresh so the journal knows we're alive.
                heartbeatTimer = new System.Threading.Timer(
                    _ => SafeExecute(WriteStatus), null,
                    1000, HEARTBEAT_MS);

                // Connect-watcher — see CheckConnectAndRetry for the bounded
                // retry semantics. Starts one watcher tick AFTER the scheduled
                // startup pull so we don't race it.
                connectWatcherAttempts = 0;
                firstPullDone = false;
                connectWatcherTimer = new System.Threading.Timer(
                    _ => SafeExecute(CheckConnectAndRetry), null,
                    INITIAL_PULL_DELAY_MS + CONNECT_WATCHER_INTERVAL_MS,
                    CONNECT_WATCHER_INTERVAL_MS);

                initialized = true;
                JournifiNTLog.Info("Bars", "Module initialized successfully.");
            }
            catch (Exception ex)
            {
                JournifiNTLog.Error("Bars", "Initialization failed", ex);
            }
        }

        public void Cleanup()
        {
            if (!initialized) return;
            try
            {
                JournifiNTLog.Info("Bars", "Module shutting down...");

                cts?.Cancel();
                heartbeatTimer?.Dispose();
                heartbeatTimer = null;
                connectWatcherTimer?.Dispose();
                connectWatcherTimer = null;
                // v3.1+ — tear down self-heal timer
                selfHealTimer?.Dispose();
                selfHealTimer = null;

                // Dispose any in-flight BarsRequests — without Dispose() the
                // request keeps internal subscriptions alive past assembly
                // unload, including the live-Update callback we registered.
                foreach (var kvp in activeRequests.ToArray())
                {
                    try { kvp.Value?.Dispose(); } catch { /* gone */ }
                }
                activeRequests.Clear();
                maxWrittenIndex.Clear();
                // v3.0.4+ — drop the in-memory auto-set; it rehydrates from the
                // persisted settings on the next Initialize.
                lock (autoLock) { autoContracts.Clear(); }

                // Final status flush with isRunning=false so the journal
                // shows accurate "stopped" state.
                Stats.IsRunning = false;
                SafeExecute(WriteStatus);

                JournifiNTLog.Info("Bars",
                    $"Shutdown complete. Bars written this session: {barsWrittenSinceStart}");

                cts?.Dispose();
                initialized = false;
            }
            catch (Exception ex)
            {
                JournifiNTLog.Error("Bars", "Cleanup error", ex);
            }
        }

        #endregion

        #region Bar pull mechanics

        private void PullAllWatchedSymbols(string trigger)
        {
            var watched = BarsSettings.WatchedSymbols;
            // v3.0.4+ — auto-managed (rolled) contracts are pulled alongside the
            // manual watchlist, so "nothing to pull" must consider both.
            List<string> autoToPull;
            lock (autoLock) { autoToPull = autoContracts.Keys.ToList(); }
            if ((watched == null || watched.Count == 0) && autoToPull.Count == 0)
            {
                JournifiNTLog.Info("Bars", $"PullAll ({trigger}): nothing to pull.");
                // Set firstPullDone so the connect-watcher self-cancels on its
                // next tick. With zero watched symbols there's nothing to
                // retry; polling would just spam the log every 30s for 20
                // attempts. The watcher will resume automatically the next
                // time AddWatchedSymbol → ResyncAll re-arms it.
                firstPullDone = true;
                return;
            }

            // Pre-flight connection check — BarsRequest silently returns empty
            // when no feed is connected, so log loudly upfront.
            string[] connectedNames = GetConnectedConnectionNames();
            if (connectedNames.Length == 0)
            {
                JournifiNTLog.Warn("Bars",
                    $"PullAll ({trigger}): no data-feed connections active. " +
                    "BarsRequests will return no data until you connect to a provider in NT.");
                return;
            }
            JournifiNTLog.Info("Bars",
                $"PullAll ({trigger}): connected feeds → {string.Join(", ", connectedNames)}");

            DateTime fromDate = DateTime.Now.AddDays(-BarsSettings.HistoricalDays).Date;
            DateTime toDate = DateTime.Now;

            // Null-safe: `watched` may legitimately be null here now that the
            // guard above lets an auto-contracts-only pull through (fresh install
            // that never pinned a manual symbol). Use this count in every log line
            // below instead of dereferencing `watched.Count` directly.
            int watchedCount = watched?.Count ?? 0;
            JournifiNTLog.Info("Bars",
                $"PullAll ({trigger}): {watchedCount} symbol(s), from {fromDate:yyyy-MM-dd} to {toDate:yyyy-MM-dd}");

            // v3.1+ — when SubscribeOneMinuteOnly is enabled, force the
            // subscription list to just ["1m"] regardless of what the user
            // configured per symbol. Higher timeframes are derived in
            // JournifiAI via aggregation. Rationale documented on the
            // JournifiNTBarsSettings.SubscribeOneMinuteOnly property.
            //
            // We honor user-configured TFs when the toggle is OFF so existing
            // installs that opt out keep their prior multi-TF behavior.
            bool oneMinOnly = BarsSettings?.SubscribeOneMinuteOnly ?? false;
            var effectiveTfs = oneMinOnly
                ? new List<string> { "1m" }
                : (List<string>)null;

            int requestsFired = 0;
            foreach (var entry in (watched ?? new List<JournifiNTWatchedSymbol>()))
            {
                if (cts == null || cts.IsCancellationRequested) return;
                var tfsToFire = effectiveTfs ?? (entry.Timeframes ?? new List<string>());
                foreach (string tf in tfsToFire)
                {
                    try
                    {
                        StartBarsRequest(entry.Symbol, tf, fromDate, toDate);
                        requestsFired++;
                    }
                    catch (Exception ex)
                    {
                        JournifiNTLog.Error("Bars",
                            $"StartBarsRequest failed for {entry.Symbol} {tf}", ex);
                    }
                }
            }

            // v3.0.4+ — pull the auto-managed (rolled) contracts on the same feed
            // pre-flight. Their TF set honors SubscribeOneMinuteOnly (else the
            // union of the watchlist's TFs) — see EffectiveAutoTfs.
            if (autoToPull.Count > 0)
            {
                var autoTfs = EffectiveAutoTfs();
                foreach (string contract in autoToPull)
                {
                    if (cts == null || cts.IsCancellationRequested) return;
                    foreach (string tf in autoTfs)
                    {
                        try
                        {
                            StartBarsRequest(contract, tf, fromDate, toDate);
                            requestsFired++;
                        }
                        catch (Exception ex)
                        {
                            JournifiNTLog.Error("Bars",
                                $"StartBarsRequest failed for auto-contract {contract} {tf}", ex);
                        }
                    }
                }
                JournifiNTLog.Info("Bars",
                    $"PullAll ({trigger}): auto-roll set → {string.Join(", ", autoToPull)} ({autoTfs.Count} TF each).");
            }

            if (requestsFired > 0)
            {
                firstPullDone = true;
                JournifiNTLog.Info("Bars",
                    oneMinOnly
                        ? $"PullAll: subscribed to 1m only ({watchedCount} symbols + {autoToPull.Count} auto); higher TFs derived in JournifiAI."
                        : $"PullAll: subscribed to user-configured timeframes ({watchedCount} symbols + {autoToPull.Count} auto).");
                // Kick off the self-heal sweep loop now that initial pulls
                // are queued. EnsureSelfHealTimer is idempotent — safe to
                // call on every PullAll even if a timer already exists.
                EnsureSelfHealTimer();
            }
        }

        /// <summary>
        /// Connect-watcher tick. See header comments — three exit paths:
        ///   1. firstPullDone is true → self-dispose
        ///   2. MAX_ATTEMPTS exceeded → log hint, self-dispose
        ///   3. Feed appears → fire delayed pull (which flips firstPullDone
        ///      and triggers exit 1 on the next tick)
        /// </summary>
        private void CheckConnectAndRetry()
        {
            if (firstPullDone)
            {
                try { connectWatcherTimer?.Dispose(); } catch { /* gone */ }
                connectWatcherTimer = null;
                return;
            }

            connectWatcherAttempts++;
            if (connectWatcherAttempts > CONNECT_WATCHER_MAX_ATTEMPTS)
            {
                int elapsedSec = (connectWatcherAttempts - 1) * CONNECT_WATCHER_INTERVAL_MS / 1000;
                JournifiNTLog.Warn("Bars",
                    $"Connect-watcher giving up after {connectWatcherAttempts - 1} attempts " +
                    $"({elapsedSec}s without a connected feed). Connect a provider and click Resync.");
                try { connectWatcherTimer?.Dispose(); } catch { /* gone */ }
                connectWatcherTimer = null;
                return;
            }

            string[] feeds = GetConnectedConnectionNames();
            if (feeds.Length == 0) return; // still no feed; wait for next tick

            JournifiNTLog.Info("Bars",
                $"Connect-watcher: feed(s) now active ({string.Join(", ", feeds)}) — " +
                $"firing delayed pull (attempt {connectWatcherAttempts}).");
            PullAllWatchedSymbols("delayed-connect");
        }

        private static string[] GetConnectedConnectionNames()
        {
            var names = new List<string>();
            try
            {
                lock (Connection.Connections)
                {
                    foreach (Connection c in Connection.Connections)
                    {
                        if (c?.Status == ConnectionStatus.Connected)
                        {
                            string name = c.Options?.Name ?? c.Options?.Provider.ToString() ?? "Unknown";
                            names.Add(name);
                        }
                    }
                }
            }
            catch { /* best-effort */ }
            return names.ToArray();
        }

        private void StartBarsRequest(string symbolFullName, string timeframe,
            DateTime fromDate, DateTime toDate)
        {
            // Route the lookup through our shared cache (single dict shared
            // with SyncModule, so repeated lookups for the same contract are
            // free after the first hit).
            Instrument instrument = JournifiNTInstrumentCache.Resolve(symbolFullName);
            if (instrument == null)
            {
                JournifiNTLog.Error("Bars",
                    $"Instrument not found: '{symbolFullName}'. Open a chart or watchlist with it in NT first.");
                return;
            }

            BarsPeriod period = ParseTimeframe(timeframe);
            if (period == null)
            {
                JournifiNTLog.Error("Bars",
                    $"Unsupported timeframe '{timeframe}' for {symbolFullName}. Supported: 1m, 5m, 15m, 1h, 4h.");
                return;
            }

            string key = $"{symbolFullName}|{timeframe}";

            // Dispose any in-flight prior request for this (symbol, tf) so
            // Resync doesn't pile them up. Reset the watermark so the
            // historical Request callback can re-seed it cleanly.
            if (activeRequests.TryRemove(key, out BarsRequest old))
            {
                try { old.Dispose(); } catch { /* gone */ }
            }
            maxWrittenIndex.TryRemove(key, out _);

            // Resolve TradingHours with a safe fallback. NT's per-feed default
            // ("CME US Index Futures ETH") may not exist on every install;
            // fall back to "Default 24 x 7" which ships with every NT8.
            TradingHours th = TradingHours.Get(BarsSettings.TradingHoursTemplate);
            if (th == null)
            {
                JournifiNTLog.Warn("Bars",
                    $"TradingHours template '{BarsSettings.TradingHoursTemplate}' not found; " +
                    "falling back to 'Default 24 x 7'");
                th = TradingHours.Get("Default 24 x 7");
            }

            var request = new BarsRequest(instrument, fromDate, toDate)
            {
                BarsPeriod = period,
                TradingHours = th
            };
            activeRequests[key] = request;

            // Two subscriptions on the same request. Subscribe to .Update
            // FIRST so any updates that arrive concurrently with the
            // historical load are captured (race-safe). Both the request
            // and the event args are passed through to the handler: we
            // need request.Bars (type Bars) for the actual data and
            // e.MinIndex/e.MaxIndex for the range NT says changed.
            request.Update += (sender, e) =>
            {
                SafeExecute(() => OnBarsLiveUpdate(symbolFullName, timeframe, request, e));
            };

            request.Request(new Action<BarsRequest, ErrorCode, string>((req, errorCode, errorMessage) =>
            {
                SafeExecute(() => OnBarsResult(symbolFullName, timeframe, req, errorCode, errorMessage));
            }));
        }

        private void OnBarsResult(string symbolFullName, string timeframe,
            BarsRequest request, ErrorCode errorCode, string errorMessage)
        {
            if (errorCode != ErrorCode.NoError)
            {
                JournifiNTLog.Error("Bars",
                    $"BarsRequest {symbolFullName} {timeframe}: {errorCode} — {errorMessage}");
                return;
            }
            if (request?.Bars == null || request.Bars.Count == 0)
            {
                JournifiNTLog.Warn("Bars",
                    $"BarsRequest {symbolFullName} {timeframe}: no bars returned " +
                    "(data feed may not have history for this range)");
                return;
            }

            int count = request.Bars.Count;
            int totalWritten = WriteBarsRange(symbolFullName, timeframe, request.Bars, 0, count - 1);

            // Seed the watermark to the in-progress bar's index so subsequent
            // Update fires don't re-process the historical range. The Update
            // event will increment MaxIndex when a NEW bar closes; the watermark
            // logic in OnBarsLiveUpdate writes only [prevMax+1 .. MaxIndex-1]
            // from that point on. In-progress tick updates (MaxIndex == prevMax)
            // are silently skipped.
            string key = $"{symbolFullName}|{timeframe}";
            maxWrittenIndex[key] = count - 1;

            if (totalWritten > 0)
            {
                Interlocked.Add(ref barsWrittenSinceStart, totalWritten);
                lastWriteAt = DateTime.Now;
                lastWritePerSymbol[symbolFullName] = DateTime.Now;
                JournifiNTLog.Info("Bars",
                    $"{symbolFullName} {timeframe}: historical pull wrote {totalWritten} bar(s) [0..{count - 1}]");
            }
            JournifiNTLog.Info("Bars", $"{symbolFullName} {timeframe}: subscribed to live bar updates");
        }

        /// <summary>
        /// Live bar event. Uses the official <see cref="BarsUpdateEventArgs"/>
        /// API but with a per-(symbol, timeframe) watermark to avoid writing
        /// on every in-progress tick:
        ///
        ///   1. <b>New bars closed</b> (MaxIndex > maxWrittenIndex) — write
        ///      the range [maxWrittenIndex+1 .. MaxIndex-1] (i.e., the newly
        ///      closed bars). EXCLUDE MaxIndex itself: that's the brand-new
        ///      in-progress bar; future ticks updating it won't trigger a
        ///      write until it closes (when MaxIndex grows again).
        ///   2. <b>Late correction</b> (MinIndex &lt; maxWrittenIndex) — NT
        ///      is reporting a change to an older closed bar. Honor it via
        ///      <c>WriteBarsRange(MinIndex, MaxIndex-1)</c> — overwrite-on-
        ///      duplicate dedup in WriteMonthlyFile handles the rewrite.
        ///   3. <b>In-progress tick on current bar</b> (MaxIndex unchanged) —
        ///      SKIP. This was the bug source pre-fix: NT fires Update on
        ///      every tick (potentially many per second per symbol × per
        ///      timeframe), and the old code rewrote the whole monthly CSV
        ///      each time. Writing only on bar-close means the disk file is
        ///      at most one timeframe-period stale, which is fine for trade-
        ///      card chart rendering (the trade is already in the past).
        ///
        /// We read the OHLCV from <c>request.Bars</c> (type <c>Bars</c>)
        /// rather than <c>e.BarsSeries</c> (type <c>BarsSeries</c>, which
        /// can't be passed to <see cref="WriteBarsRange"/> directly). They
        /// reference the same underlying series so the data is consistent.
        ///
        /// (Note: <c>BarsUpdateEventArgs.ErrorCode</c> doesn't exist on
        /// 8.1.6.3 — the historical Request() callback receives ErrorCode
        /// separately; live updates don't carry one.)
        /// </summary>
        private void OnBarsLiveUpdate(string symbolFullName, string timeframe,
            BarsRequest request, BarsUpdateEventArgs e)
        {
            if (e == null || request?.Bars == null) return;
            if (e.MaxIndex < e.MinIndex) return; // empty range — nothing to do

            // Stamp "feed alive" BEFORE any branching. We want this to move
            // on every NT update fire — including in-progress ticks and
            // dedup-resolved no-op writes — so the dashboard can tell
            // "NT is streaming" apart from "bytes hit disk." Without this,
            // LastWriteAt looks 1h stale on a perfectly healthy connection
            // that just hasn't produced a NEW closed bar in a 5m timeframe
            // because the watched symbol is quiet.
            lastUpdateFireAt = DateTime.Now;

            string key = $"{symbolFullName}|{timeframe}";
            int prevMax = maxWrittenIndex.TryGetValue(key, out int v) ? v : -1;

            int writeFrom;
            int writeTo;
            string reason;

            if (e.MinIndex < prevMax)
            {
                // Late correction — honor the full range NT specifies, but
                // still exclude the trailing in-progress bar (MaxIndex).
                writeFrom = e.MinIndex;
                writeTo = e.MaxIndex - 1;
                reason = "correction";
            }
            else if (e.MaxIndex > prevMax)
            {
                // New bar(s) closed — write [prevMax+1 .. MaxIndex-1]. If
                // this is the first update post-historical pull (prevMax = -1
                // because OnBarsResult doesn't seed the watermark) we use
                // MaxIndex - 1 as the lower bound to avoid rewriting the
                // entire historical range.
                writeFrom = prevMax >= 0 ? prevMax + 1 : e.MaxIndex - 1;
                writeFrom = Math.Max(0, writeFrom);
                writeTo = e.MaxIndex - 1;
                reason = "new bar";
            }
            else
            {
                // In-progress tick on current bar — skip entirely.
                return;
            }

            if (writeTo < writeFrom) return; // nothing to actually write

            int totalWritten = WriteBarsRange(symbolFullName, timeframe, request.Bars, writeFrom, writeTo);

            // Always update the watermark to the highest index NT has shown
            // us, even if no rows actually changed (zero-write case).
            // Without this, repeated identical Update fires would re-enter
            // the "new bar" branch every time.
            if (e.MaxIndex > prevMax) maxWrittenIndex[key] = e.MaxIndex;

            if (totalWritten > 0)
            {
                Interlocked.Add(ref barsWrittenSinceStart, totalWritten);
                lastWriteAt = DateTime.Now;
                lastWritePerSymbol[symbolFullName] = DateTime.Now;
                JournifiNTLog.Info("Bars",
                    $"{symbolFullName} {timeframe}: live append wrote {totalWritten} bar(s) " +
                    $"({reason}, range [{writeFrom}..{writeTo}])");
            }
        }

        #endregion

        #region Self-heal sweep (v3.1+)

        /// <summary>
        /// Lazily start the self-heal Timer. Idempotent — safe to call from
        /// every PullAllWatchedSymbols; only the first call actually creates
        /// the timer. Honors the SelfHealIntervalMinutes setting; 0 disables.
        /// </summary>
        private void EnsureSelfHealTimer()
        {
            if (selfHealTimer != null) return;
            int min = BarsSettings?.SelfHealIntervalMinutes ?? 0;
            if (min <= 0)
            {
                JournifiNTLog.Info("Bars", "Self-heal sweep disabled (SelfHealIntervalMinutes=0).");
                return;
            }
            int intervalMs = min * 60 * 1000;
            // First fire after the full interval (not immediately) — gives the
            // initial historical pull time to land its bars + watermark before
            // the sweep races them.
            selfHealTimer = new System.Threading.Timer(_ => SafeSelfHealSweep(),
                null, intervalMs, intervalMs);
            JournifiNTLog.Info("Bars",
                $"Self-heal sweep armed: every {min} min, looks back {BarsSettings.SelfHealLookbackMinutes} min.");
        }

        private void SafeSelfHealSweep()
        {
            // v3.0.4+ — retire superseded auto-roll contracts past their grace
            // window first (own try so a hiccup can't block the heal sweep).
            try { RetireExpiredAutoContracts(); }
            catch (Exception ex)
            {
                JournifiNTLog.Error("Bars", "Auto-roll retirement sweep crashed", ex);
            }
            try { SelfHealSweep(); }
            catch (Exception ex)
            {
                JournifiNTLog.Error("Bars", "Self-heal sweep crashed", ex);
            }
        }

        /// <summary>
        /// Re-pull the last SelfHealLookbackMinutes of 1m bars for each
        /// watched symbol via a fresh BarsRequest, then merge into the file
        /// using the WriteMonthlyFile dedup logic. Fills gaps left by the
        /// live BarsUpdate stream (which silently drops events under load).
        ///
        /// Why 1m specifically: this is the smallest TF, so a 1-hour lookback
        /// catches the most granular drops. Higher TFs are derived in
        /// JournifiAI via aggregation, so 1m is the only file that needs
        /// healing.
        ///
        /// Each sweep fires N BarsRequests (one per watched symbol). They run
        /// in parallel via NT's threading. Results are routed through the
        /// SAME OnBarsResult callback used by initial pulls, so the existing
        /// WriteBarsRange + dedup pipeline handles the merge with no special
        /// casing.
        /// </summary>
        private void SelfHealSweep()
        {
            if (cts == null || cts.IsCancellationRequested) return;
            if (!IsEnabled) return;

            int lookbackMin = BarsSettings?.SelfHealLookbackMinutes ?? 60;
            DateTime fromDate = DateTime.Now.AddMinutes(-lookbackMin);
            DateTime toDate = DateTime.Now;

            List<JournifiNTWatchedSymbol> watched = GetWatchedSymbolsSnapshot();
            // v3.0.4+ — heal auto-rolled contracts too. A freshly-rolled contract
            // is exactly as exposed to the cash-open BarsUpdate-drop the sweep was
            // built for as a pinned symbol, so it must be re-pulled here. Snapshot
            // the keys (not under the sweep's path) and union with the manual set.
            List<string> autoToHeal = (AutoManagedContractsSnapshot ?? new List<string>()).ToList();
            if (watched.Count == 0 && autoToHeal.Count == 0) return;

            Interlocked.Increment(ref selfHealRunsTotal);
            lastSelfHealAt = DateTime.Now;

            int fired = 0;
            foreach (var entry in watched)
            {
                if (cts.IsCancellationRequested) return;
                if (string.IsNullOrWhiteSpace(entry.Symbol)) continue;
                try
                {
                    // Always 1m, regardless of SubscribeOneMinuteOnly setting.
                    // Higher TFs aggregate from 1m on the JournifiAI side, so
                    // healing 1m heals everything downstream.
                    StartBarsRequest(entry.Symbol, "1m", fromDate, toDate);
                    fired++;
                }
                catch (Exception ex)
                {
                    JournifiNTLog.Warn("Bars",
                        $"Self-heal request failed for {entry.Symbol} 1m: {ex.Message}");
                }
            }

            // Auto-rolled contracts (skip any already covered by a manual pin).
            var watchedNames = new HashSet<string>(
                watched.Where(w => !string.IsNullOrWhiteSpace(w.Symbol)).Select(w => w.Symbol),
                StringComparer.OrdinalIgnoreCase);
            foreach (var contract in autoToHeal)
            {
                if (cts.IsCancellationRequested) return;
                if (string.IsNullOrWhiteSpace(contract) || watchedNames.Contains(contract)) continue;
                try
                {
                    StartBarsRequest(contract, "1m", fromDate, toDate);
                    fired++;
                }
                catch (Exception ex)
                {
                    JournifiNTLog.Warn("Bars",
                        $"Self-heal request failed for auto-contract {contract} 1m: {ex.Message}");
                }
            }

            if (fired > 0)
            {
                JournifiNTLog.Info("Bars",
                    $"Self-heal sweep #{selfHealRunsTotal}: fired {fired} 1m request(s), " +
                    $"window {fromDate:HH:mm}–{toDate:HH:mm}. Dedup determines actual writes.");
            }
        }

        #endregion

        #region Auto-roll (v3.0.4+ — execution-driven contract subscription)

        /// <summary>Read-only snapshot of the auto-managed contract set (for status/UI).</summary>
        public IReadOnlyList<string> AutoManagedContractsSnapshot
        {
            get { lock (autoLock) { return autoContracts.Keys.ToList(); } }
        }

        /// <summary>
        /// Execution-driven auto-roll entry point. Called by the Sync module on
        /// each enabled-account FUTURES fill. If the traded contract isn't already
        /// actively auto-subscribed, subscribe its bars and mark any same-root
        /// predecessor for retirement after RollRetentionDays. Fire-and-forget +
        /// self-contained try/catch — a bars hiccup must never break execution
        /// capture. Cheap no-op on every fill once the contract is subscribed.
        /// </summary>
        public void NoteTradedContract(Instrument instrument)
        {
            try
            {
                if (!BarsSettings.AutoRollContracts) return;
                if (instrument?.MasterInstrument == null) return;
                // Futures only — never try to "roll" an equity/option. (The Sync
                // caller already gates on this; double-gate is cheap + safe.)
                if (instrument.MasterInstrument.InstrumentType != InstrumentType.Future) return;

                string root = instrument.MasterInstrument.Name;     // "MNQ"   (reliable NT API)
                string contract = instrument.FullName;              // "MNQU6" / "MNQ 06-26"
                if (string.IsNullOrWhiteSpace(root) || string.IsNullOrWhiteSpace(contract)) return;

                bool subscribeNow = false;
                lock (autoLock)
                {
                    // Already actively tracked → cheap no-op (the common per-fill path).
                    if (autoContracts.TryGetValue(contract, out var existing) && existing.RetireAtUtc == null)
                        return;

                    // (Re)activate this contract.
                    autoContracts[contract] = new AutoContractState { Root = root, RetireAtUtc = null };

                    // Supersede any OTHER still-active contract of the SAME root —
                    // it keeps pulling through RollRetentionDays (roll-week overlap)
                    // then gets retired by the self-heal sweep. Mutating the value's
                    // field doesn't alter the dictionary's structure, so iterating
                    // here is safe.
                    DateTime retireAt = DateTime.UtcNow.AddDays(Math.Max(0, BarsSettings.RollRetentionDays));
                    foreach (var kv in autoContracts)
                    {
                        if (string.Equals(kv.Key, contract, StringComparison.OrdinalIgnoreCase)) continue;
                        if (kv.Value.RetireAtUtc == null &&
                            string.Equals(kv.Value.Root, root, StringComparison.OrdinalIgnoreCase))
                        {
                            kv.Value.RetireAtUtc = retireAt;
                            JournifiNTLog.Info("Bars",
                                $"Auto-roll: {kv.Key} superseded by {contract} (root {root}); retiring in {BarsSettings.RollRetentionDays}d.");
                        }
                    }

                    PersistAutoSet(); // caller holds autoLock
                    subscribeNow = true;
                }

                if (subscribeNow)
                {
                    JournifiNTLog.Info("Bars", $"Auto-roll: new contract {contract} (root {root}) — subscribing bars.");
                    SubscribeAutoContract(contract);
                    // Ensure the self-heal/retirement timer is running so the new
                    // contract gets healed + predecessors retired.
                    EnsureSelfHealTimer();
                }
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("Bars", $"NoteTradedContract failed: {ex.Message}");
            }
        }

        /// <summary>Subscribe bars for one auto-managed contract across the effective TF set.</summary>
        private void SubscribeAutoContract(string contract)
        {
            DateTime fromDate = DateTime.Now.AddDays(-BarsSettings.HistoricalDays).Date;
            DateTime toDate = DateTime.Now;
            foreach (string tf in EffectiveAutoTfs())
            {
                try { StartBarsRequest(contract, tf, fromDate, toDate); }
                catch (Exception ex)
                {
                    JournifiNTLog.Error("Bars", $"Auto-roll StartBarsRequest failed for {contract} {tf}", ex);
                }
            }
        }

        /// <summary>
        /// TF set for auto-managed contracts. Honors SubscribeOneMinuteOnly (1m
        /// only — higher TFs aggregate in JournifiAI); otherwise the union of the
        /// watchlist's configured TFs so a rolled contract matches the user's
        /// existing coverage, falling back to the full supported set.
        /// </summary>
        private List<string> EffectiveAutoTfs()
        {
            if (BarsSettings?.SubscribeOneMinuteOnly ?? false)
                return new List<string> { "1m" };

            var tfs = new List<string>();
            lock (configLock)
            {
                var watched = BarsSettings?.WatchedSymbols;
                if (watched != null)
                {
                    foreach (var w in watched)
                    {
                        if (w?.Timeframes == null) continue;
                        foreach (var tf in w.Timeframes)
                            if (!string.IsNullOrWhiteSpace(tf) && !tfs.Contains(tf)) tfs.Add(tf);
                    }
                }
            }
            if (tfs.Count == 0) tfs.AddRange(new[] { "1m", "5m", "15m", "1h", "4h" });
            return tfs;
        }

        /// <summary>Write the active auto-set to settings as "ROOT|CONTRACT". CALLER MUST HOLD autoLock.</summary>
        private void PersistAutoSet()
        {
            var list = new List<string>(autoContracts.Count);
            foreach (var kv in autoContracts)
                list.Add((kv.Value.Root ?? "") + "|" + kv.Key);
            BarsSettings.AutoManagedContracts = list;
            JournifiNTSettingsStore.Save();
        }

        /// <summary>
        /// Dispose BarsRequests for superseded contracts whose grace window has
        /// elapsed, drop them from the auto-set, and persist. History files stay
        /// on disk. Runs on the self-heal timer (resource hygiene, not correctness).
        /// </summary>
        private void RetireExpiredAutoContracts()
        {
            DateTime nowUtc = DateTime.UtcNow;
            var toRetire = new List<string>();
            lock (autoLock)
            {
                foreach (var kv in autoContracts)
                    if (kv.Value.RetireAtUtc.HasValue && kv.Value.RetireAtUtc.Value <= nowUtc)
                        toRetire.Add(kv.Key);
                if (toRetire.Count == 0) return;
                foreach (var c in toRetire) autoContracts.Remove(c);
                PersistAutoSet();
            }

            // Dispose live subscriptions for retired contracts (outside autoLock).
            foreach (var contract in toRetire)
            {
                var keys = activeRequests.Keys
                    .Where(k => k.StartsWith(contract + "|", StringComparison.OrdinalIgnoreCase))
                    .ToArray();
                foreach (var k in keys)
                {
                    if (activeRequests.TryRemove(k, out BarsRequest req))
                    {
                        try { req?.Dispose(); } catch { /* gone */ }
                    }
                    maxWrittenIndex.TryRemove(k, out _);
                }
                JournifiNTLog.Info("Bars",
                    $"Auto-roll: retired superseded contract {contract} (disposed {keys.Length} subscription(s); history kept).");
            }
        }

        /// <summary>
        /// Rebuild the in-memory auto-set from the persisted "ROOT|CONTRACT" list
        /// on startup, so the startup pull re-subscribes the right contract(s)
        /// without waiting for the day's first fill. All rehydrated entries are
        /// active (RetireAtUtc=null); the next fill re-asserts same-root supersession.
        /// </summary>
        private void RehydrateAutoContracts()
        {
            try
            {
                var persisted = BarsSettings?.AutoManagedContracts;
                if (persisted == null || persisted.Count == 0) return;
                string joined;
                lock (autoLock)
                {
                    autoContracts.Clear();
                    foreach (var s in persisted)
                    {
                        if (string.IsNullOrWhiteSpace(s)) continue;
                        int bar = s.IndexOf('|');
                        if (bar <= 0 || bar >= s.Length - 1) continue;
                        string root = s.Substring(0, bar);
                        string contract = s.Substring(bar + 1);
                        if (!string.IsNullOrWhiteSpace(contract))
                            autoContracts[contract] = new AutoContractState { Root = root, RetireAtUtc = null };
                    }
                    joined = string.Join(", ", autoContracts.Keys);
                }
                JournifiNTLog.Info("Bars", $"Auto-roll: rehydrated persisted contract(s): {joined}");
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("Bars", $"Auto-roll rehydrate failed: {ex.Message}");
            }
        }

        #endregion

        #region File output (write pipeline)

        /// <summary>
        /// Walk a bar range [fromIdx..toIdx] inclusive, group by year-month,
        /// and dispatch to WriteMonthlyFile per month.
        /// </summary>
        private int WriteBarsRange(string symbolFullName, string timeframe, Bars bars, int fromIdx, int toIdx)
        {
            if (bars == null || bars.Count == 0) return 0;
            if (fromIdx < 0) fromIdx = 0;
            if (toIdx >= bars.Count) toIdx = bars.Count - 1;
            if (toIdx < fromIdx) return 0;

            var byMonth = new SortedDictionary<string, List<JournifiSyncNTBarRow>>();
            for (int i = fromIdx; i <= toIdx; i++)
            {
                DateTime t = bars.GetTime(i);
                long unixSec = ToUnixSeconds(t);
                string monthKey = t.ToString("yyyy-MM", CultureInfo.InvariantCulture);
                if (!byMonth.TryGetValue(monthKey, out var list))
                {
                    list = new List<JournifiSyncNTBarRow>();
                    byMonth[monthKey] = list;
                }
                list.Add(new JournifiSyncNTBarRow
                {
                    TimeUnix = unixSec,
                    Open    = bars.GetOpen(i),
                    High    = bars.GetHigh(i),
                    Low     = bars.GetLow(i),
                    Close   = bars.GetClose(i),
                    Volume  = bars.GetVolume(i),
                });
            }

            int totalWritten = 0;
            foreach (var kvp in byMonth)
                totalWritten += WriteMonthlyFile(symbolFullName, timeframe, kvp.Key, kvp.Value);
            return totalWritten;
        }

        #endregion

        #region File output (atomic, dedup-on-merge)

        private int WriteMonthlyFile(string symbolFullName, string timeframe,
            string monthKey, List<JournifiSyncNTBarRow> bars)
        {
            if (bars == null || bars.Count == 0) return 0;

            string sanitizedSym = SanitizePathPart(symbolFullName);
            string symDir = Path.Combine(JournifiNTPaths.BarsDir, sanitizedSym);
            if (!Directory.Exists(symDir))
            {
                try { Directory.CreateDirectory(symDir); }
                catch (Exception ex)
                {
                    JournifiNTLog.Error("Bars",
                        $"Could not create symbol folder '{symDir}'", ex);
                    return 0;
                }
            }

            string filePath = Path.Combine(symDir, $"{monthKey}_{timeframe}.csv");

            lock (fileLock)
            {
                try
                {
                    // Merge existing + new by Unix timestamp, OVERWRITE on
                    // duplicate. When a bar transitions from in-progress to
                    // closed, the live-update callback re-emits it with final
                    // OHLC values; the existing in-progress row must yield to
                    // the closed version.
                    var byTime = new Dictionary<long, JournifiSyncNTBarRow>();

                    if (File.Exists(filePath))
                    {
                        foreach (var existing in ReadCsvBars(filePath))
                            byTime[existing.TimeUnix] = existing;
                    }

                    int newCount = 0;
                    int changedCount = 0;
                    foreach (var b in bars)
                    {
                        if (!byTime.TryGetValue(b.TimeUnix, out var existing))
                        {
                            newCount++;
                        }
                        else if (existing.Open != b.Open || existing.High != b.High ||
                                 existing.Low  != b.Low  || existing.Close != b.Close ||
                                 existing.Volume != b.Volume)
                        {
                            changedCount++;
                        }
                        byTime[b.TimeUnix] = b;
                    }

                    if (newCount == 0 && changedCount == 0) return 0;

                    var merged = byTime.Values.ToList();
                    merged.Sort((a, b) => a.TimeUnix.CompareTo(b.TimeUnix));

                    var sb = new StringBuilder(merged.Count * 64);
                    sb.Append("time,open,high,low,close,volume\n");
                    foreach (var b in merged)
                    {
                        sb.Append(b.TimeUnix).Append(',');
                        sb.Append(b.Open.ToString("R", CultureInfo.InvariantCulture)).Append(',');
                        sb.Append(b.High.ToString("R", CultureInfo.InvariantCulture)).Append(',');
                        sb.Append(b.Low.ToString("R", CultureInfo.InvariantCulture)).Append(',');
                        sb.Append(b.Close.ToString("R", CultureInfo.InvariantCulture)).Append(',');
                        sb.Append(b.Volume.ToString(CultureInfo.InvariantCulture)).Append('\n');
                    }

                    // v3.0.1 — durable atomic write via the shared chokepoint
                    // (was delete-then-Move, which could lose the whole month's
                    // bars on a crash mid-rename).
                    JournifiNTIO.AtomicWriteAllText(filePath, sb.ToString());

                    return newCount + changedCount;
                }
                catch (Exception ex)
                {
                    JournifiNTLog.Error("Bars", $"WriteMonthlyFile {filePath}", ex);
                    return 0;
                }
            }
        }

        /// <summary>
        /// Lightweight CSV reader for the headered format we write. Tolerates
        /// extra whitespace, ignores malformed rows. Intentionally NOT
        /// RFC-4180 — we own the writer too, so quoted commas / embedded
        /// newlines aren't an issue.
        /// </summary>
        private IEnumerable<JournifiSyncNTBarRow> ReadCsvBars(string filePath)
        {
            var rows = new List<JournifiSyncNTBarRow>();
            string[] lines;
            try { lines = File.ReadAllLines(filePath); }
            catch { return rows; }

            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                if (string.IsNullOrWhiteSpace(line)) continue;
                if (i == 0 && line.StartsWith("time,", StringComparison.OrdinalIgnoreCase)) continue;

                string[] parts = line.Split(',');
                if (parts.Length < 5) continue;

                if (!long.TryParse(parts[0].Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out long t)) continue;
                if (!double.TryParse(parts[1].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out double o)) continue;
                if (!double.TryParse(parts[2].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out double h)) continue;
                if (!double.TryParse(parts[3].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out double l)) continue;
                if (!double.TryParse(parts[4].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out double c)) continue;
                long v = 0;
                if (parts.Length >= 6) long.TryParse(parts[5].Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out v);

                rows.Add(new JournifiSyncNTBarRow { TimeUnix = t, Open = o, High = h, Low = l, Close = c, Volume = v });
            }
            return rows;
        }

        #endregion

        #region Status heartbeat

        private void WriteStatus()
        {
            try
            {
                var sb = new StringBuilder(512);
                sb.Append("{\n");
                sb.Append("  \"version\": \"").Append(JournifiSyncNT.VERSION).Append("\",\n");
                sb.Append("  \"isRunning\": ").Append(Stats.IsRunning ? "true" : "false").Append(",\n");
                sb.Append("  \"startedAt\": \"").Append(Stats.StartTime.ToString("o", CultureInfo.InvariantCulture)).Append("\",\n");
                sb.Append("  \"lastWriteAt\": ");
                if (lastWriteAt == DateTime.MinValue) sb.Append("null");
                else sb.Append('"').Append(lastWriteAt.ToString("o", CultureInfo.InvariantCulture)).Append('"');
                sb.Append(",\n");
                // "Feed alive" signal — moves on every NT update fire, even
                // when no bytes change on disk. Lets the journal side tell
                // "NT is streaming, no new bars" apart from "NT is silent."
                sb.Append("  \"lastUpdateFireAt\": ");
                if (lastUpdateFireAt == DateTime.MinValue) sb.Append("null");
                else sb.Append('"').Append(lastUpdateFireAt.ToString("o", CultureInfo.InvariantCulture)).Append('"');
                sb.Append(",\n");
                sb.Append("  \"barsWrittenSinceStart\": ").Append(barsWrittenSinceStart).Append(",\n");
                // Per-symbol last-write — surfaces which specific watched
                // symbol is lagging when one feed stalls but others keep
                // writing. Useful for the "trade MNQ but watching ES" config
                // mismatch where the global lastWriteAt looks healthy but the
                // user's actually-trading symbol hasn't been touched.
                sb.Append("  \"lastWritePerSymbol\": {");
                bool firstSym = true;
                foreach (var kvp in lastWritePerSymbol)
                {
                    if (!firstSym) sb.Append(", ");
                    sb.Append('"').Append(JsonEscape(kvp.Key)).Append("\": \"");
                    sb.Append(kvp.Value.ToString("o", CultureInfo.InvariantCulture)).Append('"');
                    firstSym = false;
                }
                sb.Append("},\n");
                // v3.1+ — self-heal sweep telemetry. Lets the JournifiAI
                // side surface "addon is healing N gaps per sweep" insight
                // and warn when the sweep itself is silent for too long.
                sb.Append("  \"selfHeal\": {\n");
                sb.Append("    \"enabled\": ").Append(SelfHealEnabled ? "true" : "false").Append(",\n");
                sb.Append("    \"intervalMinutes\": ").Append(BarsSettings?.SelfHealIntervalMinutes ?? 0).Append(",\n");
                sb.Append("    \"lookbackMinutes\": ").Append(BarsSettings?.SelfHealLookbackMinutes ?? 0).Append(",\n");
                sb.Append("    \"lastSweepAt\": ");
                if (lastSelfHealAt == DateTime.MinValue) sb.Append("null");
                else sb.Append('"').Append(lastSelfHealAt.ToString("o", CultureInfo.InvariantCulture)).Append('"');
                sb.Append(",\n");
                sb.Append("    \"runsTotal\": ").Append(selfHealRunsTotal).Append(",\n");
                sb.Append("    \"barsFilled\": ").Append(selfHealBarsFilled).Append(",\n");
                sb.Append("    \"barsRevised\": ").Append(selfHealBarsRevised).Append("\n");
                sb.Append("  },\n");
                sb.Append("  \"subscribeOneMinuteOnly\": ").Append(BarsSettings?.SubscribeOneMinuteOnly == true ? "true" : "false").Append(",\n");
                // v3.0.4+ — execution-driven auto-roll visibility.
                sb.Append("  \"autoRoll\": {\n");
                sb.Append("    \"enabled\": ").Append(BarsSettings?.AutoRollContracts == true ? "true" : "false").Append(",\n");
                sb.Append("    \"contracts\": [");
                var autoSnapshot = AutoManagedContractsSnapshot;
                for (int i = 0; i < autoSnapshot.Count; i++)
                {
                    if (i > 0) sb.Append(", ");
                    sb.Append('"').Append(JsonEscape(autoSnapshot[i])).Append('"');
                }
                sb.Append("]\n");
                sb.Append("  },\n");
                sb.Append("  \"watchedSymbols\": [");
                var watched = BarsSettings?.WatchedSymbols;
                if (watched != null)
                {
                    for (int i = 0; i < watched.Count; i++)
                    {
                        if (i > 0) sb.Append(", ");
                        sb.Append('"').Append(JsonEscape(watched[i].Symbol)).Append('"');
                    }
                }
                sb.Append("]\n");
                sb.Append("}\n");

                lock (fileLock)
                {
                    File.WriteAllText(JournifiNTPaths.BarsStatusPath, sb.ToString());
                }
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("Bars", $"WriteStatus failed: {ex.Message}");
            }
        }

        #endregion

        #region Helpers

        private static BarsPeriod ParseTimeframe(string tf)
        {
            if (string.IsNullOrWhiteSpace(tf)) return null;
            // NT8's BarsPeriodType has no native "Hour" — hourly bars are
            // expressed as Minute with the appropriate multiplier (60, 240).
            switch (tf.Trim().ToLowerInvariant())
            {
                case "1m":   return new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, Value = 1 };
                case "5m":   return new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, Value = 5 };
                case "15m":  return new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, Value = 15 };
                case "1h":   return new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, Value = 60 };
                case "60m":  return new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, Value = 60 };
                case "4h":   return new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, Value = 240 };
                case "240m": return new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, Value = 240 };
                default:     return null;
            }
        }

        /// <summary>
        /// Convert NT's bar timestamp to Unix seconds. NT's GetTime returns
        /// a DateTime in NT's configured local timezone with Kind=Unspecified;
        /// we treat as Local. The journal-side parser re-anchors on read.
        /// </summary>
        private static long ToUnixSeconds(DateTime dt)
        {
            try
            {
                if (dt.Kind == DateTimeKind.Unspecified)
                    dt = DateTime.SpecifyKind(dt, DateTimeKind.Local);
                return ((DateTimeOffset)dt).ToUnixTimeSeconds();
            }
            catch
            {
                return ((DateTimeOffset)DateTime.SpecifyKind(dt, DateTimeKind.Utc)).ToUnixTimeSeconds();
            }
        }

        private static string SanitizePathPart(string s)
        {
            if (string.IsNullOrEmpty(s)) return "_";
            var bad = Path.GetInvalidFileNameChars();
            var sb = new StringBuilder(s.Length);
            foreach (char c in s)
                sb.Append(Array.IndexOf(bad, c) >= 0 ? '_' : c);
            return sb.ToString().Trim();
        }

        private static string JsonEscape(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("\\", "\\\\").Replace("\"", "\\\"");
        }

        private static void SafeExecute(Action action)
        {
            try { action(); }
            catch (Exception ex) { JournifiNTLog.Error("Bars", "SafeExecute caught", ex); }
        }

        #endregion
    }

    #endregion

    #region Data classes

    /// <summary>
    /// One row of OHLCV bar data. Time is Unix seconds (UTC anchor) so the
    /// journal-side parser can interpret without timezone ambiguity.
    /// Schema identical to v1.1.1's BarRow — renamed only to avoid the
    /// type-name collision while v1 is still installed.
    /// </summary>
    public class JournifiSyncNTBarRow
    {
        public long TimeUnix { get; set; }
        public double Open { get; set; }
        public double High { get; set; }
        public double Low { get; set; }
        public double Close { get; set; }
        public long Volume { get; set; }
    }

    public class JournifiSyncNTBarsStats
    {
        public bool IsRunning { get; set; }
        public DateTime StartTime { get; set; }
    }

    #endregion
}
