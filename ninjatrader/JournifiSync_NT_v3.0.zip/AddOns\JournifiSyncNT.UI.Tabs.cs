#region Using declarations
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Xml.Linq;
using NinjaTrader.Core;
using NinjaTrader.Gui;
using NinjaTrader.Gui.NinjaScript;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.Gui.NinjaScript
{
    // =====================================================================
    //  UI shell for JournifiSync NT
    // =====================================================================
    //
    //  • JournifiSyncNTTheme       — shared color palette (dark)
    //  • JournifiSyncNTMenu        — Control Center → New menu entry
    //  • JournifiSyncNTWindow      — NTWindow + IWorkspacePersistence
    //  • JournifiSyncNTWindowFactory — INTTabFactory (workspace restore)
    //  • JournifiSyncNTTabBase     — abstract base with placeholder render
    //  • DashboardTab / SyncTab / BarsTab / MappingsTab / AboutTab
    //
    //  Phase 3 wires the window and tabs. Each tab is a placeholder showing
    //  what content will land here. Real implementations arrive in Phases
    //  4-9 (modules + tabs) and each phase swaps out one tab's body.

    #region Theme

    /// <summary>
    /// Color palette shared by every tab. Mirrors the palette JournifiSync
    /// v2.0.1 and JournifiBars v1.1.1 each maintained locally (and which
    /// had drifted between them — unifying it here is one of the small
    /// quality-of-life wins from the merge).
    /// </summary>
    internal static class JournifiSyncNTTheme
    {
        public static readonly Color ColorBackground = Color.FromRgb(27, 29, 31);
        public static readonly Color ColorCard = Color.FromRgb(39, 41, 44);
        public static readonly Color ColorSurface = Color.FromRgb(33, 35, 38);
        public static readonly Color ColorBorder = Color.FromRgb(58, 62, 66);
        public static readonly Color ColorAccent = Color.FromRgb(14, 165, 233);    // sky-500
        public static readonly Color ColorAccentGreen = Color.FromRgb(34, 197, 94); // emerald-500
        public static readonly Color ColorAccentRed = Color.FromRgb(239, 68, 68);   // red-500
        public static readonly Color ColorTextPrimary = Color.FromRgb(240, 242, 245);
        public static readonly Color ColorTextSecondary = Color.FromRgb(176, 182, 188);
        public static readonly Color ColorTextMuted = Color.FromRgb(120, 126, 132);
    }

    #endregion

    #region Menu integration

    /// <summary>
    /// Adds a single "JournifiSync NT" entry to Control Center → New.
    /// Identity-by-header-text and separator tracking carried forward from
    /// JournifiBars v1.1.0's hardened pattern (clean recompile, no leftover
    /// menu items, no orphan separators).
    /// </summary>
    public class JournifiSyncNTMenu : AddOnBase
    {
        // Visible label AND the identity key used by stale-entry cleanup —
        // a recompiled MenuItem object's .Equals() to the prior one fails,
        // but the .Header text still matches.
        private const string MENU_ITEM_HEADER = "JournifiSync NT";

        private NTMenuItem journifiMenuItem;
        private NTMenuItem newMenuRoot;
        private Separator journifiSeparator;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "JournifiSync NT — Control Center menu entry";
                Name = "JournifiSyncNTMenu";
            }
        }

        protected override void OnWindowCreated(Window window)
        {
            var cc = window as ControlCenter;
            if (cc == null) return;

            newMenuRoot = cc.FindFirst("ControlCenterMenuItemNew") as NTMenuItem;
            if (newMenuRoot == null) return;

            // Sweep any leftover entries from previous compile cycles before
            // adding fresh ones. Match by .Header text (cross-assembly safe).
            CleanupStaleEntries();

            journifiSeparator = new Separator();
            newMenuRoot.Items.Add(journifiSeparator);

            journifiMenuItem = new NTMenuItem
            {
                Header = MENU_ITEM_HEADER,
                Style = Application.Current.TryFindResource("MainMenuItem") as Style
            };
            newMenuRoot.Items.Add(journifiMenuItem);
            journifiMenuItem.Click += OnMenuItemClick;
        }

        protected override void OnWindowDestroyed(Window window)
        {
            if (!(window is ControlCenter) || newMenuRoot == null) return;

            if (journifiMenuItem != null && newMenuRoot.Items.Contains(journifiMenuItem))
                newMenuRoot.Items.Remove(journifiMenuItem);
            if (journifiSeparator != null && newMenuRoot.Items.Contains(journifiSeparator))
                newMenuRoot.Items.Remove(journifiSeparator);

            if (journifiMenuItem != null) journifiMenuItem.Click -= OnMenuItemClick;
            journifiMenuItem = null;
            journifiSeparator = null;
        }

        private void CleanupStaleEntries()
        {
            if (newMenuRoot == null) return;
            var items = newMenuRoot.Items;

            var toRemove = new List<int>();
            for (int i = 0; i < items.Count; i++)
            {
                var mi = items[i] as System.Windows.Controls.MenuItem;
                if (mi == null) continue;
                if ((mi.Header as string) != MENU_ITEM_HEADER) continue;

                toRemove.Add(i);
                if (i > 0 && items[i - 1] is Separator)
                    toRemove.Add(i - 1);
            }
            foreach (var idx in toRemove.OrderByDescending(x => x))
            {
                try { items.RemoveAt(idx); } catch { /* best-effort */ }
            }
        }

        private void OnMenuItemClick(object sender, RoutedEventArgs e)
        {
            try { JournifiSyncNTWindow.ShowWindow(); }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening JournifiSync NT: {ex.Message}",
                    "JournifiSync NT", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }

    #endregion

    #region Window

    /// <summary>
    /// JournifiSync NT settings window. Five tabs:
    ///   1. Dashboard  — combined stats card (Sync + Bars side by side)
    ///   2. Sync       — exec capture settings + account list
    ///   3. Bars       — watched symbols + dropdown picker
    ///   4. Mappings   — NT account → Journifi accountId
    ///   5. About      — version, paths, manual resync, folder shortcuts
    ///
    /// IWorkspacePersistence + GUID WorkspaceOptions copied verbatim from
    /// JournifiBars v1.1.0 (which copied from JournifiSync v2.0.1) — that
    /// pattern is proven against the NT recompile + workspace-restore loop.
    /// </summary>
    public class JournifiSyncNTWindow : NTWindow, IWorkspacePersistence
    {
        private static JournifiSyncNTWindow currentInstance;
        public static bool IsWindowOpen => currentInstance != null;

        public JournifiSyncNTWindow()
        {
            JournifiNTLog.Info("Window", "Creating new JournifiSyncNTWindow");
            Caption = "JournifiSync NT";
            Width = 760;
            Height = 620;

            currentInstance = this;
            this.Closing += (s, e) =>
            {
                JournifiNTLog.Info("Window", "Window closing");
                currentInstance = null;
            };

            var tabControl = new TabControl
            {
                Style = Application.Current.TryFindResource("MainTabControlStyle") as Style
            };
            TabControlManager.SetIsMovable(tabControl, false);
            TabControlManager.SetCanAddTabs(tabControl, false);
            TabControlManager.SetCanRemoveTabs(tabControl, false);
            TabControlManager.SetFactory(tabControl, new JournifiSyncNTWindowFactory());

            // Order matters — this is the left-to-right tab order.
            tabControl.AddNTTabPage(new DashboardTab());
            tabControl.AddNTTabPage(new SyncTab());
            tabControl.AddNTTabPage(new BarsTab());
            tabControl.AddNTTabPage(new MappingsTab());
            tabControl.AddNTTabPage(new AboutTab());

            Content = tabControl;

            Loaded += (o, e) =>
            {
                if (WorkspaceOptions == null)
                    WorkspaceOptions = new WorkspaceOptions(
                        "JournifiSyncNT-" + Guid.NewGuid().ToString("N"), this);
            };
        }

        public void Restore(XDocument document, XElement element)
        {
            if (MainTabControl != null) MainTabControl.RestoreFromXElement(element);
        }

        public void Save(XDocument document, XElement element)
        {
            if (MainTabControl != null) MainTabControl.SaveToXElement(element);
        }

        public WorkspaceOptions WorkspaceOptions { get; set; }

        private static List<Window> FindAllInstances()
        {
            try
            {
                if (Application.Current == null) return new List<Window>();
                return Application.Current.Windows
                    .OfType<Window>()
                    .Where(w => w.GetType().Name == nameof(JournifiSyncNTWindow))
                    .ToList();
            }
            catch { return new List<Window>(); }
        }

        public static void ShowWindow()
        {
            var existing = FindAllInstances();
            JournifiNTLog.Info("Window", $"ShowWindow: found {existing.Count} existing instance(s)");

            if (existing.Count > 0)
            {
                var keep = existing[0];
                for (int i = 1; i < existing.Count; i++)
                {
                    try { existing[i].Close(); } catch { }
                }
                keep.Activate();
                try { currentInstance = keep as JournifiSyncNTWindow; } catch { }
                return;
            }

            JournifiNTLog.Info("Window", "ShowWindow: creating new window");
            Core.Globals.RandomDispatcher.BeginInvoke(new Action(() =>
            {
                new JournifiSyncNTWindow().Show();
            }));
        }
    }

    /// <summary>
    /// Workspace-restore factory. NT calls <see cref="CreateTabPage"/> with
    /// the saved tab's type name; we map back to the concrete NTTabPage.
    /// Unknown type names fall back to the Dashboard tab so a malformed
    /// workspace XML never breaks restore.
    /// </summary>
    public class JournifiSyncNTWindowFactory : INTTabFactory
    {
        public NTWindow CreateParentWindow() => new JournifiSyncNTWindow();

        public NTTabPage CreateTabPage(string typeName, bool isTrue)
        {
            // typeName is the C# class name NT serialized during Save.
            // OrdinalIgnoreCase guards against capitalization drift across
            // NT versions.
            if (typeName != null)
            {
                if (typeName.Equals(nameof(DashboardTab), StringComparison.OrdinalIgnoreCase)) return new DashboardTab();
                if (typeName.Equals(nameof(SyncTab), StringComparison.OrdinalIgnoreCase)) return new SyncTab();
                if (typeName.Equals(nameof(BarsTab), StringComparison.OrdinalIgnoreCase)) return new BarsTab();
                if (typeName.Equals(nameof(MappingsTab), StringComparison.OrdinalIgnoreCase)) return new MappingsTab();
                if (typeName.Equals(nameof(AboutTab), StringComparison.OrdinalIgnoreCase)) return new AboutTab();
            }
            return new DashboardTab();
        }
    }

    #endregion

    #region Tab base class

    /// <summary>
    /// Common base for v3's tab pages. Handles the boilerplate NTTabPage
    /// overrides + a shared "placeholder body" renderer so each concrete
    /// tab just declares its header text, phase-tracker text, and a
    /// description of what's coming. Real implementations override
    /// <see cref="BuildContent"/> in their respective phase.
    /// </summary>
    public abstract class JournifiSyncNTTabBase : NTTabPage
    {
        /// <summary>The label NT shows on the tab itself.</summary>
        protected abstract string HeaderLabel { get; }

        /// <summary>Phase identifier in the placeholder card (e.g. "Phase 6").</summary>
        protected virtual string PlaceholderPhase => "(future phase)";

        /// <summary>One-paragraph description shown in the placeholder card.</summary>
        protected virtual string PlaceholderDescription => "";

        protected JournifiSyncNTTabBase()
        {
            TabName = HeaderLabel;
            Content = BuildContent();
        }

        /// <summary>
        /// Renders the tab body. Default impl is the placeholder card —
        /// subclasses override once their phase ships real UI.
        /// </summary>
        protected virtual FrameworkElement BuildContent()
        {
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorBackground)
            };

            var outer = new StackPanel
            {
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorBackground),
                Margin = new Thickness(24, 24, 24, 24)
            };

            // Header strip — section name + phase pill
            var header = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 12) };
            header.Children.Add(new TextBlock
            {
                Text = HeaderLabel,
                FontSize = 22,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                VerticalAlignment = VerticalAlignment.Center
            });
            var phaseBorder = new Border
            {
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorSurface),
                BorderBrush = new SolidColorBrush(JournifiSyncNTTheme.ColorBorder),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(10),
                Padding = new Thickness(10, 2, 10, 2),
                Margin = new Thickness(12, 4, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            phaseBorder.Child = new TextBlock
            {
                Text = PlaceholderPhase,
                FontSize = 10,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary)
            };
            header.Children.Add(phaseBorder);
            outer.Children.Add(header);

            // Placeholder card
            var card = new Border
            {
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorCard),
                BorderBrush = new SolidColorBrush(JournifiSyncNTTheme.ColorBorder),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(6),
                Padding = new Thickness(20, 16, 20, 20)
            };
            var cardStack = new StackPanel();
            cardStack.Children.Add(new TextBlock
            {
                Text = "Placeholder — content lands in a later phase",
                FontSize = 11,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                Margin = new Thickness(0, 0, 0, 8)
            });
            cardStack.Children.Add(new TextBlock
            {
                Text = string.IsNullOrWhiteSpace(PlaceholderDescription)
                    ? "(Description coming when this phase lands.)"
                    : PlaceholderDescription,
                FontSize = 13,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                TextWrapping = TextWrapping.Wrap,
                LineHeight = 20
            });
            card.Child = cardStack;
            outer.Children.Add(card);

            // Version footer
            outer.Children.Add(new TextBlock
            {
                Text = $"JournifiSync NT v{JournifiSyncNT.VERSION}  ·  data root: {JournifiNTPaths.NT8DataRoot}",
                FontSize = 10,
                FontStyle = FontStyles.Italic,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted),
                Margin = new Thickness(0, 16, 0, 0)
            });

            scroll.Content = outer;
            return scroll;
        }

        protected override string GetHeaderPart(string variable) => HeaderLabel;
        protected override void Restore(XElement element) { }
        protected override void Save(XElement element) { }
    }

    #endregion

    #region Tab implementations (placeholders for now)

    /// <summary>
    /// Live status dashboard — two side-by-side cards, one per module, with
    /// 2-second auto-refresh. Reads state through
    /// <see cref="JournifiSyncNTBridge"/> so the dashboard keeps showing live
    /// data even when the window survives an NT NinjaScript recompile.
    /// </summary>
    public class DashboardTab : JournifiSyncNTTabBase
    {
        protected override string HeaderLabel => "Dashboard";

        private DispatcherTimer refreshTimer;

        // Sync card refs (updated by RefreshUI every 2s)
        private Ellipse syncStatusDot;
        private TextBlock syncStatusText;
        private TextBlock syncExecutionsText;
        private TextBlock syncExportsText;
        private TextBlock syncLastExecText;
        private TextBlock syncLastExportText;
        private TextBlock syncCacheText;
        private TextBlock syncAccountsText;

        // Bars card refs
        private Ellipse barsStatusDot;
        private TextBlock barsStatusText;
        private TextBlock barsWrittenText;
        private TextBlock barsLastWriteText;
        private TextBlock barsLastUpdateText;
        private TextBlock barsFeedsText;
        private TextBlock barsWatchedText;

        // JournifiAI heartbeat pill refs (in the header strip)
        private Ellipse journifiAIStatusDot;
        private TextBlock journifiAIStatusText;

        // Footer refs
        private TextBlock footerText;

        protected override FrameworkElement BuildContent()
        {
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorBackground)
            };

            var outer = new StackPanel
            {
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorBackground),
                Margin = new Thickness(24, 20, 24, 20)
            };

            outer.Children.Add(BuildHeader());
            outer.Children.Add(BuildModulesGrid());
            outer.Children.Add(BuildFooter());
            scroll.Content = outer;

            StartRefreshTimer();
            this.Unloaded += OnTabUnloaded;

            return scroll;
        }

        public override void Cleanup()
        {
            // NOTE: Do NOT stop refreshTimer here — JournifiSync v2.0.1 / v1.1.1
            // learned this the hard way. During an NT NinjaScript recompile, NT
            // calls Cleanup() on old-assembly tabs while the window stays open.
            // The timer keeps running so RefreshUI() picks up the new assembly's
            // Instance on its next tick. Teardown happens in OnTabUnloaded on
            // real window close.
            base.Cleanup();
        }

        private void OnTabUnloaded(object sender, RoutedEventArgs e)
        {
            refreshTimer?.Stop();
            refreshTimer = null;
            this.Unloaded -= OnTabUnloaded;
        }

        #region UI construction

        private FrameworkElement BuildHeader()
        {
            // Three-column layout: [Dashboard + version pill] [spacer] [JournifiAI status pill, right-aligned]
            var grid = new Grid { Margin = new Thickness(0, 0, 0, 14) };
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            // Left: title + version pill
            var leftStack = new StackPanel { Orientation = Orientation.Horizontal };
            leftStack.Children.Add(new TextBlock
            {
                Text = "Dashboard",
                FontSize = 22,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                VerticalAlignment = VerticalAlignment.Center
            });
            leftStack.Children.Add(BuildPill($"v{JournifiSyncNT.VERSION}", JournifiSyncNTTheme.ColorTextSecondary));
            Grid.SetColumn(leftStack, 0);
            grid.Children.Add(leftStack);

            // Right: Journifi AI connection status pill, with live dot
            var rightPill = new Border
            {
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorSurface),
                BorderBrush = new SolidColorBrush(JournifiSyncNTTheme.ColorBorder),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(10),
                Padding = new Thickness(10, 4, 12, 4),
                VerticalAlignment = VerticalAlignment.Center
            };
            var rightRow = new StackPanel { Orientation = Orientation.Horizontal };
            journifiAIStatusDot = new Ellipse
            {
                Width = 8,
                Height = 8,
                Fill = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted),
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 6, 0)
            };
            rightRow.Children.Add(journifiAIStatusDot);
            journifiAIStatusText = new TextBlock
            {
                Text = "Journifi AI — ?",
                FontSize = 10,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                VerticalAlignment = VerticalAlignment.Center
            };
            rightRow.Children.Add(journifiAIStatusText);
            rightPill.Child = rightRow;
            Grid.SetColumn(rightPill, 2);
            grid.Children.Add(rightPill);

            return grid;
        }

        private FrameworkElement BuildModulesGrid()
        {
            // Two-column grid: Sync on left, Bars on right. SharedSizeGroup
            // would balance heights but isn't reliable when one card has
            // wrapping text and the other doesn't; rely on auto sizing.
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(12) }); // gutter
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            var syncCard = BuildSyncCard();
            Grid.SetColumn(syncCard, 0);
            grid.Children.Add(syncCard);

            var barsCard = BuildBarsCard();
            Grid.SetColumn(barsCard, 2);
            grid.Children.Add(barsCard);

            return grid;
        }

        private Border BuildSyncCard()
        {
            var card = MakeCard();
            var stack = new StackPanel();

            // Header row: dot + name + status
            var headerRow = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 12) };
            syncStatusDot = MakeStatusDot();
            headerRow.Children.Add(syncStatusDot);
            headerRow.Children.Add(new TextBlock
            {
                Text = "Sync",
                FontSize = 16,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                Margin = new Thickness(8, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            });
            syncStatusText = new TextBlock
            {
                Text = "—",
                FontSize = 10,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                Margin = new Thickness(10, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            headerRow.Children.Add(syncStatusText);
            stack.Children.Add(headerRow);

            // Stat rows
            syncExecutionsText = AddStatRow(stack, "Executions captured");
            syncExportsText    = AddStatRow(stack, "Exports written");
            syncLastExecText   = AddStatRow(stack, "Last execution");
            syncLastExportText = AddStatRow(stack, "Last export");
            syncCacheText      = AddStatRow(stack, "ATM cache hit rate");
            syncAccountsText   = AddStatRow(stack, "Connected accounts");

            card.Child = stack;
            return card;
        }

        private Border BuildBarsCard()
        {
            var card = MakeCard();
            var stack = new StackPanel();

            var headerRow = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 12) };
            barsStatusDot = MakeStatusDot();
            headerRow.Children.Add(barsStatusDot);
            headerRow.Children.Add(new TextBlock
            {
                Text = "Bars",
                FontSize = 16,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                Margin = new Thickness(8, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            });
            barsStatusText = new TextBlock
            {
                Text = "—",
                FontSize = 10,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                Margin = new Thickness(10, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            headerRow.Children.Add(barsStatusText);
            stack.Children.Add(headerRow);

            barsWrittenText    = AddStatRow(stack, "Bars written (session)");
            barsLastWriteText  = AddStatRow(stack, "Last write");
            // "Last update" — fires on every NT BarsUpdate event for ANY
            // watched symbol/timeframe, even in-progress ticks. Lets the user
            // tell "NT is streaming, just no new closed bars yet" apart from
            // "feed died." Without this, a long quiet stretch on the watched
            // timeframe makes "Last write" read 1h+ stale on a perfectly
            // healthy connection.
            barsLastUpdateText = AddStatRow(stack, "Last update");
            barsFeedsText      = AddStatRow(stack, "Connected feeds");
            barsWatchedText    = AddStatRow(stack, "Watched symbols");

            card.Child = stack;
            return card;
        }

        private FrameworkElement BuildFooter()
        {
            footerText = new TextBlock
            {
                Text = "",  // populated by RefreshUI on first tick
                FontSize = 10,
                FontStyle = FontStyles.Italic,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted),
                Margin = new Thickness(0, 16, 0, 0),
                TextWrapping = TextWrapping.Wrap
            };
            return footerText;
        }

        // Small primitives used by the cards.
        private static Border MakeCard()
        {
            return new Border
            {
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorCard),
                BorderBrush = new SolidColorBrush(JournifiSyncNTTheme.ColorBorder),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(6),
                Padding = new Thickness(14, 12, 14, 14),
                VerticalAlignment = VerticalAlignment.Top
            };
        }

        private static Ellipse MakeStatusDot()
        {
            return new Ellipse
            {
                Width = 10,
                Height = 10,
                Fill = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted),
                VerticalAlignment = VerticalAlignment.Center
            };
        }

        /// <summary>
        /// Append a label/value row to a card body stack and return the value
        /// TextBlock so RefreshUI can mutate it without a back-reference dance.
        /// </summary>
        private static TextBlock AddStatRow(StackPanel parent, string label)
        {
            var row = new Grid { Margin = new Thickness(0, 0, 0, 6) };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var labelBlock = new TextBlock
            {
                Text = label,
                FontSize = 11,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(labelBlock, 0);
            row.Children.Add(labelBlock);

            var valueBlock = new TextBlock
            {
                Text = "—",
                FontSize = 13,
                FontFamily = new FontFamily("Consolas, Courier New, monospace"),
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Right,
                TextAlignment = TextAlignment.Right
            };
            Grid.SetColumn(valueBlock, 1);
            row.Children.Add(valueBlock);

            parent.Children.Add(row);
            return valueBlock;
        }

        private static Border BuildPill(string text, Color foreground)
        {
            return new Border
            {
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorSurface),
                BorderBrush = new SolidColorBrush(JournifiSyncNTTheme.ColorBorder),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(10),
                Padding = new Thickness(10, 2, 10, 2),
                Margin = new Thickness(12, 4, 0, 0),
                VerticalAlignment = VerticalAlignment.Center,
                Child = new TextBlock
                {
                    Text = text,
                    FontSize = 10,
                    Foreground = new SolidColorBrush(foreground)
                }
            };
        }

        #endregion

        #region Refresh

        private void StartRefreshTimer()
        {
            refreshTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
            refreshTimer.Tick += (s, e) => RefreshUI();
            refreshTimer.Start();
            RefreshUI();  // first paint immediately, don't wait for the 2s tick
        }

        /// <summary>
        /// Re-read module state and update the cards. Routes through the
        /// cross-assembly Bridge so the dashboard rebinds automatically
        /// after an NT recompile.
        /// </summary>
        private void RefreshUI()
        {
            try
            {
                UpdateSyncCard(JournifiSyncNTBridge.Sync);
                UpdateBarsCard(JournifiSyncNTBridge.Bars);
                UpdateJournifiAICard();
                UpdateFooter();
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("Dashboard", $"RefreshUI: {ex.Message}");
            }
        }

        // Parameter is dynamic so DLR resolves Stats / GetConnectedAccounts /
        // GetMonitoredAccounts even when 'sync' is a cross-assembly type.
        private void UpdateSyncCard(dynamic sync)
        {
            if (sync == null)
            {
                SetDot(syncStatusDot, JournifiSyncNTTheme.ColorTextMuted);
                syncStatusText.Text = "(loading)";
                syncExecutionsText.Text = "—";
                syncExportsText.Text = "—";
                syncLastExecText.Text = "—";
                syncLastExportText.Text = "—";
                syncCacheText.Text = "—";
                syncAccountsText.Text = "—";
                return;
            }

            // Each property read through 'sync' (dynamic) is DLR-resolved at
            // runtime so cross-assembly calls work transparently. The
            // assignments to typed locals trigger an implicit dynamic→T
            // conversion, also via DLR.
            bool running = (bool)sync.Stats.IsRunning;
            SetDot(syncStatusDot, running
                ? JournifiSyncNTTheme.ColorAccentGreen
                : JournifiSyncNTTheme.ColorAccentRed);
            syncStatusText.Text = running ? "Running" : "Stopped";

            int execCount = (int)sync.Stats.ExecutionCount;
            int exportCount = (int)sync.Stats.ExportCount;
            DateTime lastExec = (DateTime)sync.Stats.LastExecutionTime;
            DateTime lastExport = (DateTime)sync.Stats.LastExportTime;
            int hits = (int)sync.Stats.AtmCacheHits;
            int misses = (int)sync.Stats.AtmCacheMisses;

            syncExecutionsText.Text = execCount.ToString();
            syncExportsText.Text    = exportCount.ToString();
            syncLastExecText.Text   = FormatRelativeOrNever(lastExec);
            syncLastExportText.Text = FormatRelativeOrNever(lastExport);

            int total = hits + misses;
            if (total == 0) syncCacheText.Text = "—";
            else
            {
                double rate = (double)sync.Stats.CacheHitRate;
                syncCacheText.Text = $"{rate:F1}%  ({hits}/{total})";
            }

            try
            {
                // Materialize the dynamic IEnumerables into typed Lists so
                // we can use LINQ (Take/Count) reliably — DLR doesn't dispatch
                // to extension methods on dynamic receivers.
                var connected = new List<string>();
                var dConnected = sync.GetConnectedAccounts();
                if (dConnected != null)
                    foreach (string s in dConnected) connected.Add(s);

                var monitored = new List<string>();
                var dMonitored = sync.GetMonitoredAccounts();
                if (dMonitored != null)
                    foreach (string s in dMonitored) monitored.Add(s);

                syncAccountsText.Text = monitored.Count == 0
                    ? "(none)"
                    : $"{connected.Count}/{monitored.Count}  {(connected.Count > 0 ? string.Join(", ", connected.Take(3)) : "")}".TrimEnd();
            }
            catch
            {
                syncAccountsText.Text = "—";
            }
        }

        private void UpdateBarsCard(dynamic bars)
        {
            if (bars == null)
            {
                SetDot(barsStatusDot, JournifiSyncNTTheme.ColorTextMuted);
                barsStatusText.Text = "(loading)";
                barsWrittenText.Text = "—";
                barsLastWriteText.Text = "—";
                barsLastUpdateText.Text = "—";
                barsFeedsText.Text = "—";
                barsWatchedText.Text = "—";
                return;
            }

            bool running = (bool)bars.Stats.IsRunning;
            SetDot(barsStatusDot, running
                ? JournifiSyncNTTheme.ColorAccentGreen
                : JournifiSyncNTTheme.ColorAccentRed);
            barsStatusText.Text = running ? "Running" : "Stopped";

            long written = (long)bars.BarsWrittenSinceStart;
            DateTime lastWrite = (DateTime)bars.LastWriteAt;
            DateTime lastUpdate = (DateTime)bars.LastUpdateFireAt;
            barsWrittenText.Text    = written.ToString();
            barsLastWriteText.Text  = FormatRelativeOrNever(lastWrite);
            barsLastUpdateText.Text = FormatRelativeOrNever(lastUpdate);

            // Tooltip diagnostic — explains the distinction. Without this,
            // a "Last write 1h ago" beside "Last update 12s ago" looks weird;
            // with it, the user knows what they're looking at.
            barsLastWriteText.ToolTip  = "Last time a NEW or CHANGED bar was written to disk. " +
                                         "Doesn't move if NT keeps firing updates with bars that already match disk.";
            barsLastUpdateText.ToolTip = "Last time NinjaTrader fired ANY bar update for a watched symbol. " +
                                         "This is the 'feed alive' signal — even in-progress ticks count.";

            try
            {
                var feeds = new List<string>();
                var dFeeds = bars.ConnectedFeedNames;
                if (dFeeds != null)
                    foreach (string s in dFeeds) feeds.Add(s);
                barsFeedsText.Text = feeds.Count == 0
                    ? "(none)"
                    : string.Join(", ", feeds);
            }
            catch
            {
                barsFeedsText.Text = "—";
            }

            try
            {
                int watched = 0;
                var dWatched = bars.GetWatchedSymbolsSnapshot();
                if (dWatched != null)
                    foreach (var _ in dWatched) watched++;
                barsWatchedText.Text = watched.ToString();
            }
            catch
            {
                barsWatchedText.Text = "—";
            }
        }

        /// <summary>
        /// Update the Journifi AI connection pill on the header strip.
        /// Reads the heartbeat file the desktop app writes (every few seconds)
        /// to <c>JournifiSync\journifi_heartbeat.json</c>. Fresh heartbeat →
        /// green dot + version; stale or absent → red dot + "offline".
        /// </summary>
        private void UpdateJournifiAICard()
        {
            if (journifiAIStatusDot == null || journifiAIStatusText == null) return;
            try
            {
                var hb = JournifiAIHeartbeatReader.Read();
                if (!hb.Found)
                {
                    SetDot(journifiAIStatusDot, JournifiSyncNTTheme.ColorTextMuted);
                    journifiAIStatusText.Text = "Journifi AI — not detected";
                    return;
                }
                if (hb.Fresh)
                {
                    SetDot(journifiAIStatusDot, JournifiSyncNTTheme.ColorAccentGreen);
                    journifiAIStatusText.Text = string.IsNullOrEmpty(hb.Version)
                        ? "Journifi AI — connected"
                        : $"Journifi AI — connected · v{hb.Version}";
                }
                else
                {
                    SetDot(journifiAIStatusDot, JournifiSyncNTTheme.ColorAccentRed);
                    int secs = (int)hb.Age.TotalSeconds;
                    journifiAIStatusText.Text = $"Journifi AI — stale ({secs}s)";
                }
            }
            catch
            {
                SetDot(journifiAIStatusDot, JournifiSyncNTTheme.ColorTextMuted);
                journifiAIStatusText.Text = "Journifi AI — ?";
            }
        }

        private void UpdateFooter()
        {
            if (footerText == null) return;
            footerText.Text =
                $"Data root: {JournifiNTPaths.NT8DataRoot}  ·  " +
                $"Settings: {JournifiNTPaths.SettingsPath}  ·  " +
                $"Log: {JournifiNTPaths.LogPath}";
        }

        private static void SetDot(Ellipse dot, Color color)
        {
            if (dot == null) return;
            dot.Fill = new SolidColorBrush(color);
        }

        /// <summary>
        /// Render a timestamp as "12s ago" / "3m ago" / "1h ago" or "never"
        /// for the MinValue sentinel. Mirrors v1.1.1's UI convention so
        /// users get the same readout in the merged dashboard.
        /// </summary>
        private static string FormatRelativeOrNever(DateTime t)
        {
            if (t == DateTime.MinValue) return "never";
            var delta = DateTime.Now - t;
            if (delta.TotalSeconds < 0) return t.ToString("HH:mm:ss");
            if (delta.TotalSeconds < 60) return $"{(int)delta.TotalSeconds}s ago";
            if (delta.TotalMinutes < 60) return $"{(int)delta.TotalMinutes}m ago";
            if (delta.TotalHours < 24)   return $"{(int)delta.TotalHours}h ago";
            return t.ToString("yyyy-MM-dd HH:mm");
        }

        #endregion
    }

    /// <summary>
    /// Sync settings tab — master enable toggle, monitored-accounts list with
    /// per-account checkboxes, output-folder shortcut. Ported from
    /// JournifiSync v2.0.1's settings panel; stats moved to Dashboard so this
    /// tab focuses on control rather than display.
    /// </summary>
    public class SyncTab : JournifiSyncNTTabBase
    {
        protected override string HeaderLabel => "Sync";

        private DispatcherTimer refreshTimer;
        private CheckBox enableCheckbox;
        private TextBlock enableHint;
        private StackPanel accountsPanel;
        private TextBlock outputFolderText;
        // Suppression flag so refresh-driven CheckBox state changes don't
        // re-fire SetAccountEnabled and loop. Mirrors v2.0.1's pattern.
        private bool isRefreshingAccounts;

        protected override FrameworkElement BuildContent()
        {
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorBackground)
            };
            var outer = new StackPanel
            {
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorBackground),
                Margin = new Thickness(24, 20, 24, 20)
            };

            outer.Children.Add(BuildHeader());
            outer.Children.Add(BuildEnableCard());
            outer.Children.Add(BuildAccountsCard());
            outer.Children.Add(BuildOutputCard());
            scroll.Content = outer;

            StartRefreshTimer();
            this.Unloaded += OnTabUnloaded;
            return scroll;
        }

        public override void Cleanup()
        {
            // Don't stop refreshTimer here — see DashboardTab note. Real
            // teardown happens in OnTabUnloaded on actual window close.
            base.Cleanup();
        }

        private void OnTabUnloaded(object sender, RoutedEventArgs e)
        {
            refreshTimer?.Stop();
            refreshTimer = null;
            this.Unloaded -= OnTabUnloaded;
        }

        #region UI construction

        private FrameworkElement BuildHeader()
        {
            var row = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 0, 0, 14)
            };
            row.Children.Add(new TextBlock
            {
                Text = "Sync",
                FontSize = 22,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                VerticalAlignment = VerticalAlignment.Center
            });
            row.Children.Add(new TextBlock
            {
                Text = "Execution capture & journal export",
                FontSize = 11,
                FontStyle = FontStyles.Italic,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                Margin = new Thickness(12, 8, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            });
            return row;
        }

        private Border BuildEnableCard()
        {
            var card = MakeSectionCard("MASTER SWITCH");
            var stack = (StackPanel)card.Child;

            var row = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 4, 0, 0) };
            enableCheckbox = new CheckBox
            {
                IsChecked = true,
                VerticalAlignment = VerticalAlignment.Center,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary)
            };
            enableCheckbox.Click += OnEnableCheckboxClick;
            row.Children.Add(enableCheckbox);
            row.Children.Add(new TextBlock
            {
                Text = "Sync enabled",
                FontSize = 13,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                Margin = new Thickness(8, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            });
            stack.Children.Add(row);

            enableHint = new TextBlock
            {
                Text = "When disabled the module keeps subscribing to accounts but does not write executions.",
                FontSize = 10,
                FontStyle = FontStyles.Italic,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted),
                Margin = new Thickness(0, 8, 0, 0),
                TextWrapping = TextWrapping.Wrap
            };
            stack.Children.Add(enableHint);
            return card;
        }

        private Border BuildAccountsCard()
        {
            var card = MakeSectionCard("MONITORED ACCOUNTS");
            var stack = (StackPanel)card.Child;

            accountsPanel = new StackPanel { Margin = new Thickness(0, 4, 0, 0) };
            stack.Children.Add(accountsPanel);

            stack.Children.Add(new TextBlock
            {
                Text = "Uncheck an account to mute its executions from sync (preference persists across restarts).",
                FontSize = 10,
                FontStyle = FontStyles.Italic,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted),
                Margin = new Thickness(0, 8, 0, 0),
                TextWrapping = TextWrapping.Wrap
            });
            return card;
        }

        private Border BuildOutputCard()
        {
            var card = MakeSectionCard("OUTPUT");
            var stack = (StackPanel)card.Child;

            var row = new Grid { Margin = new Thickness(0, 4, 0, 0) };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            outputFolderText = new TextBlock
            {
                Text = JournifiNTPaths.SyncDir,
                FontSize = 11,
                FontFamily = new FontFamily("Consolas, Courier New, monospace"),
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                VerticalAlignment = VerticalAlignment.Center,
                TextTrimming = TextTrimming.CharacterEllipsis
            };
            Grid.SetColumn(outputFolderText, 0);
            row.Children.Add(outputFolderText);

            var openBtn = MakeAccentButton("Open");
            openBtn.Click += OnOpenFolderClick;
            Grid.SetColumn(openBtn, 1);
            row.Children.Add(openBtn);

            stack.Children.Add(row);
            return card;
        }

        // Small primitives — slightly different from DashboardTab's because
        // SyncTab cards have a section header pill inside them.
        private static Border MakeSectionCard(string headerLabel)
        {
            var card = new Border
            {
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorCard),
                BorderBrush = new SolidColorBrush(JournifiSyncNTTheme.ColorBorder),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(6),
                Padding = new Thickness(14, 12, 14, 14),
                Margin = new Thickness(0, 0, 0, 12)
            };
            var stack = new StackPanel();
            stack.Children.Add(new TextBlock
            {
                Text = headerLabel,
                FontSize = 10,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                Margin = new Thickness(0, 0, 0, 4)
            });
            card.Child = stack;
            return card;
        }

        private static Button MakeAccentButton(string text)
        {
            return new Button
            {
                Content = text,
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorAccent),
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                BorderThickness = new Thickness(0),
                Padding = new Thickness(14, 4, 14, 4),
                Margin = new Thickness(8, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
        }

        #endregion

        #region Event handlers

        private void OnEnableCheckboxClick(object sender, RoutedEventArgs e)
        {
            dynamic sync = JournifiSyncNTBridge.Sync;
            if (sync == null) return;
            bool enabled = enableCheckbox.IsChecked ?? true;
            sync.SetEnabled(enabled);
        }

        private void OnAccountCheckboxClick(object sender, RoutedEventArgs e)
        {
            if (isRefreshingAccounts) return;
            var cb = sender as CheckBox;
            if (cb == null) return;
            string accountName = cb.Tag as string;
            if (string.IsNullOrEmpty(accountName)) return;

            dynamic sync = JournifiSyncNTBridge.Sync;
            if (sync == null) return;
            bool enabled = cb.IsChecked ?? true;
            sync.SetAccountEnabled(accountName, enabled);

            // Update the sibling status text inline so the user sees an
            // instant response without waiting for the 2s refresh tick.
            var row = cb.Parent as Grid;
            if (row != null)
            {
                foreach (var child in row.Children)
                {
                    if (!(child is TextBlock tb)) continue;
                    int col = Grid.GetColumn(tb);
                    if (col == 1)
                    {
                        tb.Foreground = new SolidColorBrush(enabled
                            ? JournifiSyncNTTheme.ColorTextPrimary
                            : JournifiSyncNTTheme.ColorTextSecondary);
                    }
                    else if (col == 2)
                    {
                        tb.Text = enabled ? "Active" : "Muted";
                        tb.Foreground = new SolidColorBrush(enabled
                            ? JournifiSyncNTTheme.ColorAccentGreen
                            : JournifiSyncNTTheme.ColorTextMuted);
                    }
                }
            }
        }

        private void OnOpenFolderClick(object sender, RoutedEventArgs e)
        {
            try
            {
                string folder = JournifiNTPaths.SyncDir;
                if (System.IO.Directory.Exists(folder))
                    System.Diagnostics.Process.Start("explorer.exe", folder);
                else
                    MessageBox.Show($"Folder does not exist yet:\n{folder}",
                        "JournifiSync NT", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("SyncTab", $"OpenFolder failed: {ex.Message}");
            }
        }

        #endregion

        #region Refresh

        private void StartRefreshTimer()
        {
            refreshTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
            refreshTimer.Tick += (s, e) => RefreshUI();
            refreshTimer.Start();
            RefreshUI();
        }

        private void RefreshUI()
        {
            try
            {
                dynamic sync = JournifiSyncNTBridge.Sync;
                RefreshEnable(sync);
                RefreshAccounts(sync);
                outputFolderText.Text = JournifiNTPaths.SyncDir;
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("SyncTab", $"RefreshUI: {ex.Message}");
            }
        }

        private void RefreshEnable(dynamic sync)
        {
            if (sync == null)
            {
                enableCheckbox.IsEnabled = false;
                return;
            }
            enableCheckbox.IsEnabled = true;
            // Mute the Click handler while we set IsChecked programmatically
            // to avoid bouncing on the SetEnabled call.
            isRefreshingAccounts = true;
            try { enableCheckbox.IsChecked = sync.IsEnabled; }
            finally { isRefreshingAccounts = false; }
        }

        /// <summary>
        /// Rebuild the accounts list. Connected accounts come from the module's
        /// live connection-status check; the per-account enable state comes
        /// from the persisted disabled-accounts set.
        ///
        /// Rebuild-from-scratch on each refresh is fine because the connected
        /// account count is small (single-digit typical, ~7 max for the user)
        /// and the WPF measure cost is negligible.
        /// </summary>
        private void RefreshAccounts(dynamic sync)
        {
            isRefreshingAccounts = true;
            try
            {
                accountsPanel.Children.Clear();

                if (sync == null)
                {
                    accountsPanel.Children.Add(new TextBlock
                    {
                        Text = "(loading)",
                        FontSize = 11,
                        FontStyle = FontStyles.Italic,
                        Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted),
                        HorizontalAlignment = HorizontalAlignment.Center,
                        Margin = new Thickness(0, 12, 0, 12)
                    });
                    return;
                }

                // Materialize the dynamic IEnumerable into a typed list so
                // we can sort with LINQ. DLR can't dispatch ToList()/OrderBy()
                // on dynamic receivers.
                var connected = new List<string>();
                try
                {
                    var dConnected = sync.GetConnectedAccounts();
                    if (dConnected != null)
                        foreach (string s in dConnected) connected.Add(s);
                }
                catch { /* leave empty */ }

                if (connected.Count == 0)
                {
                    accountsPanel.Children.Add(new TextBlock
                    {
                        Text = "No accounts connected — connect to your broker in NT and they'll appear here.",
                        FontSize = 11,
                        FontStyle = FontStyles.Italic,
                        Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                        HorizontalAlignment = HorizontalAlignment.Center,
                        Margin = new Thickness(0, 12, 0, 12),
                        TextWrapping = TextWrapping.Wrap
                    });
                    return;
                }

                foreach (string accountName in connected.OrderBy(a => a, StringComparer.OrdinalIgnoreCase))
                {
                    bool enabled = (bool)sync.IsAccountEnabled(accountName);
                    accountsPanel.Children.Add(BuildAccountRow(accountName, enabled));
                }
            }
            finally
            {
                isRefreshingAccounts = false;
            }
        }

        private Grid BuildAccountRow(string accountName, bool isEnabled)
        {
            var row = new Grid { Margin = new Thickness(0, 3, 0, 3) };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(24) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(60) });

            var cb = new CheckBox
            {
                IsChecked = isEnabled,
                VerticalAlignment = VerticalAlignment.Center,
                Tag = accountName,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary)
            };
            cb.Click += OnAccountCheckboxClick;
            Grid.SetColumn(cb, 0);
            row.Children.Add(cb);

            var name = new TextBlock
            {
                Text = accountName,
                FontSize = 12,
                FontFamily = new FontFamily("Consolas, Courier New, monospace"),
                Foreground = new SolidColorBrush(isEnabled
                    ? JournifiSyncNTTheme.ColorTextPrimary
                    : JournifiSyncNTTheme.ColorTextSecondary),
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(4, 0, 0, 0)
            };
            Grid.SetColumn(name, 1);
            row.Children.Add(name);

            var status = new TextBlock
            {
                Text = isEnabled ? "Active" : "Muted",
                FontSize = 10,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(isEnabled
                    ? JournifiSyncNTTheme.ColorAccentGreen
                    : JournifiSyncNTTheme.ColorTextMuted),
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Right
            };
            Grid.SetColumn(status, 2);
            row.Children.Add(status);

            return row;
        }

        #endregion
    }

    /// <summary>
    /// Bars settings tab — master enable toggle, watched-symbols list with
    /// Remove buttons, Add-Symbol panel with the instrument-picker dropdown
    /// (carried forward from JournifiBars v1.1.1), and Resync All / Open
    /// Folder actions. Ported from JournifiBars v1.1.1's settings panel;
    /// stats moved to the Dashboard so this tab focuses on configuration.
    /// </summary>
    public class BarsTab : JournifiSyncNTTabBase
    {
        protected override string HeaderLabel => "Bars";

        // v3.0.1 — the per-symbol timeframe picker was removed: the journal
        // imports 1-minute bars only and aggregates 5m/15m/1h/4h on read.
        // The static Timeframes array + newSymbolTfChecks field that backed
        // the checkbox row are gone with it.

        private DispatcherTimer refreshTimer;
        private CheckBox enableCheckbox;
        private StackPanel symbolsPanel;
        // NT's native instrument picker — Tools.InstrumentSelector is the
        // inline single-select UserControl variant. (Tools.InstrumentSelectorPopup
        // is the hidden popup body designed to embed in a parent host;
        // doesn't render standalone.) Emits an InstrumentChanged event when
        // the user picks something.
        private NinjaTrader.Gui.Tools.InstrumentSelector ntInstrumentPicker;
        // FullName of the user's most recent selection from the picker.
        // OnAddSymbolClick reads this when the Add Symbol button is clicked.
        private string ntSelectedSymbol;
        private TextBlock outputFolderText;
        // Suppression flag — see SyncTab for the same pattern.
        private bool isRefreshing;

        protected override FrameworkElement BuildContent()
        {
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorBackground)
            };
            var outer = new StackPanel
            {
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorBackground),
                Margin = new Thickness(24, 20, 24, 20)
            };

            outer.Children.Add(BuildHeader());
            outer.Children.Add(BuildEnableCard());
            outer.Children.Add(BuildSymbolsCard());
            outer.Children.Add(BuildAddSymbolCard());
            outer.Children.Add(BuildActionsCard());
            scroll.Content = outer;

            StartRefreshTimer();
            this.Unloaded += OnTabUnloaded;
            return scroll;
        }

        public override void Cleanup()
        {
            // Don't stop refreshTimer here — see DashboardTab note.
            base.Cleanup();
        }

        private void OnTabUnloaded(object sender, RoutedEventArgs e)
        {
            refreshTimer?.Stop();
            refreshTimer = null;
            this.Unloaded -= OnTabUnloaded;
        }

        #region UI construction

        private FrameworkElement BuildHeader()
        {
            var row = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 0, 0, 14)
            };
            row.Children.Add(new TextBlock
            {
                Text = "Bars",
                FontSize = 22,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                VerticalAlignment = VerticalAlignment.Center
            });
            row.Children.Add(new TextBlock
            {
                Text = "OHLCV bar export for trade-card charts",
                FontSize = 11,
                FontStyle = FontStyles.Italic,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                Margin = new Thickness(12, 8, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            });
            return row;
        }

        private Border BuildEnableCard()
        {
            var card = MakeSectionCard("MASTER SWITCH");
            var stack = (StackPanel)card.Child;

            var row = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 4, 0, 0) };
            enableCheckbox = new CheckBox
            {
                IsChecked = true,
                VerticalAlignment = VerticalAlignment.Center,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary)
            };
            enableCheckbox.Click += OnEnableCheckboxClick;
            row.Children.Add(enableCheckbox);
            row.Children.Add(new TextBlock
            {
                Text = "Bar export enabled",
                FontSize = 13,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                Margin = new Thickness(8, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            });
            stack.Children.Add(row);

            stack.Children.Add(new TextBlock
            {
                Text = "When disabled, watched-symbol subscriptions stay armed but no new bars are written to disk.",
                FontSize = 10,
                FontStyle = FontStyles.Italic,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted),
                Margin = new Thickness(0, 8, 0, 0),
                TextWrapping = TextWrapping.Wrap
            });
            return card;
        }

        private Border BuildSymbolsCard()
        {
            var card = MakeSectionCard("WATCHED SYMBOLS");
            var stack = (StackPanel)card.Child;

            symbolsPanel = new StackPanel { Margin = new Thickness(0, 4, 0, 0) };
            stack.Children.Add(symbolsPanel);
            return card;
        }

        private Border BuildAddSymbolCard()
        {
            var card = MakeSectionCard("ADD SYMBOL");
            var stack = (StackPanel)card.Child;

            // Try NT's native Tools.InstrumentSelector first — the inline
            // visible variant (single-select). If it fails to instantiate
            // we log and fall through to the ComboBox below as a fallback.
            try
            {
                ntInstrumentPicker = new NinjaTrader.Gui.Tools.InstrumentSelector
                {
                    Margin = new Thickness(0, 4, 0, 6)
                };
                ntInstrumentPicker.InstrumentChanged += OnNTInstrumentChanged;
                stack.Children.Add(ntInstrumentPicker);

                stack.Children.Add(new TextBlock
                {
                    Text = "Native NT instrument picker — categorized lists, recents, search.",
                    FontSize = 10,
                    FontStyle = FontStyles.Italic,
                    Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted),
                    Margin = new Thickness(0, 0, 0, 10)
                });
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("BarsTab",
                    $"Native InstrumentSelector unavailable, falling back to ComboBox: {ex.Message}");
                ntInstrumentPicker = null;
            }

            // v3.0.1 — timeframe picker removed. The journal imports 1-minute
            // bars only and aggregates 5m/15m/1h/4h on read, so there's no
            // reason to offer a per-symbol TF selection (it only created
            // redundant native-bar CSVs the journal never read). Every added
            // symbol is watched at 1m.
            stack.Children.Add(new TextBlock
            {
                Text = "Imports 1-minute bars. The journal derives 5m / 15m / 1h / 4h on read.",
                FontSize = 10,
                FontStyle = FontStyles.Italic,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted),
                Margin = new Thickness(0, 0, 0, 6)
            });

            var addBtn = MakeAccentButton("Add Symbol");
            addBtn.HorizontalAlignment = HorizontalAlignment.Right;
            addBtn.Margin = new Thickness(0, 10, 0, 0);
            addBtn.Click += OnAddSymbolClick;
            stack.Children.Add(addBtn);
            return card;
        }

        private Border BuildActionsCard()
        {
            var card = MakeSectionCard("ACTIONS");
            var stack = (StackPanel)card.Child;

            var row = new Grid { Margin = new Thickness(0, 4, 0, 0) };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var resyncBtn = new Button
            {
                Content = "Resync All",
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorAccentGreen),
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                BorderThickness = new Thickness(0),
                Padding = new Thickness(14, 4, 14, 4)
            };
            resyncBtn.Click += OnResyncClick;
            Grid.SetColumn(resyncBtn, 0);
            row.Children.Add(resyncBtn);

            outputFolderText = new TextBlock
            {
                Text = JournifiNTPaths.BarsDir,
                FontSize = 11,
                FontFamily = new FontFamily("Consolas, Courier New, monospace"),
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(12, 0, 12, 0),
                TextTrimming = TextTrimming.CharacterEllipsis
            };
            Grid.SetColumn(outputFolderText, 1);
            row.Children.Add(outputFolderText);

            var openBtn = new Button
            {
                Content = "Open",
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorSurface),
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                BorderBrush = new SolidColorBrush(JournifiSyncNTTheme.ColorBorder),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(14, 4, 14, 4)
            };
            openBtn.Click += OnOpenFolderClick;
            Grid.SetColumn(openBtn, 2);
            row.Children.Add(openBtn);

            stack.Children.Add(row);
            return card;
        }

        private static Border MakeSectionCard(string headerLabel)
        {
            var card = new Border
            {
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorCard),
                BorderBrush = new SolidColorBrush(JournifiSyncNTTheme.ColorBorder),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(6),
                Padding = new Thickness(14, 12, 14, 14),
                Margin = new Thickness(0, 0, 0, 12)
            };
            var stack = new StackPanel();
            stack.Children.Add(new TextBlock
            {
                Text = headerLabel,
                FontSize = 10,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                Margin = new Thickness(0, 0, 0, 4)
            });
            card.Child = stack;
            return card;
        }

        private static Button MakeAccentButton(string text)
        {
            return new Button
            {
                Content = text,
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorAccent),
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                BorderThickness = new Thickness(0),
                Padding = new Thickness(14, 4, 14, 4),
                VerticalAlignment = VerticalAlignment.Center
            };
        }

        #endregion

        #region Event handlers

        private void OnEnableCheckboxClick(object sender, RoutedEventArgs e)
        {
            dynamic bars = JournifiSyncNTBridge.Bars;
            if (bars == null) return;
            bool enabled = enableCheckbox.IsChecked ?? true;
            bars.SetEnabled(enabled);
        }

        private void OnResyncClick(object sender, RoutedEventArgs e)
        {
            dynamic bars = JournifiSyncNTBridge.Bars;
            bars?.ResyncAll();
        }

        private void OnOpenFolderClick(object sender, RoutedEventArgs e)
        {
            try
            {
                string folder = JournifiNTPaths.BarsDir;
                if (System.IO.Directory.Exists(folder))
                    System.Diagnostics.Process.Start("explorer.exe", folder);
                else
                    MessageBox.Show($"Folder does not exist yet:\n{folder}",
                        "JournifiSync NT", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("BarsTab", $"OpenFolder failed: {ex.Message}");
            }
        }

        /// <summary>
        /// Fires when the user picks an instrument in the native NT
        /// <see cref="NinjaTrader.Gui.Tools.InstrumentSelector"/>. We don't
        /// know the exact event-handler signature — could be
        /// <see cref="EventHandler"/> or NT's own delegate type. Try the
        /// plain pattern; iterate from the compile error if it's wrong.
        /// Selection is read from the picker's <c>SelectedInstrument</c>
        /// property (singular — this is the inline variant, single-select).
        /// </summary>
        private void OnNTInstrumentChanged(object sender, EventArgs e)
        {
            try
            {
                if (ntInstrumentPicker == null) return;

                string fullName = null;

                // Try direct property access via dynamic — most likely path.
                try
                {
                    dynamic dynPicker = ntInstrumentPicker;
                    var inst = dynPicker.SelectedInstrument;
                    if (inst != null) fullName = (string)inst.FullName;
                }
                catch { /* try reflection fallbacks below */ }

                // Reflection fallback — probe likely property names since
                // we're not 100% certain which one this control exposes.
                if (string.IsNullOrEmpty(fullName))
                {
                    foreach (var memberName in new[] { "SelectedInstrument", "Instrument" })
                    {
                        try
                        {
                            var prop = ntInstrumentPicker.GetType().GetProperty(memberName);
                            var val = prop?.GetValue(ntInstrumentPicker);
                            if (val == null) continue;
                            fullName = val.GetType().GetProperty("FullName")?.GetValue(val) as string;
                            if (!string.IsNullOrWhiteSpace(fullName)) break;
                        }
                        catch { }
                    }
                }

                if (!string.IsNullOrEmpty(fullName))
                {
                    ntSelectedSymbol = fullName;
                    JournifiNTLog.Info("BarsTab", $"Native picker selected: {ntSelectedSymbol}");
                }
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("BarsTab", $"OnNTInstrumentChanged: {ex.Message}");
            }
        }

        private void OnAddSymbolClick(object sender, RoutedEventArgs e)
        {
            // Read the user's selection from the native NT picker. The
            // InstrumentChanged event handler stamps ntSelectedSymbol when
            // they pick something — if nothing is picked, prompt and bail.
            string sym = (ntSelectedSymbol ?? "").Trim();
            if (string.IsNullOrEmpty(sym))
            {
                MessageBox.Show("Pick a symbol from the dropdown first " +
                                "(use the search box for symbols not yet loaded).",
                    "JournifiSync NT", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            // v3.0.1 — always 1m. The journal aggregates coarser TFs on read,
            // so there's no per-symbol timeframe choice anymore. AddWatchedSymbol
            // still takes a list (data model unchanged) — we just pass ["1m"].
            var tfs = new List<string> { "1m" };

            dynamic bars = JournifiSyncNTBridge.Bars;
            if (bars == null)
            {
                MessageBox.Show("Bars module not loaded yet.", "JournifiSync NT",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Cast the dynamic return to bool — DLR can struggle with the
            // negation operator applied directly to a dynamic call result.
            bool added = (bool)bars.AddWatchedSymbol(sym, (IEnumerable<string>)tfs);
            if (!added)
            {
                MessageBox.Show($"Symbol \"{sym}\" is already in the watched list.",
                    "JournifiSync NT", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            // Clear the in-memory selection. We don't try to reset the
            // native picker control's visible state — it correctly remembers
            // its last pick which is fine UX (matches how NT's chart picker
            // behaves).
            ntSelectedSymbol = null;
            RefreshUI();
            bars.ResyncAll();
        }

        private void OnRemoveSymbolClick(string symbol)
        {
            if (string.IsNullOrEmpty(symbol)) return;
            var result = MessageBox.Show($"Remove \"{symbol}\" from the watched list?",
                "JournifiSync NT", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result != MessageBoxResult.Yes) return;

            dynamic bars = JournifiSyncNTBridge.Bars;
            bars?.RemoveWatchedSymbol(symbol);
            RefreshUI();
        }

        #endregion

        #region Refresh

        private void StartRefreshTimer()
        {
            refreshTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
            refreshTimer.Tick += (s, e) => RefreshUI();
            refreshTimer.Start();
            RefreshUI();
        }

        private void RefreshUI()
        {
            try
            {
                dynamic bars = JournifiSyncNTBridge.Bars;
                RefreshEnable(bars);
                RefreshWatchedSymbols(bars);
                outputFolderText.Text = JournifiNTPaths.BarsDir;
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("BarsTab", $"RefreshUI: {ex.Message}");
            }
        }

        private void RefreshEnable(dynamic bars)
        {
            if (bars == null)
            {
                enableCheckbox.IsEnabled = false;
                return;
            }
            enableCheckbox.IsEnabled = true;
            isRefreshing = true;
            try { enableCheckbox.IsChecked = bars.IsEnabled; }
            finally { isRefreshing = false; }
        }

        private void RefreshWatchedSymbols(dynamic bars)
        {
            isRefreshing = true;
            try
            {
                symbolsPanel.Children.Clear();

                if (bars == null)
                {
                    symbolsPanel.Children.Add(new TextBlock
                    {
                        Text = "(loading)",
                        FontSize = 11,
                        FontStyle = FontStyles.Italic,
                        Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted),
                        HorizontalAlignment = HorizontalAlignment.Center,
                        Margin = new Thickness(0, 12, 0, 12)
                    });
                    return;
                }

                // Materialize the dynamic remote list into local-assembly
                // POCOs so LINQ + .Count work normally. The remote items
                // are JournifiNTWatchedSymbol from a different assembly
                // (after recompile); we can't pattern-match them as our
                // own type, but their fields are universally compatible.
                var watched = new List<JournifiNTWatchedSymbol>();
                try
                {
                    var dWatched = bars.GetWatchedSymbolsSnapshot();
                    if (dWatched != null)
                    {
                        foreach (var item in dWatched)
                        {
                            var copy = new JournifiNTWatchedSymbol
                            {
                                Symbol = (string)item.Symbol,
                                Timeframes = new List<string>()
                            };
                            var dTfs = item.Timeframes;
                            if (dTfs != null)
                                foreach (string tf in dTfs) copy.Timeframes.Add(tf);
                            watched.Add(copy);
                        }
                    }
                }
                catch { /* leave empty */ }

                if (watched.Count == 0)
                {
                    symbolsPanel.Children.Add(new TextBlock
                    {
                        Text = "No symbols configured. Add one below.",
                        FontSize = 11,
                        FontStyle = FontStyles.Italic,
                        Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                        HorizontalAlignment = HorizontalAlignment.Center,
                        Margin = new Thickness(0, 12, 0, 12)
                    });
                    return;
                }

                foreach (var w in watched.OrderBy(x => x.Symbol, StringComparer.OrdinalIgnoreCase))
                {
                    symbolsPanel.Children.Add(BuildSymbolRow(w.Symbol, string.Join(", ", w.Timeframes ?? new List<string>())));
                }
            }
            finally
            {
                isRefreshing = false;
            }
        }

        private Border BuildSymbolRow(string symbol, string tfDisplay)
        {
            var card = new Border
            {
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorSurface),
                BorderBrush = new SolidColorBrush(JournifiSyncNTTheme.ColorBorder),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(4),
                Padding = new Thickness(10, 6, 10, 6),
                Margin = new Thickness(0, 0, 0, 6)
            };
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var labelStack = new StackPanel();
            labelStack.Children.Add(new TextBlock
            {
                Text = symbol,
                FontFamily = new FontFamily("Consolas, Courier New, monospace"),
                FontSize = 13,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary)
            });
            labelStack.Children.Add(new TextBlock
            {
                Text = string.IsNullOrEmpty(tfDisplay) ? "(no timeframes)" : tfDisplay,
                FontSize = 10,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                Margin = new Thickness(0, 2, 0, 0)
            });
            Grid.SetColumn(labelStack, 0);
            grid.Children.Add(labelStack);

            var removeBtn = new Button
            {
                Content = "Remove",
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorSurface),
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorAccentRed),
                BorderBrush = new SolidColorBrush(JournifiSyncNTTheme.ColorBorder),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(10, 3, 10, 3),
                FontSize = 11,
                VerticalAlignment = VerticalAlignment.Center
            };
            removeBtn.Click += (s, e) => OnRemoveSymbolClick(symbol);
            Grid.SetColumn(removeBtn, 1);
            grid.Children.Add(removeBtn);

            card.Child = grid;
            return card;
        }

        #endregion
    }

    /// <summary>
    /// Mappings tab — NT account FullName → Journifi accountId table.
    ///
    /// New in v3 (v1/v2 had no shared mapping table). The accountMappings
    /// dictionary lives in Journifi\settings.json under
    /// <see cref="JournifiNTSettings.AccountMappings"/>. Today this is
    /// forward-looking infrastructure: the desktop app still handles its
    /// own mapping at import time, but having the mapping written on the
    /// AddOn side opens the door to (a) the AddOn embedding Journifi
    /// accountIds directly in exec JSONs, eliminating a journal-side
    /// lookup, and (b) future modules (e.g., per-account bars) being able
    /// to disambiguate accounts without re-implementing the mapping table.
    ///
    /// UX:
    ///   • Auto-populates rows for every currently-subscribed NT account
    ///     (read from <see cref="JournifiSyncNTSyncModule.GetMonitoredAccounts"/>)
    ///     PLUS any account already in the persisted map (even if it's
    ///     disconnected right now — preserves user-configured mappings
    ///     across broker disconnects).
    ///   • Each row is read-only NT name + editable TextBox for the
    ///     Journifi accountId.
    ///   • Save All Mappings button persists every editor value to the
    ///     unified settings store in one atomic save.
    ///   • Disconnected accounts get a "(offline)" hint so the user can
    ///     distinguish stale mappings from live ones.
    /// </summary>
    public class MappingsTab : JournifiSyncNTTabBase
    {
        protected override string HeaderLabel => "Mappings";

        private DispatcherTimer refreshTimer;
        private StackPanel rowsPanel;
        // Per-account TextBox refs so Save can read them back in one sweep.
        // Keyed by NT account FullName (case-insensitive).
        private Dictionary<string, TextBox> rowEditors
            = new Dictionary<string, TextBox>(StringComparer.OrdinalIgnoreCase);
        // Track the set we've rendered rows for so refresh can decide whether
        // to rebuild (cheaper than rebuilding every tick).
        private HashSet<string> currentRowKeys
            = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private TextBlock statusText;

        protected override FrameworkElement BuildContent()
        {
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorBackground)
            };
            var outer = new StackPanel
            {
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorBackground),
                Margin = new Thickness(24, 20, 24, 20)
            };

            outer.Children.Add(BuildHeader());
            outer.Children.Add(BuildAboutCard());
            outer.Children.Add(BuildAccountsCard());
            outer.Children.Add(BuildSaveCard());
            scroll.Content = outer;

            StartRefreshTimer();
            this.Unloaded += OnTabUnloaded;
            return scroll;
        }

        public override void Cleanup()
        {
            // Don't stop refreshTimer here — see DashboardTab note.
            base.Cleanup();
        }

        private void OnTabUnloaded(object sender, RoutedEventArgs e)
        {
            refreshTimer?.Stop();
            refreshTimer = null;
            this.Unloaded -= OnTabUnloaded;
        }

        #region UI construction

        private FrameworkElement BuildHeader()
        {
            var row = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 0, 0, 14)
            };
            row.Children.Add(new TextBlock
            {
                Text = "Mappings",
                FontSize = 22,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                VerticalAlignment = VerticalAlignment.Center
            });
            row.Children.Add(new TextBlock
            {
                Text = "NT account → Journifi accountId",
                FontSize = 11,
                FontStyle = FontStyles.Italic,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                Margin = new Thickness(12, 8, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            });
            return row;
        }

        private Border BuildAboutCard()
        {
            var card = MakeSectionCard("ABOUT");
            var stack = (StackPanel)card.Child;
            stack.Children.Add(new TextBlock
            {
                Text = "Map each NinjaTrader account to its corresponding Journifi accountId. " +
                       "The map persists in Journifi\\settings.json. Today the desktop app " +
                       "handles account mapping at import time; this table is forward-looking " +
                       "infrastructure that future versions of the AddOn will embed directly " +
                       "into exec JSONs.",
                FontSize = 11,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 4, 0, 0),
                LineHeight = 17
            });
            return card;
        }

        private Border BuildAccountsCard()
        {
            var card = MakeSectionCard("ACCOUNTS");
            var stack = (StackPanel)card.Child;

            // Column header strip
            var header = new Grid { Margin = new Thickness(0, 4, 0, 8) };
            header.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            header.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(16) });
            header.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.4, GridUnitType.Star) });

            var lblNT = new TextBlock
            {
                Text = "NT ACCOUNT",
                FontSize = 9,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted)
            };
            Grid.SetColumn(lblNT, 0);
            header.Children.Add(lblNT);

            var lblJournifi = new TextBlock
            {
                Text = "JOURNIFI accountId",
                FontSize = 9,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted)
            };
            Grid.SetColumn(lblJournifi, 2);
            header.Children.Add(lblJournifi);
            stack.Children.Add(header);

            rowsPanel = new StackPanel();
            stack.Children.Add(rowsPanel);
            return card;
        }

        private Border BuildSaveCard()
        {
            var card = MakeSectionCard("SAVE");
            var stack = (StackPanel)card.Child;

            var row = new Grid { Margin = new Thickness(0, 4, 0, 0) };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            statusText = new TextBlock
            {
                Text = "",
                FontSize = 11,
                FontStyle = FontStyles.Italic,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted),
                VerticalAlignment = VerticalAlignment.Center,
                TextWrapping = TextWrapping.Wrap
            };
            Grid.SetColumn(statusText, 0);
            row.Children.Add(statusText);

            var saveBtn = new Button
            {
                Content = "Save All Mappings",
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorAccent),
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                BorderThickness = new Thickness(0),
                Padding = new Thickness(14, 4, 14, 4),
                VerticalAlignment = VerticalAlignment.Center
            };
            saveBtn.Click += OnSaveAllClick;
            Grid.SetColumn(saveBtn, 1);
            row.Children.Add(saveBtn);

            stack.Children.Add(row);
            return card;
        }

        private static Border MakeSectionCard(string headerLabel)
        {
            var card = new Border
            {
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorCard),
                BorderBrush = new SolidColorBrush(JournifiSyncNTTheme.ColorBorder),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(6),
                Padding = new Thickness(14, 12, 14, 14),
                Margin = new Thickness(0, 0, 0, 12)
            };
            var stack = new StackPanel();
            stack.Children.Add(new TextBlock
            {
                Text = headerLabel,
                FontSize = 10,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                Margin = new Thickness(0, 0, 0, 4)
            });
            card.Child = stack;
            return card;
        }

        #endregion

        #region Save handler

        private void OnSaveAllClick(object sender, RoutedEventArgs e)
        {
            try
            {
                var newMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (var kvp in rowEditors)
                {
                    string ntName = kvp.Key;
                    string journifiId = (kvp.Value?.Text ?? "").Trim();
                    if (string.IsNullOrEmpty(journifiId)) continue; // empty row → skip (effectively delete)
                    newMap[ntName] = journifiId;
                }

                // Route through the bridge so the save lands in the LIVE
                // orchestrator's settings store, even if this tab is in an
                // old assembly post-recompile.
                dynamic instance = JournifiSyncNTBridge.Instance;
                bool ok = false;
                if (instance != null)
                {
                    try { ok = (bool)instance.SetAccountMappings(newMap); } catch { ok = false; }
                }
                statusText.Text = ok
                    ? $"Saved {newMap.Count} mapping(s) at {DateTime.Now:HH:mm:ss}."
                    : "Save failed — see log for details.";
                statusText.Foreground = new SolidColorBrush(ok
                    ? JournifiSyncNTTheme.ColorAccentGreen
                    : JournifiSyncNTTheme.ColorAccentRed);
                JournifiNTLog.Info("MappingsTab",
                    $"Saved {newMap.Count} account mapping(s) (ok={ok}).");
            }
            catch (Exception ex)
            {
                statusText.Text = $"Save error: {ex.Message}";
                statusText.Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorAccentRed);
                JournifiNTLog.Error("MappingsTab", "Save failed", ex);
            }
        }

        #endregion

        #region Refresh

        private void StartRefreshTimer()
        {
            refreshTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
            refreshTimer.Tick += (s, e) => RefreshUI();
            refreshTimer.Start();
            RefreshUI();
        }

        /// <summary>
        /// Decide whether to rebuild the rows. The set of accounts comes from
        /// the union of (currently subscribed) + (already mapped). Rebuild
        /// only when that key set changes — otherwise the TextBoxes the user
        /// is typing into would get clobbered by the 2s tick.
        /// </summary>
        private void RefreshUI()
        {
            try
            {
                // Pull both the live account list and the persisted mappings
                // through the bridge so reads land on the LIVE orchestrator
                // (works correctly across NT recompile boundaries).
                dynamic instance = JournifiSyncNTBridge.Instance;

                var live = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                try
                {
                    dynamic sync = instance?.Sync;
                    if (sync != null)
                        foreach (string name in sync.GetMonitoredAccounts())
                            if (!string.IsNullOrWhiteSpace(name)) live.Add(name);
                }
                catch { }

                var mappings = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                try
                {
                    if (instance != null)
                    {
                        var d = instance.GetAccountMappings();
                        if (d != null)
                            foreach (var pair in d)
                                mappings[(string)pair.Key] = (string)pair.Value;
                    }
                }
                catch { }

                // Combined key set — live accounts + previously-mapped accounts
                var keys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (var k in live) keys.Add(k);
                foreach (var k in mappings.Keys) keys.Add(k);

                if (keys.SetEquals(currentRowKeys)) return; // no membership change → skip rebuild

                RebuildRows(keys, mappings, live);
                currentRowKeys = keys;
            }
            catch (Exception ex)
            {
                JournifiNTLog.Warn("MappingsTab", $"RefreshUI: {ex.Message}");
            }
        }

        private void RebuildRows(HashSet<string> accountKeys,
                                 Dictionary<string, string> mappings,
                                 HashSet<string> liveAccounts)
        {
            rowsPanel.Children.Clear();
            rowEditors.Clear();

            if (accountKeys.Count == 0)
            {
                rowsPanel.Children.Add(new TextBlock
                {
                    Text = "No accounts to map yet. Connect to your broker in NT and " +
                           "subscribed accounts will appear here automatically.",
                    FontSize = 11,
                    FontStyle = FontStyles.Italic,
                    Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                    HorizontalAlignment = HorizontalAlignment.Center,
                    TextWrapping = TextWrapping.Wrap,
                    Margin = new Thickness(0, 12, 0, 12)
                });
                return;
            }

            // Connected accounts on top, then offline (mapped but not currently
            // subscribed) so the user sees their live working set first.
            var ordered = accountKeys
                .OrderByDescending(k => liveAccounts.Contains(k))
                .ThenBy(k => k, StringComparer.OrdinalIgnoreCase);

            foreach (var ntName in ordered)
            {
                bool isLive = liveAccounts.Contains(ntName);
                string mapped = "";
                if (mappings.TryGetValue(ntName, out var v))
                    mapped = v ?? "";
                rowsPanel.Children.Add(BuildAccountRow(ntName, mapped, isLive));
            }
        }

        private Grid BuildAccountRow(string ntName, string currentMapping, bool isLive)
        {
            var row = new Grid { Margin = new Thickness(0, 3, 0, 3) };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(16) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.4, GridUnitType.Star) });

            // NT account name (left column) + offline tag if applicable
            var leftStack = new StackPanel { Orientation = Orientation.Horizontal };
            leftStack.Children.Add(new TextBlock
            {
                Text = ntName,
                FontFamily = new FontFamily("Consolas, Courier New, monospace"),
                FontSize = 12,
                Foreground = new SolidColorBrush(isLive
                    ? JournifiSyncNTTheme.ColorTextPrimary
                    : JournifiSyncNTTheme.ColorTextSecondary),
                VerticalAlignment = VerticalAlignment.Center
            });
            if (!isLive)
            {
                leftStack.Children.Add(new TextBlock
                {
                    Text = "  (offline)",
                    FontSize = 10,
                    FontStyle = FontStyles.Italic,
                    Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted),
                    VerticalAlignment = VerticalAlignment.Center
                });
            }
            Grid.SetColumn(leftStack, 0);
            row.Children.Add(leftStack);

            // Arrow separator (column 1 is just a spacer, drawn here for clarity)
            var arrow = new TextBlock
            {
                Text = "→",
                FontSize = 11,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted),
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };
            Grid.SetColumn(arrow, 1);
            row.Children.Add(arrow);

            // Journifi accountId editor (right column)
            var editor = new TextBox
            {
                Text = currentMapping ?? "",
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorSurface),
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                BorderBrush = new SolidColorBrush(JournifiSyncNTTheme.ColorBorder),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(6, 3, 6, 3),
                FontFamily = new FontFamily("Consolas, Courier New, monospace"),
                FontSize = 12,
                Tag = ntName
            };
            Grid.SetColumn(editor, 2);
            row.Children.Add(editor);

            rowEditors[ntName] = editor;
            return row;
        }

        #endregion
    }

    /// <summary>
    /// About tab — version + build info, output-path shortcuts, manual
    /// legacy-migration re-run, log shortcuts.
    /// </summary>
    public class AboutTab : JournifiSyncNTTabBase
    {
        protected override string HeaderLabel => "About";

        private TextBlock migrationStatusText;
        private TextBlock legacyStatusText;

        protected override FrameworkElement BuildContent()
        {
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorBackground)
            };
            var outer = new StackPanel
            {
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorBackground),
                Margin = new Thickness(24, 20, 24, 20)
            };

            outer.Children.Add(BuildHeader());
            outer.Children.Add(BuildVersionCard());
            outer.Children.Add(BuildFoldersCard());
            outer.Children.Add(BuildMigrationCard());
            outer.Children.Add(BuildAuthorFooter());
            scroll.Content = outer;
            return scroll;
        }

        #region UI construction

        private FrameworkElement BuildHeader()
        {
            var row = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 0, 0, 14)
            };
            row.Children.Add(new TextBlock
            {
                Text = "About",
                FontSize = 22,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                VerticalAlignment = VerticalAlignment.Center
            });
            row.Children.Add(new TextBlock
            {
                Text = "Version, paths, legacy migration",
                FontSize = 11,
                FontStyle = FontStyles.Italic,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                Margin = new Thickness(12, 8, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            });
            return row;
        }

        private Border BuildVersionCard()
        {
            var card = MakeSectionCard("JOURNIFISYNC NT");
            var stack = (StackPanel)card.Child;
            AddKeyValueRow(stack, "Version",  JournifiSyncNT.VERSION);
            AddKeyValueRow(stack, "AddOn name", JournifiSyncNT.ADDON_NAME);
            AddKeyValueRow(stack, "Brand",    "JournifiSync NT (NinjaTrader 8 client of the Journifi AI line)");

            var notes = new TextBlock
            {
                Text = "Unified successor to JournifiSync v2.0.1 (executions) and JournifiBars v1.1.x (bars). " +
                       "Both modules share settings, instrument cache, and logging through one orchestrator.",
                FontSize = 11,
                FontStyle = FontStyles.Italic,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted),
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 10, 0, 0),
                LineHeight = 17
            };
            stack.Children.Add(notes);
            return card;
        }

        private Border BuildFoldersCard()
        {
            var card = MakeSectionCard("OUTPUT FOLDERS");
            var stack = (StackPanel)card.Child;

            AddFolderRow(stack, "Settings + log",
                JournifiNTPaths.JournifiDir,
                "Unified v3 folder. settings.json + log\\Journifi.log live here.");
            AddFolderRow(stack, "Sync output",
                JournifiNTPaths.SyncDir,
                "Per-day execution JSONs. Watched by the Journifi AI desktop app.");
            AddFolderRow(stack, "Bars output",
                JournifiNTPaths.BarsDir,
                "Monthly rolling CSVs per (symbol, timeframe). Read by NinjaTraderBarSource.");
            return card;
        }

        private Border BuildMigrationCard()
        {
            var card = MakeSectionCard("LEGACY MIGRATION");
            var stack = (StackPanel)card.Child;

            stack.Children.Add(new TextBlock
            {
                Text = "On first v3 run we copy data from the legacy JournifiSync and JournifiBars settings files. " +
                       "Re-run manually if you install v1/v2 data later, or want to pull in changes the legacy " +
                       "AddOns made after v3 was set up. Merges (not overwrites): your v3-only edits are preserved.",
                FontSize = 11,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 4, 0, 8),
                LineHeight = 17
            });

            legacyStatusText = new TextBlock
            {
                Text = BuildLegacyFilesStatus(),
                FontSize = 11,
                FontFamily = new FontFamily("Consolas, Courier New, monospace"),
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 0, 0, 10)
            };
            stack.Children.Add(legacyStatusText);

            var actionRow = new Grid();
            actionRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            actionRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            var rerunBtn = new Button
            {
                Content = "Re-run Migration",
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorAccent),
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                BorderThickness = new Thickness(0),
                Padding = new Thickness(14, 4, 14, 4)
            };
            rerunBtn.Click += OnRerunMigrationClick;
            Grid.SetColumn(rerunBtn, 0);
            actionRow.Children.Add(rerunBtn);

            migrationStatusText = new TextBlock
            {
                Text = "",
                FontSize = 11,
                FontStyle = FontStyles.Italic,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted),
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(12, 0, 0, 0),
                TextWrapping = TextWrapping.Wrap
            };
            Grid.SetColumn(migrationStatusText, 1);
            actionRow.Children.Add(migrationStatusText);

            stack.Children.Add(actionRow);
            return card;
        }

        private FrameworkElement BuildAuthorFooter()
        {
            var stack = new StackPanel { Margin = new Thickness(0, 8, 0, 0) };
            stack.Children.Add(new TextBlock
            {
                Text = $"JournifiSync NT v{JournifiSyncNT.VERSION}  ·  Developed for AlphaWolfTrader",
                FontSize = 10,
                FontStyle = FontStyles.Italic,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted)
            });
            stack.Children.Add(new TextBlock
            {
                Text = "Built on the NinjaTrader 8 AddOn framework. Two modules (Sync + Bars) under one isolation boundary.",
                FontSize = 10,
                FontStyle = FontStyles.Italic,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted),
                Margin = new Thickness(0, 2, 0, 0)
            });
            return stack;
        }

        // Small primitives — same shape as the other tabs' MakeSectionCard.
        private static Border MakeSectionCard(string headerLabel)
        {
            var card = new Border
            {
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorCard),
                BorderBrush = new SolidColorBrush(JournifiSyncNTTheme.ColorBorder),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(6),
                Padding = new Thickness(14, 12, 14, 14),
                Margin = new Thickness(0, 0, 0, 12)
            };
            var stack = new StackPanel();
            stack.Children.Add(new TextBlock
            {
                Text = headerLabel,
                FontSize = 10,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                Margin = new Thickness(0, 0, 0, 4)
            });
            card.Child = stack;
            return card;
        }

        private static void AddKeyValueRow(StackPanel parent, string label, string value)
        {
            var row = new Grid { Margin = new Thickness(0, 4, 0, 0) };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(120) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            var lbl = new TextBlock
            {
                Text = label,
                FontSize = 11,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(lbl, 0);
            row.Children.Add(lbl);

            var val = new TextBlock
            {
                Text = value,
                FontSize = 12,
                FontFamily = new FontFamily("Consolas, Courier New, monospace"),
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                TextWrapping = TextWrapping.Wrap
            };
            Grid.SetColumn(val, 1);
            row.Children.Add(val);

            parent.Children.Add(row);
        }

        private void AddFolderRow(StackPanel parent, string label, string folderPath, string hint)
        {
            var block = new Border
            {
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorSurface),
                BorderBrush = new SolidColorBrush(JournifiSyncNTTheme.ColorBorder),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(4),
                Padding = new Thickness(10, 8, 10, 8),
                Margin = new Thickness(0, 4, 0, 6)
            };
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var labelStack = new StackPanel();
            labelStack.Children.Add(new TextBlock
            {
                Text = label,
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary)
            });
            labelStack.Children.Add(new TextBlock
            {
                Text = folderPath,
                FontSize = 10,
                FontFamily = new FontFamily("Consolas, Courier New, monospace"),
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary),
                Margin = new Thickness(0, 2, 0, 0)
            });
            labelStack.Children.Add(new TextBlock
            {
                Text = hint,
                FontSize = 10,
                FontStyle = FontStyles.Italic,
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextMuted),
                Margin = new Thickness(0, 2, 0, 0),
                TextWrapping = TextWrapping.Wrap
            });
            Grid.SetColumn(labelStack, 0);
            grid.Children.Add(labelStack);

            var openBtn = new Button
            {
                Content = "Open",
                Background = new SolidColorBrush(JournifiSyncNTTheme.ColorSurface),
                Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextPrimary),
                BorderBrush = new SolidColorBrush(JournifiSyncNTTheme.ColorBorder),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(12, 4, 12, 4),
                VerticalAlignment = VerticalAlignment.Center,
                Tag = folderPath
            };
            openBtn.Click += (s, e) =>
            {
                try
                {
                    string path = ((Button)s).Tag as string;
                    if (string.IsNullOrEmpty(path)) return;
                    if (System.IO.Directory.Exists(path))
                        System.Diagnostics.Process.Start("explorer.exe", path);
                    else
                        MessageBox.Show($"Folder does not exist yet:\n{path}",
                            "JournifiSync NT", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    JournifiNTLog.Warn("AboutTab", $"Open folder failed: {ex.Message}");
                }
            };
            Grid.SetColumn(openBtn, 1);
            grid.Children.Add(openBtn);

            block.Child = grid;
            parent.Children.Add(block);
        }

        private static string BuildLegacyFilesStatus()
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine($"  • {JournifiNTPaths.LegacySyncSettingsPath}  ({FileStatus(JournifiNTPaths.LegacySyncSettingsPath)})");
            sb.Append($"  • {JournifiNTPaths.LegacyBarsSettingsPath}  ({FileStatus(JournifiNTPaths.LegacyBarsSettingsPath)})");
            return sb.ToString();
        }

        private static string FileStatus(string path)
        {
            try
            {
                if (!System.IO.File.Exists(path)) return "not found";
                var fi = new System.IO.FileInfo(path);
                return $"{fi.Length} bytes, modified {fi.LastWriteTime:yyyy-MM-dd HH:mm}";
            }
            catch { return "?"; }
        }

        #endregion

        #region Handlers

        private void OnRerunMigrationClick(object sender, RoutedEventArgs e)
        {
            try
            {
                migrationStatusText.Text = "Importing…";
                migrationStatusText.Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorTextSecondary);

                // Route through the bridge so the merge lands in the LIVE
                // settings store (handles post-recompile correctly).
                string message;
                dynamic instance = JournifiSyncNTBridge.Instance;
                if (instance == null)
                {
                    message = "Orchestrator not loaded yet — try again in a moment.";
                }
                else
                {
                    try { message = (string)instance.RerunLegacyMigration(); }
                    catch (Exception ex) { message = $"Error: {ex.Message}"; }
                }

                migrationStatusText.Text = message ?? "Done.";
                migrationStatusText.Foreground = new SolidColorBrush(
                    message != null && message.StartsWith("Imported", StringComparison.Ordinal)
                        ? JournifiSyncNTTheme.ColorAccentGreen
                        : JournifiSyncNTTheme.ColorTextSecondary);

                // Refresh the legacy-files status line in case modification
                // times shifted (no-op for our copy-only flow, but cheap).
                if (legacyStatusText != null) legacyStatusText.Text = BuildLegacyFilesStatus();
            }
            catch (Exception ex)
            {
                migrationStatusText.Text = $"Click handler error: {ex.Message}";
                migrationStatusText.Foreground = new SolidColorBrush(JournifiSyncNTTheme.ColorAccentRed);
            }
        }

        #endregion
    }

    #endregion
}
